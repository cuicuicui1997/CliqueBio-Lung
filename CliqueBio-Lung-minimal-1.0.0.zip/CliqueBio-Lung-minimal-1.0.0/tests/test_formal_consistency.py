from __future__ import annotations

import itertools
import random
import unittest

import networkx as nx
import pandas as pd

from src.module_builder import _expand_or_trim, build_modules, build_seed_adjacency
from src.structural_metrics import contains_r_clique_exact, feasible_module_exact


def scored_graph(edges: list[tuple[str, str]]) -> nx.Graph:
    graph = nx.Graph()
    graph.add_edges_from(edges)
    for node in graph:
        graph.nodes[node]["final_node_score"] = 0.5
        graph.nodes[node]["Knowledge_score"] = 0.0
    for left, right in graph.edges:
        graph.edges[left, right]["final_edge_score"] = 0.7
        graph.edges[left, right]["STRING_score"] = 0.9
    return graph


def brute_contains(graph: nx.Graph, vertices: set[str], r: int) -> bool:
    return any(
        all(graph.has_edge(left, right) for left, right in itertools.combinations(candidate, 2))
        for candidate in itertools.combinations(sorted(vertices), r)
    )


class FormalConsistencyTests(unittest.TestCase):
    def test_valid_clique_seeded_module_passes(self):
        graph = scored_graph([("A", "B"), ("A", "C"), ("B", "C"), ("C", "D")])
        seeds = pd.DataFrame([{"seed_id": "S1", "genes": "A;B;C", "r": 3, "final_seed_score": 0.8}])
        config = {"module": {"min_module_size": 3, "max_module_size": 5, "top_B_modules": 2}}
        modules, meta = build_modules(graph, seeds, config)
        self.assertEqual(len(modules), 1)
        self.assertEqual(meta["num_rejected_infeasible"], 0)
        self.assertTrue(feasible_module_exact(set(modules.iloc[0]["genes"].split(";")), graph, 3, 3, 5))

    def test_connected_size_legal_but_clique_free_is_rejected(self):
        graph = scored_graph([("A", "B"), ("B", "C"), ("C", "D"), ("D", "E")])
        self.assertFalse(feasible_module_exact(set(graph), graph, 3, 5, 5))

    def test_trimming_counterexample_is_rejected_after_repair(self):
        graph = scored_graph([
            ("A", "B"), ("A", "C"), ("B", "C"),
            ("B", "D"), ("D", "E"), ("E", "F"),
        ])
        graph.nodes["A"]["final_node_score"] = 0.0
        for node in set(graph) - {"A"}:
            graph.nodes[node]["final_node_score"] = 10.0
        repaired = _expand_or_trim(graph, set(graph), min_size=5, max_size=5)
        self.assertEqual(repaired, {"B", "C", "D", "E", "F"})
        self.assertFalse(feasible_module_exact(repaired, graph, 3, 5, 5))

    def test_largest_component_counterexample_is_rejected(self):
        graph = scored_graph([
            ("A", "B"), ("A", "C"), ("B", "C"),
            ("D", "E"), ("E", "F"), ("F", "G"),
        ])
        repaired = _expand_or_trim(graph, set(graph), min_size=4, max_size=10)
        self.assertEqual(repaired, {"D", "E", "F", "G"})
        self.assertFalse(feasible_module_exact(repaired, graph, 3, 4, 10))

    def test_random_small_graph_oracle_for_r_3_4_5(self):
        rng = random.Random(2026)
        nodes = [chr(ord("A") + index) for index in range(8)]
        for r in (3, 4, 5):
            for _ in range(25):
                graph = nx.Graph()
                graph.add_nodes_from(nodes)
                for left, right in itertools.combinations(nodes, 2):
                    if rng.random() < 0.42:
                        graph.add_edge(left, right)
                subset = {node for node in nodes if rng.random() < 0.75}
                self.assertEqual(
                    contains_r_clique_exact(subset, graph, r),
                    brute_contains(graph, subset, r),
                )

    def test_seed_pair_generation_is_canonical(self):
        graph = scored_graph([
            ("A", "B"), ("A", "C"), ("B", "C"),
            ("B", "D"), ("C", "D"),
        ])
        forward = {"z": {"A", "B", "C"}, "a": {"B", "C", "D"}}
        reverse = {"a": {"D", "C", "B"}, "z": {"C", "B", "A"}}
        adj1, pairs1 = build_seed_adjacency(graph, forward, 3, 0.5, 2, 100)
        adj2, pairs2 = build_seed_adjacency(graph, reverse, 3, 0.5, 2, 100)
        self.assertEqual(pairs1, pairs2)
        self.assertEqual({key: sorted(value) for key, value in adj1.items()}, {key: sorted(value) for key, value in adj2.items()})


if __name__ == "__main__":
    unittest.main()
