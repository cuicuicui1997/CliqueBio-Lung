from __future__ import annotations

import argparse
import gzip
import shutil
import urllib.request
from pathlib import Path

import pandas as pd


LINKS_URL = "https://stringdb-downloads.org/download/protein.physical.links.v12.0/9606.protein.physical.links.v12.0.txt.gz"
INFO_URL = "https://stringdb-downloads.org/download/protein.info.v12.0/9606.protein.info.v12.0.txt.gz"


def download(url: str, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.stat().st_size > 0:
        return
    with urllib.request.urlopen(url, timeout=120) as response, open(path, "wb") as out:
        shutil.copyfileobj(response, out)


def gene_key(value: object) -> str:
    if pd.isna(value):
        return ""
    return str(value).strip().upper()


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare Homo sapiens STRING physical PPI as symbol-level edges.")
    parser.add_argument("--download-dir", default="data/download")
    parser.add_argument("--out", default="data/raw/STRING_Homo_sapiens_physical_symbol.tsv")
    parser.add_argument("--threshold", type=int, default=700)
    args = parser.parse_args()

    download_dir = Path(args.download_dir)
    links_gz = download_dir / "9606.protein.physical.links.v12.0.txt.gz"
    info_gz = download_dir / "9606.protein.info.v12.0.txt.gz"
    download(LINKS_URL, links_gz)
    download(INFO_URL, info_gz)

    with gzip.open(info_gz, "rt") as handle:
        info = pd.read_csv(handle, sep="\t")
    symbol_map = dict(zip(info["#string_protein_id"], info["preferred_name"].map(gene_key)))

    with gzip.open(links_gz, "rt") as handle:
        links = pd.read_csv(handle, sep=" ")
    raw_edges = len(links)
    links["geneA"] = links["protein1"].map(symbol_map)
    links["geneB"] = links["protein2"].map(symbol_map)
    mapped = links.dropna(subset=["geneA", "geneB"]).copy()
    mapped = mapped[(mapped["geneA"].str.len() > 0) & (mapped["geneB"].str.len() > 0)]
    mapped_edges = len(mapped)
    mapped = mapped[mapped["geneA"] != mapped["geneB"]]
    mapped = mapped[pd.to_numeric(mapped["combined_score"], errors="coerce") >= args.threshold]
    filtered_edges = len(mapped)
    a = mapped[["geneA", "geneB"]].min(axis=1)
    b = mapped[["geneA", "geneB"]].max(axis=1)
    mapped["geneA"], mapped["geneB"] = a, b
    out = (
        mapped[["geneA", "geneB", "combined_score"]]
        .sort_values("combined_score", ascending=False)
        .drop_duplicates(["geneA", "geneB"], keep="first")
        .sort_values(["geneA", "geneB"])
    )
    out["combined_score"] = out["combined_score"].astype(int)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(out_path, sep="\t", index=False)

    report = [
        "STRING Homo sapiens physical PPI preparation report",
        f"links_url: {LINKS_URL}",
        f"protein_info_url: {INFO_URL}",
        f"threshold: {args.threshold}",
        f"raw_edges: {raw_edges}",
        f"mapped_edges: {mapped_edges}",
        f"unmapped_edges: {raw_edges - mapped_edges}",
        f"filtered_edges: {filtered_edges}",
        f"unique_symbol_level_edges: {len(out)}",
    ]
    Path("data/processed").mkdir(parents=True, exist_ok=True)
    Path("data/processed/string_physical_ppi_prepare_report.txt").write_text("\n".join(report), encoding="utf-8")
    print("\n".join(report))


if __name__ == "__main__":
    main()
