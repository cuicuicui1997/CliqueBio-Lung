from __future__ import annotations

import argparse
import pandas as pd

from experiment_utils import exp_dir, load_cached_inputs, run_cached_setting, module_summary, write_report


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/phase1_luad.yaml")
    p.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    args = p.parse_args()
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    rows = []
    for max_genes in [500, 1000, 1500, 2000, 3000]:
        try:
            res = run_cached_setting(cfg, cache, {"candidate_graph.max_candidate_genes": max_genes}, 3)
            s = res["graph_stats"].iloc[0]; ms = module_summary(res["modules"])
            rows.append({"max_candidate_genes": max_genes, "candidate_num_nodes": s["candidate_num_nodes"], "candidate_num_edges": s["candidate_num_edges"], "density": s["density"], "degeneracy": s["degeneracy"], "enumerated_cliques": res["enum_meta"]["num_enumerated_cliques"], "retained_seeds": res["enum_meta"]["num_retained_seeds"], **ms, "enumeration_time": res["enum_meta"]["runtime_enum"], "expansion_time": res["module_meta"].get("runtime_expansion"), "redundancy_selection_time": res["module_meta"].get("runtime_redundancy_selection"), "total_runtime_without_scoring": res["total"], "status": "success", "notes": ""})
        except Exception as exc:
            rows.append({"max_candidate_genes": max_genes, "status": "failed", "notes": str(exc)})
    out = exp_dir("exp04_graph_size_scalability")
    df = pd.DataFrame(rows); df.to_csv(out / "graph_size_scalability.csv", index=False)
    ok = df[df["status"] == "success"]
    write_report(out / "GRAPH_SIZE_SCALABILITY_REPORT.md", "Exp 4 Graph-Size Scalability",
                 f"Completed {len(ok)}/{len(df)} graph-size settings using cached scores. The experiment records growth in candidate graph size, degeneracy, clique count, and module construction time without treating AUC as the objective. Max runtime without scoring: {ok['total_runtime_without_scoring'].max() if not ok.empty else 'NA'}s.")


if __name__ == "__main__":
    main()
