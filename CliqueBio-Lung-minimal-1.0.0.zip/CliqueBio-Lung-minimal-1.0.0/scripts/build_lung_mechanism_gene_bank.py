from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


GENES = {
    "ECM_CAF": ["ACTA2", "FAP", "PDGFRB", "TAGLN", "VIM", "COL1A1"],
    "collagen_remodeling": ["COL1A1", "COL1A2", "COL3A1", "COL5A1", "LOX", "MMP2", "MMP9", "TIMP1"],
    "immune_checkpoint": ["CD274", "PDCD1", "PDCD1LG2", "CTLA4", "LAG3", "TIGIT", "HAVCR2"],
    "glycolysis": ["HK2", "PFKP", "ALDOA", "ENO1", "PKM", "LDHA", "SLC2A1"],
    "ferroptosis": ["SLC7A11", "GPX4", "ACSL4", "FTH1", "NFE2L2", "TFRC"],
    "mTOR": ["MTOR", "RPTOR", "RICTOR", "AKT1", "PIK3CA", "TSC1", "TSC2", "RHEB"],
    "p53_MDM2": ["TP53", "MDM2", "MDM4", "CDKN1A", "ATM", "CHEK2"],
    "tRF_RBP_exploratory": ["YBX1", "IGF2BP1", "IGF2BP2", "IGF2BP3", "HNRNPA1", "ELAVL1"],
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a small curated lung mechanism gene bank for Phase 1.6.")
    parser.add_argument("--out", default="data/raw/lung_mechanism_gene_bank.tsv")
    args = parser.parse_args()

    rows = []
    for category, genes in GENES.items():
        for gene in genes:
            rows.append({
                "gene": gene.upper(),
                "category": category,
                "source_note": "Phase 1.6 initial curated lung-cancer mechanism bank",
            })
    df = pd.DataFrame(rows).drop_duplicates(["gene", "category"]).sort_values(["category", "gene"])
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, sep="\t", index=False)
    print(f"wrote {out} with {df['gene'].nunique()} unique genes and {len(df)} gene-category rows")


if __name__ == "__main__":
    main()
