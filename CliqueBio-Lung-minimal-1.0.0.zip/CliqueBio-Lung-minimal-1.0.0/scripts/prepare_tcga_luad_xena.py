from __future__ import annotations

import argparse
import gzip
import shutil
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd


EXPRESSION_URL = "https://tcga.xenahubs.net/download/TCGA.LUAD.sampleMap/HiSeqV2.gz"
CLINICAL_URL = "https://tcga.xenahubs.net/download/TCGA.LUAD.sampleMap/LUAD_clinicalMatrix"


def download(url: str, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.stat().st_size > 0:
        return
    with urllib.request.urlopen(url, timeout=120) as response, open(path, "wb") as out:
        shutil.copyfileobj(response, out)


def normalize_gene(value: object) -> str:
    if pd.isna(value):
        return ""
    return str(value).strip().upper()


def sample_label(sample_id: str) -> str | None:
    parts = str(sample_id).split("-")
    if len(parts) < 4:
        return None
    code = parts[3][:2]
    if "01" <= code <= "09":
        return "tumor"
    if "10" <= code <= "19":
        return "normal"
    return None


def load_expression(gz_path: Path, barcode_length: int) -> pd.DataFrame:
    with gzip.open(gz_path, "rt") as handle:
        expr = pd.read_csv(handle, sep="\t")
    gene_col = expr.columns[0]
    expr[gene_col] = expr[gene_col].map(normalize_gene)
    expr = expr[expr[gene_col].str.len() > 0]
    expr = expr.set_index(gene_col)
    expr.columns = [str(c)[:barcode_length] for c in expr.columns]
    expr = expr.apply(pd.to_numeric, errors="coerce")
    if pd.Index(expr.columns).has_duplicates:
        expr = expr.T.groupby(level=0).mean(numeric_only=True).T
    if expr.index.has_duplicates:
        expr = expr.groupby(level=0).mean(numeric_only=True)
    expr.index.name = "GeneSymbol"
    return expr


def build_metadata(expression: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for sample_id in expression.columns:
        label = sample_label(sample_id)
        if label is not None:
            rows.append({"sample_id": sample_id, "label": label})
    return pd.DataFrame(rows).drop_duplicates("sample_id")


def first_existing(row: pd.Series, columns: list[str]) -> object:
    for col in columns:
        if col in row.index and pd.notna(row[col]) and str(row[col]).strip() != "":
            return row[col]
    return np.nan


def build_survival(clinical_path: Path, expression_samples: list[str]) -> pd.DataFrame:
    clinical = pd.read_csv(clinical_path, sep="\t", low_memory=False)
    sample_col = "sampleID" if "sampleID" in clinical.columns else clinical.columns[0]
    clinical[sample_col] = clinical[sample_col].astype(str)
    clinical["_sample16"] = clinical[sample_col].str[:16]
    clinical["_patient12"] = clinical[sample_col].str[:12]

    rows = []
    for _, row in clinical.drop_duplicates("_patient12").iterrows():
        death = pd.to_numeric(row.get("days_to_death"), errors="coerce")
        followup = pd.to_numeric(row.get("days_to_last_followup"), errors="coerce")
        vital = str(first_existing(row, ["vital_status", "person_neoplasm_cancer_status"])).strip().lower()
        if pd.notna(death) and death > 0:
            os_time = float(death)
            os_status = 1
        elif pd.notna(followup) and followup > 0:
            os_time = float(followup)
            os_status = 0 if "living" in vital or "alive" in vital or vital in {"nan", ""} else np.nan
        else:
            os_time = np.nan
            os_status = 1 if "dead" in vital or "deceased" in vital else (0 if "living" in vital or "alive" in vital else np.nan)
        rows.append({"patient12": row["_patient12"], "OS_time": os_time, "OS_status": os_status})

    patient_survival = pd.DataFrame(rows).drop_duplicates("patient12")
    sample_map = pd.DataFrame({"sample_id": expression_samples})
    sample_map["patient12"] = sample_map["sample_id"].str[:12]
    survival = sample_map.merge(patient_survival, on="patient12", how="left")
    survival = survival[["sample_id", "OS_time", "OS_status"]]
    survival = survival[(survival["OS_time"].isna()) | (survival["OS_time"] > 0)]
    return survival


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare TCGA-LUAD expression, metadata, and survival files from UCSC Xena.")
    parser.add_argument("--download-dir", default="data/download")
    parser.add_argument("--out-dir", default="data/raw")
    parser.add_argument("--barcode-length", type=int, choices=[12, 16], default=16)
    args = parser.parse_args()

    download_dir = Path(args.download_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    expr_gz = download_dir / "TCGA_LUAD_HiSeqV2.gz"
    clinical_tsv = download_dir / "LUAD_clinicalMatrix.tsv"
    download(EXPRESSION_URL, expr_gz)
    download(CLINICAL_URL, clinical_tsv)

    expression = load_expression(expr_gz, args.barcode_length)
    metadata = build_metadata(expression)
    expression = expression.loc[:, metadata["sample_id"].tolist()]
    survival = build_survival(clinical_tsv, list(expression.columns))

    expression.reset_index().to_csv(out_dir / "TCGA_LUAD_expression.tsv", sep="\t", index=False)
    metadata.to_csv(out_dir / "TCGA_LUAD_metadata.tsv", sep="\t", index=False)
    survival.to_csv(out_dir / "TCGA_LUAD_survival.tsv", sep="\t", index=False)

    report = [
        "TCGA-LUAD Xena preparation report",
        f"expression_url: {EXPRESSION_URL}",
        f"clinical_url: {CLINICAL_URL}",
        f"barcode_length: {args.barcode_length}",
        f"expression_genes: {expression.shape[0]}",
        f"expression_samples: {expression.shape[1]}",
        f"metadata_tumor: {int((metadata['label'] == 'tumor').sum())}",
        f"metadata_normal: {int((metadata['label'] == 'normal').sum())}",
        f"survival_rows: {len(survival)}",
        f"survival_available: {int(survival[['OS_time', 'OS_status']].dropna().shape[0])}",
    ]
    Path("data/processed").mkdir(parents=True, exist_ok=True)
    Path("data/processed/tcga_luad_prepare_report.txt").write_text("\n".join(report), encoding="utf-8")
    print("\n".join(report))


if __name__ == "__main__":
    main()
