from __future__ import annotations

import argparse
import itertools
import time

import networkx as nx
import numpy as np
import pandas as pd

from experiment_utils import exp_dir, load_cached_inputs, build_graph_from_cache, avg_pairwise_jaccard, write_report
from src.clique_enum import enumerate_top_r_cliques
from src.module_builder import build_modules
from src.pipeline import apply_overrides
from src.utils import split_gene_list


def summarize_outputs(graph, outputs: pd.DataFrame, setting: str, runtime: float) -> dict:
    sizes = pd.to_numeric(outputs.get("size", pd.Series(dtype=float)), errors="coerce")
    return {"setting": setting, "num_outputs": len(outputs), "module_size_min": sizes.min(), "module_size_median": sizes.median(), "module_size_max": sizes.max(), "avg_num_supporting_cliques": pd.to_numeric(outputs.get("num_clique_seeds", pd.Series(dtype=float)), errors="coerce").mean(), "avg_clique_coverage": pd.to_numeric(outputs.get("clique_coverage", pd.Series(dtype=float)), errors="coerce").mean(), "avg_ppi_density": pd.to_numeric(outputs.get("ppi_density", pd.Series(dtype=float)), errors="coerce").mean(), "avg_string_confidence": pd.to_numeric(outputs.get("avg_string_score", pd.Series(dtype=float)), errors="coerce").mean(), "avg_module_score": pd.to_numeric(outputs.get("module_score", pd.Series(dtype=float)), errors="coerce").mean(), "avg_pairwise_jaccard": avg_pairwise_jaccard(outputs), "mechanism_gene_fraction": pd.to_numeric(outputs.get("mechanism_gene_fraction", pd.Series(dtype=float)), errors="coerce").mean(), "runtime_construction": runtime, "status": "success", "notes": ""}


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/phase1_luad.yaml")
    p.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    args = p.parse_args()
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    graph, _ = build_graph_from_cache(cfg, cache, {"candidate_graph.max_candidate_genes": 1500})
    seeds, _ = enumerate_top_r_cliques(graph, 3, int(cfg["clique"]["max_clique_seeds"]))
    rows = []
    seed_audit_cfg = apply_overrides(cfg, {"module.min_module_size": 3})
    t = time.perf_counter(); iso, _ = build_modules(graph, seeds.head(10), seed_audit_cfg, no_expansion=True, redundancy=False); rows.append(summarize_outputs(graph, iso, "IsolatedClique", time.perf_counter() - t))
    t = time.perf_counter(); union, _ = build_modules(graph, seeds.head(200), seed_audit_cfg, no_expansion=True, redundancy=True); rows.append(summarize_outputs(graph, union, "CliqueUnion", time.perf_counter() - t))
    t = time.perf_counter(); perc, _ = build_modules(graph, seeds, cfg, no_expansion=False, redundancy=False); rows.append(summarize_outputs(graph, perc, "CliquePercolation", time.perf_counter() - t))
    t = time.perf_counter(); full, _ = build_modules(graph, seeds, cfg, no_expansion=False, redundancy=True); rows.append(summarize_outputs(graph, full, "FullModuleConstruction", time.perf_counter() - t))
    out = exp_dir("exp09_module_construction_ablation")
    df = pd.DataFrame(rows); df.to_csv(out / "module_construction_ablation.csv", index=False)
    write_report(out / "MODULE_CONSTRUCTION_ABLATION_REPORT.md", "Exp 9 Module Construction Ablation", "The experiment contrasts isolated cliques with clique-seeded/percolated modules. The intended claim is that final modules preserve clique support while producing biologically interpretable module-scale structures rather than isolated r-node cliques.")


if __name__ == "__main__":
    main()
