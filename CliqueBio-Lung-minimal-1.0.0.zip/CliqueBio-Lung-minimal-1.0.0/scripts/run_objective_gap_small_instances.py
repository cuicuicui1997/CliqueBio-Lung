from __future__ import annotations

import argparse
import itertools
import sys
import time
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from experiment_utils import build_graph_from_cache, load_cached_inputs
from kbs_experiment_utils import RANDOM_SEED, jaccard, write_json
from src.clique_enum import enumerate_top_r_cliques
from src.module_builder import build_modules
from src.pipeline import apply_overrides
from src.utils import set_random_seed, split_gene_list
from src.canonical import vertex_key


def objective(rows: list[dict], lam: float) -> float:
    sets = [set(split_gene_list(row["genes"])) for row in rows]
    return sum(float(row["module_score"]) for row in rows) - lam * sum(
        jaccard(a, b) for i, a in enumerate(sets) for b in sets[i + 1 :]
    )


def exact_select(pool: list[dict], budget: int, lam: float) -> tuple[list[dict], float]:
    best_rows, best_value = [], float("-inf")
    for size in range(1, min(budget, len(pool)) + 1):
        for combo in itertools.combinations(pool, size):
            value = objective(list(combo), lam)
            if value > best_value:
                best_rows, best_value = list(combo), value
    return best_rows, best_value


def threshold_select(pool: list[dict], budget: int, tau: float) -> list[dict]:
    selected = []
    for row in sorted(pool, key=lambda item: (-float(item["module_score"]), vertex_key(split_gene_list(item["genes"])))):
        genes = set(split_gene_list(row["genes"]))
        if all(jaccard(genes, set(split_gene_list(old["genes"]))) < tau for old in selected):
            selected.append(row)
        if len(selected) >= budget:
            break
    return selected


def penalty_select(pool: list[dict], budget: int, lam: float) -> list[dict]:
    remaining, selected = list(pool), []
    while remaining and len(selected) < budget:
        best = min(
            remaining,
            key=lambda row: (
                -(objective(selected + [row], lam) - objective(selected, lam) if selected else float(row["module_score"])),
                vertex_key(split_gene_list(row["genes"])),
            ),
        )
        selected.append(best)
        remaining.remove(best)
    return selected


def main() -> None:
    parser = argparse.ArgumentParser(description="Exact objective comparison within generated module pools.")
    parser.add_argument("--config", default="configs/phase1_luad.yaml")
    parser.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    parser.add_argument("--output-dir", default="results/objective_gap")
    parser.add_argument("--lambda-value", type=float, default=0.2)
    args = parser.parse_args()
    set_random_seed(RANDOM_SEED)
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    log = [f"random_seed={RANDOM_SEED}", f"config={Path(args.config).resolve()}", f"cache={Path(args.cache_dir).resolve()}", f"lambda={args.lambda_value}"]
    print("\n".join(log))
    for candidate_budget in [100, 150, 200]:
        local = apply_overrides(cfg, {
            "candidate_graph.max_candidate_genes": candidate_budget,
            "module.top_B_modules": 30,
            "module.top_b": 30,
        })
        graph, _ = build_graph_from_cache(cfg, cache, {"candidate_graph.max_candidate_genes": candidate_budget})
        seeds, _ = enumerate_top_r_cliques(graph, 3, int(local["clique"]["max_clique_seeds"]))
        generated, _ = build_modules(graph, seeds, local, no_expansion=False, redundancy=False)
        generated = generated.sort_values(["module_score", "genes"], ascending=[False, True], kind="mergesort").drop_duplicates("genes").head(30)
        pool = generated.to_dict(orient="records")
        budget = min(3, len(pool))
        tau = float(local["module"].get("redundancy_threshold", 0.5))
        start = time.perf_counter()
        optimal, optimal_value = exact_select(pool, budget, args.lambda_value)
        exact_time = time.perf_counter() - start
        start = time.perf_counter()
        threshold = threshold_select(pool, budget, tau)
        threshold_time = time.perf_counter() - start
        start = time.perf_counter()
        penalty = penalty_select(pool, budget, args.lambda_value)
        penalty_time = time.perf_counter() - start
        threshold_value = objective(threshold, args.lambda_value)
        penalty_value = objective(penalty, args.lambda_value)
        result = {
            "candidate_budget": candidate_budget,
            "candidate_nodes": graph.number_of_nodes(),
            "candidate_edges": graph.number_of_edges(),
            "pool_size": len(pool), "B": budget, "lambda": args.lambda_value,
            "optimal_objective": optimal_value,
            "cliquebio_objective": threshold_value,
            "cliquebio_ratio": threshold_value / optimal_value if optimal_value else float("nan"),
            "penalty_greedy_objective": penalty_value,
            "penalty_greedy_ratio": penalty_value / optimal_value if optimal_value else float("nan"),
            "optimal_redundancy": sum(jaccard(set(split_gene_list(a["genes"])), set(split_gene_list(b["genes"]))) for a, b in itertools.combinations(optimal, 2)),
            "cliquebio_redundancy": sum(jaccard(set(split_gene_list(a["genes"])), set(split_gene_list(b["genes"]))) for a, b in itertools.combinations(threshold, 2)),
            "exact_time_seconds": exact_time,
            "cliquebio_time_seconds": threshold_time,
            "penalty_greedy_time_seconds": penalty_time,
        }
        rows.append(result)
        log.append(str(result))
    df = pd.DataFrame(rows)
    df.to_csv(out / "objective_gap_small_instances.csv", index=False)
    write_json(out / "objective_gap_small_instances.json", {"random_seed": RANDOM_SEED, "results": rows})
    (out / "run.log").write_text("\n".join(log) + "\n", encoding="utf-8")
    print(df.to_string(index=False))


if __name__ == "__main__":
    main()
