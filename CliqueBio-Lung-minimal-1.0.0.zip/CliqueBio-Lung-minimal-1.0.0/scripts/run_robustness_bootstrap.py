from __future__ import annotations

import argparse
import itertools
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from experiment_utils import build_graph_from_cache, load_cached_inputs
from kbs_experiment_utils import RANDOM_SEED, jaccard, write_json
from src.clique_enum import enumerate_top_r_cliques
from src.module_builder import build_modules
from src.scoring import label_vectors
from src.utils import normalize_01, set_random_seed, split_gene_list


def leakage_reduced_nodes(cache: dict, tumor: list[str], normal: list[str], config: dict) -> pd.DataFrame:
    expression = cache["expression"]
    tumor_values = expression[tumor].to_numpy(dtype=float)
    normal_values = expression[normal].to_numpy(dtype=float)
    _, pvalues = stats.ttest_ind(tumor_values, normal_values, axis=1, equal_var=False, nan_policy="omit")
    logfc = np.nanmean(tumor_values, axis=1) - np.nanmean(normal_values, axis=1)
    raw = np.abs(logfc) * -np.log10(np.maximum(np.nan_to_num(pvalues, nan=1.0), 1e-300))
    de = normalize_01(pd.Series(raw, index=expression.index))
    node = cache["node_scores"].copy().set_index("gene")
    node["DE_score"] = de.reindex(node.index)
    node["AUC_score"] = np.nan
    node["Cox_score"] = np.nan
    node["Stability_score"] = np.nan
    weights = config.get("node_scoring", {}).get("weights", {})
    de_weight = float(weights.get("DE_score", 0.0))
    knowledge_weight = float(weights.get("Knowledge_score", 0.0))
    active_weight = de_weight + knowledge_weight
    node["final_node_score"] = (
        de_weight * node["DE_score"].fillna(0.0)
        + knowledge_weight * node["Knowledge_score"].fillna(0.0)
    ) / active_weight if active_weight > 0 else 0.0
    return node.reset_index()


def matched_output_jaccard(a: list[set[str]], b: list[set[str]]) -> float:
    if not a or not b:
        return 0.0
    forward = np.mean([max(jaccard(x, y) for y in b) for x in a])
    reverse = np.mean([max(jaccard(y, x) for x in a) for y in b])
    return float((forward + reverse) / 2.0)


def main() -> None:
    parser = argparse.ArgumentParser(description="Stratified repeated-subsampling stability for leakage-reduced CliqueBio.")
    parser.add_argument("--config", default="configs/phase1_luad.yaml")
    parser.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    parser.add_argument("--runs", type=int, default=10)
    parser.add_argument("--fraction", type=float, default=0.8)
    parser.add_argument("--output-dir", default="results/robustness")
    args = parser.parse_args()
    set_random_seed(RANDOM_SEED)
    rng = np.random.default_rng(RANDOM_SEED)
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    samples, labels = label_vectors(cache["metadata"], cfg, list(cache["expression"].columns))
    tumor = np.asarray([s for s, y in zip(samples, labels) if y == 1])
    normal = np.asarray([s for s, y in zip(samples, labels) if y == 0])
    reference = {
        "ECM/collagen": set("COL11A1 COL1A1 COL1A2 COL3A1 COL5A1 COL5A2".split()),
        "immune checkpoint": set("CD274 CTLA4 HAVCR2 PDCD1 PDCD1LG2".split()),
        "RNA-binding protein": set("ELAVL1 IGF2BP1 IGF2BP3 PABPC1 YBX1".split()),
    }
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    run_rows, gene_counts, output_sets = [], {}, []
    log = [
        f"random_seed={RANDOM_SEED}", f"PYTHONHASHSEED={os.environ.get('PYTHONHASHSEED', 'unset')}", f"config={Path(args.config).resolve()}",
        f"cache={Path(args.cache_dir).resolve()}", f"runs={args.runs}, fraction={args.fraction}",
        "node weights loaded from config; AUC=Cox=Stability=0",
    ]
    print("\n".join(log))
    for run in range(args.runs):
        start = time.perf_counter()
        t = rng.choice(tumor, size=max(3, round(len(tumor) * args.fraction)), replace=False).tolist()
        n = rng.choice(normal, size=max(3, round(len(normal) * args.fraction)), replace=False).tolist()
        local_cache = dict(cache)
        local_cache["node_scores"] = leakage_reduced_nodes(cache, t, n, cfg)
        graph, _ = build_graph_from_cache(cfg, local_cache, {"candidate_graph.max_candidate_genes": 1500})
        seeds, _ = enumerate_top_r_cliques(graph, 3, int(cfg["clique"]["max_clique_seeds"]))
        modules, _ = build_modules(graph, seeds, cfg, no_expansion=False, redundancy=True)
        sets = [set(split_gene_list(value)) for value in modules.get("genes", [])]
        output_sets.append(sets)
        for gene in set().union(*sets) if sets else set():
            gene_counts[gene] = gene_counts.get(gene, 0) + 1
        row = {
            "run": run + 1, "tumor_samples": len(t), "normal_samples": len(n),
            "candidate_nodes": graph.number_of_nodes(), "candidate_edges": graph.number_of_edges(),
            "enumerated_cliques": len(seeds), "returned_modules": len(modules),
            "runtime_seconds": time.perf_counter() - start,
        }
        for theme, genes in reference.items():
            row[f"{theme}_max_jaccard"] = max((jaccard(genes, module) for module in sets), default=0.0)
        run_rows.append(row)
        log.append(str(row))
    pairwise = [matched_output_jaccard(a, b) for a, b in itertools.combinations(output_sets, 2)]
    run_df = pd.DataFrame(run_rows)
    run_df.to_csv(out / "bootstrap_runs.csv", index=False)
    recurrence = pd.DataFrame([
        {"gene": gene, "run_count": count, "recurrence": count / args.runs}
        for gene, count in gene_counts.items()
    ]).sort_values(["recurrence", "gene"], ascending=[False, True])
    recurrence.to_csv(out / "gene_recurrence.csv", index=False)
    summary = {
        "random_seed": RANDOM_SEED, "runs": args.runs, "fraction": args.fraction,
        "mean_matched_output_jaccard": float(np.mean(pairwise)),
        "median_matched_output_jaccard": float(np.median(pairwise)),
        "top10_gene_mean_recurrence": float(recurrence.head(10)["recurrence"].mean()),
        "theme_median_max_jaccard": {
            theme: float(run_df[f"{theme}_max_jaccard"].median()) for theme in reference
        },
    }
    write_json(out / "bootstrap_summary.json", summary)
    (out / "run.log").write_text("\n".join(log) + "\n", encoding="utf-8")
    print(summary)


if __name__ == "__main__":
    main()
