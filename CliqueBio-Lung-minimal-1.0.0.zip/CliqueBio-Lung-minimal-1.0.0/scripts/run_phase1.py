from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.pipeline import run_phase1_pipeline


def main() -> None:
    parser = argparse.ArgumentParser(description="Run CliqueBio-Lung Phase 1 feasibility pipeline.")
    parser.add_argument("--config", required=True, help="Path to phase1 YAML config.")
    parser.add_argument("--r", type=int, default=None, help="Clique size, usually 3 or 4.")
    parser.add_argument("--max_candidate_genes", type=int, default=None, help="Override candidate_graph.max_candidate_genes.")
    parser.add_argument("--use-cache", action="store_true", help="Use a precomputed discovery scoring cache.")
    parser.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real", help="Scoring cache directory.")
    parser.add_argument("--output-dir", default=None, help="Optional non-overwriting result root for this replay.")
    args = parser.parse_args()
    overrides = {}
    if args.max_candidate_genes is not None:
        overrides["candidate_graph.max_candidate_genes"] = args.max_candidate_genes
    if args.output_dir is not None:
        overrides["paths.output_dir"] = args.output_dir
    result = run_phase1_pipeline(args.config, r=args.r, overrides=overrides, use_cache=args.use_cache, cache_dir=args.cache_dir)
    print(f"run_id={result['run_id']}")
    print(f"output_dir={result['dirs']['run']}")


if __name__ == "__main__":
    main()
