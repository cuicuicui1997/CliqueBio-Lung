from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.cache import build_score_cache
from src.pipeline import load_config


def main() -> None:
    parser = argparse.ArgumentParser(description="Build discovery scoring cache for Phase 1.8 experiments.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    args = parser.parse_args()
    config_path = Path(args.config).resolve()
    config, base = load_config(config_path)
    manifest = build_score_cache(config, config_path, base, args.cache_dir)
    print(f"cache_dir={Path(args.cache_dir).resolve()}")
    print(json.dumps({
        "number_of_expression_genes": manifest["number_of_expression_genes"],
        "number_of_samples": manifest["number_of_samples"],
        "number_of_node_scores": manifest["number_of_node_scores"],
        "number_of_scored_ppi_edges": manifest["number_of_scored_ppi_edges"],
    }, indent=2))


if __name__ == "__main__":
    main()
