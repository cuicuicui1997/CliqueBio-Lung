from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pandas as pd

from experiment_utils import exp_dir, write_report


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/phase1_luad.yaml")
    p.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    args = p.parse_args()
    result_root = Path(os.environ.get("CLIQUEBIO_RESULT_ROOT", "results"))
    exact_dir = result_root / "exact_check"
    subprocess.run(
        [
            sys.executable,
            "scripts/run_small_exact_comparison.py",
            "--config",
            args.config,
            "--cache-dir",
            args.cache_dir,
            "--output-dir",
            str(exact_dir),
        ],
        check=True,
    )
    out = exp_dir("exp02_correctness")
    shutil.copyfile(exact_dir / "small_exact_comparison.csv", out / "correctness_comparison.csv")
    df = pd.read_csv(out / "correctness_comparison.csv")
    write_report(out / "CORRECTNESS_REPORT.md", "Exp 2 Correctness of Clique Enumeration",
                 f"All clique sets match: {bool(df['sets_match'].all())}. All top seed scores match: {bool(df['top_seed_score_match'].all())}. Median speedup over naive exact enumeration is {df['speedup'].median():.2f}x. No duplicate or missing cliques were detected in the tested small candidate graphs.")


if __name__ == "__main__":
    main()
