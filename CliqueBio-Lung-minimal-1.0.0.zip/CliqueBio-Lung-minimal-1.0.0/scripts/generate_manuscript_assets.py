from __future__ import annotations

import csv
import os
import shutil
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path("manuscript_assets")
RESULTS_ROOT = Path(os.environ.get("CLIQUEBIO_RESULT_ROOT", "results"))
DEFAULT_RUN_DIR = Path(os.environ.get("CLIQUEBIO_DEFAULT_RUN_DIR", "results/runs/phase1_luad_real_LUAD_r3_20260702_190229"))
TABLES = ROOT / "tables"
FIGURES = ROOT / "figures"
FIGDATA = ROOT / "figure_data"
TABLEDATA = ROOT / "table_data"
TEXT = ROOT / "text"
LATEX = ROOT / "latex"


def ensure_dirs() -> None:
    for path in [TABLES, FIGURES, FIGDATA, TABLEDATA, TEXT, LATEX]:
        path.mkdir(parents=True, exist_ok=True)


def fmt(value, digits: int = 3) -> str:
    if pd.isna(value):
        return "NA"
    if isinstance(value, str):
        return value
    try:
        number = float(value)
    except Exception:
        return str(value)
    if abs(number - round(number)) < 1e-9:
        return str(int(round(number)))
    return f"{number:.{digits}f}"


def markdown_table(df: pd.DataFrame) -> str:
    headers = list(df.columns)
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    for _, row in df.iterrows():
        lines.append("| " + " | ".join(str(row[col]) for col in headers) + " |")
    return "\n".join(lines) + "\n"


def latex_table(df: pd.DataFrame, caption: str, label: str) -> str:
    cols = "l" * len(df.columns)
    body = ["\\begin{table}[t]", "\\centering", f"\\caption{{{caption}}}", f"\\label{{{label}}}", f"\\begin{{tabular}}{{{cols}}}", "\\toprule"]
    body.append(" & ".join(df.columns) + " \\\\")
    body.append("\\midrule")
    for _, row in df.iterrows():
        body.append(" & ".join(str(row[col]).replace("_", "\\_") for col in df.columns) + " \\\\")
    body.extend(["\\bottomrule", "\\end{tabular}", "\\end{table}", ""])
    return "\n".join(body)


def figure_snippet(filename: str, caption: str, label: str) -> str:
    return "\n".join([
        "\\begin{figure}[t]",
        "\\centering",
        f"\\includegraphics[width=0.98\\linewidth]{{{filename}}}",
        f"\\caption{{{caption}}}",
        f"\\label{{{label}}}",
        "\\end{figure}",
        "",
    ])


def save_table(df: pd.DataFrame, stem: str, caption: str, label: str) -> None:
    df.to_csv(TABLEDATA / f"{stem}.csv", index=False)
    (TABLES / f"{stem}.md").write_text(markdown_table(df), encoding="utf-8")
    (LATEX / f"{stem}.tex").write_text(latex_table(df, caption, label), encoding="utf-8")


def panel_label(ax, label: str) -> None:
    ax.text(-0.12, 1.08, label, transform=ax.transAxes, fontsize=11, fontweight="bold", va="top")


def table1() -> None:
    src = pd.read_csv(RESULTS_ROOT / "experiments/exp01_problem_instance/problem_instance_stats.csv")
    cols = ["max_candidate_genes", "r", "candidate_num_nodes", "candidate_num_edges", "density", "average_degree", "degeneracy", "num_r_cliques", "avg_string_confidence", "runtime_enum"]
    out = src[cols].copy()
    for col in ["density", "average_degree", "avg_string_confidence", "runtime_enum"]:
        out[col] = out[col].map(lambda x: fmt(x, 3))
    for col in ["candidate_num_nodes", "candidate_num_edges", "degeneracy", "num_r_cliques"]:
        out[col] = out[col].map(lambda x: fmt(x, 0))
    save_table(out, "Table1_graph_instance_statistics", "Statistics of weighted PPI graph instances under different candidate sizes.", "tab:graph-instance-statistics")


def figure1() -> None:
    correct = pd.read_csv(RESULTS_ROOT / "experiments/exp02_correctness/correctness_comparison.csv")
    runtime = pd.read_csv(RESULTS_ROOT / "experiments/exp03_runtime_baseline/runtime_baseline.csv")
    merged = runtime.copy()
    merged.to_csv(FIGDATA / "Figure1_correctness_runtime.csv", index=False)
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.2))
    pivot = runtime[runtime["method"].isin(["NaiveEnum", "DegEnum"])].pivot(index="max_candidate_genes", columns="method", values="enumeration_time")
    pivot.plot(ax=axes[0], marker="o", color=["#666666", "#1f77b4"])
    axes[0].set_xlabel("max_candidate_genes")
    axes[0].set_ylabel("Enumeration time (s)")
    axes[0].set_title("Exact enumeration runtime")
    axes[0].legend(frameon=False)
    panel_label(axes[0], "A")
    deg = runtime[runtime["method"].isin(["DegEnum", "DegEnum+TopSeed", "CliqueBio-Full"])]
    for method, group in deg.groupby("method"):
        axes[1].plot(group["max_candidate_genes"], group["speedup_vs_naive"], marker="o", label=method)
    axes[1].set_xlabel("max_candidate_genes")
    axes[1].set_ylabel("Speedup vs exhaustive subsets")
    axes[1].set_title("Runtime gain")
    axes[1].legend(frameon=False, fontsize=8)
    panel_label(axes[1], "B")
    fig.tight_layout()
    fig.savefig(FIGURES / "Figure1_correctness_runtime.png", dpi=220)
    plt.close(fig)
    med = correct["speedup"].median()
    caption = f"Correctness and runtime efficiency. Optimized enumeration exactly matched the naive reference in clique set and top seed score across small exact checks. The median exact-check speedup was {med:.2f}x."
    (LATEX / "Figure1_correctness_runtime.tex").write_text(figure_snippet("Figure1_correctness_runtime.png", caption, "fig:correctness-runtime"), encoding="utf-8")


def figure2() -> None:
    df = pd.read_csv(RESULTS_ROOT / "experiments/exp04_graph_size_scalability/graph_size_scalability.csv")
    df.to_csv(FIGDATA / "Figure2_graph_size_scalability.csv", index=False)
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.2))
    specs = [("total_runtime_without_scoring", "Runtime without scoring (s)", "A"), ("enumerated_cliques", "Enumerated r=3 cliques", "B"), ("degeneracy", "Degeneracy", "C")]
    for ax, (y, ylabel, label) in zip(axes, specs):
        ax.plot(df["max_candidate_genes"], df[y], marker="o", color="#1f77b4")
        ax.set_xlabel("max_candidate_genes")
        ax.set_ylabel(ylabel)
        panel_label(ax, label)
    fig.tight_layout()
    fig.savefig(FIGURES / "Figure2_graph_size_scalability.png", dpi=220)
    plt.close(fig)
    caption = "Graph-size scalability. Runtime is reported without repeated biomedical scoring because a discovery score cache was used to isolate graph-mining cost."
    (LATEX / "Figure2_graph_size_scalability.tex").write_text(figure_snippet("Figure2_graph_size_scalability.png", caption, "fig:graph-size-scalability"), encoding="utf-8")


def figure3() -> None:
    clique = pd.read_csv(RESULTS_ROOT / "experiments/exp05_clique_size_scalability/clique_size_scalability.csv")
    density = pd.read_csv(RESULTS_ROOT / "experiments/exp06_ppi_density_sensitivity/ppi_density_sensitivity.csv")
    pd.concat([clique.assign(source="clique_size"), density.assign(source="ppi_density")], ignore_index=True, sort=False).to_csv(FIGDATA / "Figure3_clique_size_density.csv", index=False)
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.2))
    for r, group in clique.groupby("r"):
        axes[0].plot(group["max_candidate_genes"], group["total_runtime_without_scoring"], marker="o", label=f"r={r}")
        axes[1].plot(group["max_candidate_genes"], group["enumerated_cliques"], marker="o", label=f"r={r}")
    axes[0].set_xlabel("max_candidate_genes")
    axes[0].set_ylabel("Runtime without scoring (s)")
    axes[1].set_xlabel("max_candidate_genes")
    axes[1].set_ylabel("Enumerated r-cliques")
    axes[0].legend(frameon=False)
    axes[1].legend(frameon=False)
    axes[2].plot(density["string_threshold"], density["enumerated_cliques"], marker="o", color="#444444")
    axes[2].set_xlabel("STRING threshold")
    axes[2].set_ylabel("Enumerated r=3 cliques")
    for ax, label in zip(axes, ["A", "B", "C"]):
        panel_label(ax, label)
    fig.tight_layout()
    fig.savefig(FIGURES / "Figure3_clique_size_density.png", dpi=220)
    plt.close(fig)
    caption = "Clique-size and PPI-density sensitivity. r=3, r=4, and r=5 settings are shown as observed, and stricter STRING filtering reduced clique counts while increasing average PPI confidence."
    (LATEX / "Figure3_clique_size_density.tex").write_text(figure_snippet("Figure3_clique_size_density.png", caption, "fig:clique-size-density"), encoding="utf-8")


def table2() -> pd.DataFrame:
    cand = pd.read_csv(RESULTS_ROOT / "experiments/exp07_candidate_reduction_ablation/candidate_reduction_ablation.csv")
    core = pd.read_csv(RESULTS_ROOT / "experiments/exp08_core_component_ablation/core_component_ablation.csv")
    mod = pd.read_csv(RESULTS_ROOT / "experiments/exp09_module_construction_ablation/module_construction_ablation.csv")
    rows = []
    for _, row in cand.iterrows():
        rows.append({"category": "Candidate reduction", "setting": row["setting"], "candidate_num_nodes": fmt(row.get("candidate_num_nodes"), 0), "candidate_num_edges_or_outputs": fmt(row.get("candidate_num_edges"), 0), "enumerated_cliques": fmt(row.get("enumerated_cliques"), 0), "runtime": fmt(row.get("runtime"), 2), "avg_module_score": fmt(row.get("avg_module_score"), 3), "avg_clique_coverage": fmt(row.get("avg_clique_coverage"), 3), "avg_string_confidence": fmt(row.get("avg_string_confidence"), 3), "avg_pairwise_jaccard": "NA", "key_observation": "Tractability and disease relevance change with reduction strategy."})
    for _, row in core.iterrows():
        rows.append({"category": "Core component", "setting": row["setting"], "candidate_num_nodes": fmt(row.get("candidate_num_nodes"), 0), "candidate_num_edges_or_outputs": fmt(row.get("candidate_num_edges"), 0), "enumerated_cliques": fmt(row.get("enumerated_cliques"), 0), "runtime": fmt(row.get("runtime"), 2), "avg_module_score": fmt(row.get("avg_module_score"), 3), "avg_clique_coverage": fmt(row.get("avg_clique_coverage"), 3), "avg_string_confidence": fmt(row.get("avg_string_confidence"), 3), "avg_pairwise_jaccard": fmt(row.get("avg_pairwise_jaccard"), 3), "key_observation": "Redundancy control and knowledge support affect diversity and interpretation."})
    for _, row in mod.iterrows():
        rows.append({"category": "Module construction", "setting": row["setting"], "candidate_num_nodes": "NA", "candidate_num_edges_or_outputs": fmt(row.get("num_outputs"), 0), "enumerated_cliques": "NA", "runtime": fmt(row.get("runtime_construction"), 2), "avg_module_score": fmt(row.get("avg_module_score"), 3), "avg_clique_coverage": fmt(row.get("avg_clique_coverage"), 3), "avg_string_confidence": fmt(row.get("avg_string_confidence"), 3), "avg_pairwise_jaccard": fmt(row.get("avg_pairwise_jaccard"), 3), "key_observation": "Full construction balances clique support and low redundancy."})
    out = pd.DataFrame(rows)
    save_table(out, "Table2_ablation_summary", "Ablation summary for candidate reduction, core components, and module construction.", "tab:ablation-summary")
    return out


def figure4(table: pd.DataFrame) -> None:
    table.to_csv(FIGDATA / "Figure4_ablation.csv", index=False)
    fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.4))
    cand = pd.read_csv(RESULTS_ROOT / "experiments/exp07_candidate_reduction_ablation/candidate_reduction_ablation.csv")
    core = pd.read_csv(RESULTS_ROOT / "experiments/exp08_core_component_ablation/core_component_ablation.csv")
    mod = pd.read_csv(RESULTS_ROOT / "experiments/exp09_module_construction_ablation/module_construction_ablation.csv")
    axes[0].bar(cand["setting"], cand["enumerated_cliques"], color="#6c8ebf")
    axes[0].set_ylabel("Enumerated cliques")
    axes[0].tick_params(axis="x", labelrotation=45)
    axes[1].bar(core["setting"], core["avg_clique_coverage"], color="#82b366")
    axes[1].set_ylabel("Avg clique coverage")
    axes[1].tick_params(axis="x", labelrotation=45)
    axes[2].bar(mod["setting"], mod["avg_pairwise_jaccard"], color="#999999")
    axes[2].set_ylabel("Avg pairwise Jaccard")
    axes[2].tick_params(axis="x", labelrotation=45)
    for ax, label in zip(axes, ["A", "B", "C"]):
        panel_label(ax, label)
    fig.tight_layout()
    fig.savefig(FIGURES / "Figure4_ablation.png", dpi=220)
    plt.close(fig)
    caption = "Ablation visualization. Candidate reduction controls clique explosion, component choices affect module support, and full module construction reduces redundancy relative to simpler construction variants."
    (LATEX / "Figure4_ablation.tex").write_text(figure_snippet("Figure4_ablation.png", caption, "fig:ablation"), encoding="utf-8")


def table3() -> pd.DataFrame:
    case = pd.read_csv(RESULTS_ROOT / "experiments/exp10_biomedical_case_study/biomedical_case_study_summary.csv")
    mods = pd.read_csv(DEFAULT_RUN_DIR / "modules/top_modules.csv")
    merged = case.merge(mods[["module_id", "size", "avg_string_score"]], on="module_id", how="left")
    interp = {"M001": "Collagen/ECM remodeling module.", "M002": "Immune-checkpoint module.", "M003": "Exploratory tRF/RBP-related module."}
    rows = []
    for _, row in merged.iterrows():
        genes = str(row["genes"]).split(";")
        rows.append({"module_id": row["module_id"], "representative_genes": ";".join(genes[:6]), "mechanism_category": row.get("mechanism_categories", "NA"), "size": fmt(row.get("size"), 0), "num_structural_cliques": fmt(row.get("structural_clique_count"), 0), "structural_clique_coverage": fmt(row.get("structural_clique_coverage"), 3), "avg_string_confidence": fmt(row.get("avg_string_score"), 3), "diagnostic_AUC": fmt(row.get("diagnostic_AUC"), 3), "survival_logrank_p": fmt(row.get("logrank_p"), 4), "short_interpretation": interp.get(row["module_id"], "Representative CliqueBio module.")})
    out = pd.DataFrame(rows)
    save_table(out, "Table3_representative_modules", "Representative CliqueBio modules in the LUAD case study.", "tab:representative-modules")
    return out


def figure5(table: pd.DataFrame) -> None:
    table.to_csv(FIGDATA / "Figure5_biomedical_case_study.csv", index=False)
    src = RESULTS_ROOT / "experiments/exp10_biomedical_case_study/figures/top_module_network_M001.png"
    dst = FIGURES / "Figure5_biomedical_case_study.png"
    if src.exists():
        shutil.copyfile(src, dst)
    else:
        fig, ax = plt.subplots(figsize=(4, 3))
        ax.axis("off")
        ax.text(0.5, 0.5, "Module network figure not available", ha="center", va="center")
        fig.savefig(dst, dpi=220)
        plt.close(fig)
    caption = "Biomedical case study. A representative LUAD module network is shown to evaluate scientific utility rather than to claim predictive superiority."
    (LATEX / "Figure5_biomedical_case_study.tex").write_text(figure_snippet("Figure5_biomedical_case_study.png", caption, "fig:biomedical-case-study"), encoding="utf-8")


def experimental_setup() -> None:
    md = """# Experimental Setup

We evaluated CliqueBio-Lung on TCGA-LUAD expression and endpoint data from UCSC Xena, together with STRING Homo sapiens physical protein-protein interaction (PPI) links. A small curated lung mechanism gene bank was used only as a knowledge-score source during discovery. External validation data were not used in these experiments.

The weighted graph was constructed from gene-level node scores and PPI-level edge scores. In the default setting, node scores combined differential expression, endpoint-derived diagnostic and survival evidence, and mechanism-bank support. The unused stability component was assigned zero weight, and the active components were renormalized. Leakage-reduced analysis removed the diagnostic and survival terms before graph construction and again renormalized the remaining active components. Edge scores combined STRING physical confidence, expression co-variation, and mechanism-category support. Candidate graphs were obtained by retaining high-scoring genes and high-confidence weighted PPI edges. CliqueBio then enumerated weighted r-clique seeds, expanded clique neighborhoods into size-constrained modules, and selected top modules with redundancy-aware filtering.

We compared four algorithmic variants for runtime analysis: NaiveEnum, DegEnum, DegEnum+TopSeed, and CliqueBio-Full. NaiveEnum exhaustively tested vertex combinations on small candidate graphs. DegEnum used degeneracy-order clique enumeration. DegEnum+TopSeed added top-seed retention. CliqueBio-Full added module construction and redundancy-aware top-k selection. Structural baselines such as top-weight genes, weighted k-core, and MCODE-like modules were used only for semantic and case-study comparison, not as runtime baselines for the clique-enumeration problem.

Primary graph-mining metrics included runtime without repeated scoring, enumerated cliques, candidate graph degeneracy, clique coverage, module score, redundancy, and average STRING confidence. Biomedical metrics, including diagnostic AUC, survival log-rank p value, C-index, and mechanism interpretation, were treated as auxiliary case-study context rather than independent validation.

The implementation is a Python prototype. A discovery scoring cache was used to avoid recomputing biomedical node and edge scores in every graph-mining experiment. All graph-mining experiments used cached node and edge scores, while varying graph size, clique size, PPI density, and ablation settings.
"""
    tex = md.replace("# Experimental Setup", "\\subsection{Experimental Setup}").replace("\n\n", "\n\n")
    (TEXT / "Experimental_Setup.md").write_text(md, encoding="utf-8")
    (LATEX / "Experimental_Setup.tex").write_text(tex, encoding="utf-8")


def results_draft() -> None:
    exp01 = pd.read_csv(RESULTS_ROOT / "experiments/exp01_problem_instance/problem_instance_stats.csv")
    exp02 = pd.read_csv(RESULTS_ROOT / "experiments/exp02_correctness/correctness_comparison.csv")
    exp04 = pd.read_csv(RESULTS_ROOT / "experiments/exp04_graph_size_scalability/graph_size_scalability.csv")
    exp07 = pd.read_csv(RESULTS_ROOT / "experiments/exp07_candidate_reduction_ablation/candidate_reduction_ablation.csv")
    exp09 = pd.read_csv(RESULTS_ROOT / "experiments/exp09_module_construction_ablation/module_construction_ablation.csv")
    case = pd.read_csv(RESULTS_ROOT / "experiments/exp10_biomedical_case_study/biomedical_case_study_summary.csv")
    md = f"""# Results Draft

## 5.2 Problem Instance Characterization

We first asked whether the real LUAD weighted PPI graph produced a non-trivial instance of the proposed clique-seeded mining problem. Across candidate sizes from 500 to 3000 genes and clique sizes r=3 and r=4, all ten tested settings completed successfully. Candidate graphs ranged from {fmt(exp01['candidate_num_nodes'].min(), 0)} to {fmt(exp01['candidate_num_nodes'].max(), 0)} nodes and from {fmt(exp01['candidate_num_edges'].min(), 0)} to {fmt(exp01['candidate_num_edges'].max(), 0)} edges.

The number of enumerated r-cliques increased with candidate size, reaching {fmt(exp01['num_r_cliques'].max(), 0)} cliques in the largest tested setting. Degeneracy ranged from {fmt(exp01['degeneracy'].min(), 0)} to {fmt(exp01['degeneracy'].max(), 0)}, indicating that the instance was sparse enough to be tractable but still contained substantial higher-order structure. These results support the problem formulation as a graph-mining task rather than a simple ranked-gene selection problem.

The main implication is that real disease-weighted PPI graphs contain enough clique-supported structure to justify higher-order module mining. At the same time, candidate reduction remains necessary because graph size and clique count grow rapidly with relaxed candidate limits.

## 5.3 Correctness and Runtime Efficiency

We next evaluated whether degeneracy-order enumeration preserved exact clique semantics relative to exhaustive subset testing. On small candidate graphs with max_candidate_genes values of 100, 150, and 200 and clique sizes r=3 and r=4, the optimized enumeration matched that reference in both clique set and top seed score. The median speedup relative to this reference was {fmt(exp02['speedup'].median(), 2)}x; this comparison does not assess superiority over specialized clique-enumeration algorithms.

Runtime comparison further separated the tested implementations. DegEnum and DegEnum+TopSeed were consistently faster than exhaustive subset testing, while CliqueBio-Full added module construction and redundancy-aware top-k selection. Structural baselines such as k-core, MCODE-like modules, and top-weight genes were excluded from this runtime comparison because they solve different structural problems.

These results establish a correctness baseline for the Python prototype. They also show that the optimized enumeration order provides a practical runtime advantage before adding module-level processing.

## 5.4 Scalability Analysis

We evaluated scalability along three axes: candidate graph size, clique size, and PPI density. For r=3 graph-size scaling, candidate nodes increased from {fmt(exp04['candidate_num_nodes'].min(), 0)} to {fmt(exp04['candidate_num_nodes'].max(), 0)}, candidate edges increased from {fmt(exp04['candidate_num_edges'].min(), 0)} to {fmt(exp04['candidate_num_edges'].max(), 0)}, and enumerated cliques increased from {fmt(exp04['enumerated_cliques'].min(), 0)} to {fmt(exp04['enumerated_cliques'].max(), 0)}. Runtime without repeated scoring increased from {fmt(exp04['total_runtime_without_scoring'].min(), 2)} s to {fmt(exp04['total_runtime_without_scoring'].max(), 2)} s.

Clique-size scaling showed that r=3, r=4, and r=5 settings completed for candidate sizes up to 1500 genes. PPI-density sensitivity showed that raising the STRING threshold to 900 reduced the r=3 clique count from 2610 to 1178 and increased average STRING confidence to 0.971. These results indicate that clique count and runtime respond predictably to graph size and edge-density constraints.

The scalability experiments support the use of a score cache to isolate graph-mining runtime from repeated biomedical scoring. The cache does not change the graph-mining problem; it prevents the same node and edge scores from being recomputed for every algorithmic setting.

## 5.5 Ablation Study

We used ablations to test whether candidate reduction, core components, and module construction contributed to the graph-mining objective. Full DiseaseAwareReduction produced a 949-node graph with 1907 edges and 2610 r=3 cliques. In contrast, the EdgeOnly setting expanded to {fmt(exp07.loc[exp07['setting']=='EdgeOnly','candidate_num_nodes'].iloc[0], 0)} nodes, {fmt(exp07.loc[exp07['setting']=='EdgeOnly','candidate_num_edges'].iloc[0], 0)} edges, and {fmt(exp07.loc[exp07['setting']=='EdgeOnly','enumerated_cliques'].iloc[0], 0)} cliques, increasing runtime to {fmt(exp07.loc[exp07['setting']=='EdgeOnly','runtime'].iloc[0], 2)} s.

Core component ablations showed that removing redundancy selection produced pairwise Jaccard overlap of 1.0, indicating duplicated module outputs. Module construction ablations showed that isolated cliques had perfect density but remained size-3 structures, whereas FullModuleConstruction produced modules of size {fmt(exp09.loc[exp09['setting']=='FullModuleConstruction','module_size_min'].iloc[0], 0)}-{fmt(exp09.loc[exp09['setting']=='FullModuleConstruction','module_size_max'].iloc[0], 0)} with average structural clique coverage {fmt(exp09.loc[exp09['setting']=='FullModuleConstruction','avg_clique_coverage'].iloc[0], 2)} and low average pairwise Jaccard overlap {fmt(exp09.loc[exp09['setting']=='FullModuleConstruction','avg_pairwise_jaccard'].iloc[0], 3)}.

These ablations support the design choice to mine clique-seeded modules rather than isolated cliques. They also show that candidate reduction and redundancy-aware selection are necessary to keep the outputs tractable and diverse.

## 5.6 Biomedical Case Study

    Finally, we used representative LUAD modules to assess scientific utility. The collagen/ECM module M001 contained COL11A1, COL1A1, COL1A2, COL3A1, COL5A1, and COL5A2, with {fmt(case.loc[case['module_id']=='M001','structural_clique_count'].iloc[0], 0)} structural cliques and diagnostic AUC {fmt(case.loc[case['module_id']=='M001','diagnostic_AUC'].iloc[0], 3)}. The immune-checkpoint module M002 included CD274, CTLA4, HAVCR2, PDCD1, and PDCD1LG2. The exploratory tRF/RBP module M003 showed log-rank p value {fmt(case.loc[case['module_id']=='M003','logrank_p'].iloc[0], 4)}.

These biomedical metrics provide auxiliary context for hypothesis-generating modules with interpretable lung-cancer mechanisms. They are not independent validation or evidence of predictive superiority, because the main optimization target of CliqueBio-Lung is higher-order weighted PPI module mining rather than classifier benchmarking.

The case study provides a bridge between the algorithmic objective and scientific use. It shows that compact clique-supported modules can be biologically interpretable while retaining graph-mining properties such as clique support, PPI confidence, and low redundancy.
"""
    tex = md.replace("# Results Draft", "\\section{Results}").replace("## ", "\\subsection{")
    tex = "\n".join(line + "}" if line.startswith("\\subsection{") else line for line in tex.splitlines())
    (TEXT / "Results_Draft.md").write_text(md, encoding="utf-8")
    (LATEX / "Results_Draft.tex").write_text(tex, encoding="utf-8")


def captions() -> None:
    exp02 = pd.read_csv(RESULTS_ROOT / "experiments/exp02_correctness/correctness_comparison.csv")
    median_speedup = exp02["speedup"].median()
    md = f"""# Figure and Table Captions

**Table 1. Graph instance statistics.** Statistics of weighted PPI graph instances under different candidate sizes and clique sizes. The table reports candidate graph size, density, degeneracy, r-clique count, average STRING confidence, and enumeration time, showing that the real LUAD problem instance is non-trivial but tractable after candidate reduction.

**Figure 1. Correctness and runtime efficiency.** Panel A compares exhaustive subset testing with degeneracy-order enumeration on small candidate graphs. Panel B summarizes speedup relative to exhaustive subset testing. Optimized enumeration matched this reference in clique set and top seed score, with a median exact-check speedup of {median_speedup:.2f}x; the comparison does not cover specialized clique-enumeration algorithms.

**Figure 2. Graph-size scalability.** Runtime without repeated scoring, enumerated cliques, and degeneracy are shown as max_candidate_genes increases. A discovery score cache was used only to isolate graph-mining runtime from repeated biomedical score computation.

**Figure 3. Clique-size and PPI-density sensitivity.** Panels show runtime and clique count for r=3, r=4, and r=5, together with the effect of STRING confidence threshold. The results report observed behavior directly, including sparse or dense settings, rather than tuning parameters to optimize biomedical metrics.

**Table 2. Ablation summary.** Candidate reduction, core component, and module construction ablations are summarized in one main-text table. The table emphasizes tractability, clique support, redundancy, and structural quality rather than predictive ranking.

**Figure 4. Ablation visualization.** The visualization highlights how candidate reduction controls clique explosion, how core components affect module support, and how full module construction reduces redundancy relative to simpler construction variants.

**Table 3. Representative biomedical modules.** Three representative LUAD modules are listed with genes, mechanism categories, clique support, PPI confidence, diagnostic AUC, and survival evidence. Biomedical metrics are reported as case-study evidence rather than as the primary optimization target.

**Figure 5. Biomedical case study.** A representative module network illustrates the scientific utility of clique-supported PPI modules. The figure is used to show interpretability and mechanism support, not to claim predictive superiority.
"""
    tex = md.replace("# Figure and Table Captions", "\\section*{Figure and Table Captions}").replace("**", "")
    (TEXT / "Figure_Table_Captions.md").write_text(md, encoding="utf-8")
    (LATEX / "Figure_Table_Captions.tex").write_text(tex, encoding="utf-8")


def manifest() -> None:
    rows = []
    assets = [
        ("Table1_graph_instance_statistics", "table", "Exp 1", "results/experiments/exp01_problem_instance/problem_instance_stats.csv", "manuscript_assets/tables/Table1_graph_instance_statistics.md", "Main text Table 1", "ready", "Graph instance statistics."),
        ("Figure1_correctness_runtime", "figure", "Exp 2 + Exp 3", "results/experiments/exp02_correctness; results/experiments/exp03_runtime_baseline", "manuscript_assets/figures/Figure1_correctness_runtime.png", "Main text Figure 1", "ready", "Correctness and runtime efficiency."),
        ("Figure2_graph_size_scalability", "figure", "Exp 4", "results/experiments/exp04_graph_size_scalability/graph_size_scalability.csv", "manuscript_assets/figures/Figure2_graph_size_scalability.png", "Main text Figure 2", "ready", "Graph-size scalability."),
        ("Figure3_clique_size_density", "figure", "Exp 5 + Exp 6", "results/experiments/exp05_clique_size_scalability; results/experiments/exp06_ppi_density_sensitivity", "manuscript_assets/figures/Figure3_clique_size_density.png", "Main text Figure 3", "ready", "Clique-size and PPI-density sensitivity."),
        ("Table2_ablation_summary", "table", "Exp 7 + Exp 8 + Exp 9", "results/experiments/exp07; exp08; exp09", "manuscript_assets/tables/Table2_ablation_summary.md", "Main text Table 2", "ready", "Ablation summary."),
        ("Figure4_ablation", "figure", "Exp 7 + Exp 8 + Exp 9", "results/experiments/exp07; exp08; exp09", "manuscript_assets/figures/Figure4_ablation.png", "Main text Figure 4", "ready", "Ablation visualization."),
        ("Table3_representative_modules", "table", "Exp 10", "results/experiments/exp10_biomedical_case_study/biomedical_case_study_summary.csv", "manuscript_assets/tables/Table3_representative_modules.md", "Main text Table 3", "ready", "Representative biomedical modules."),
        ("Figure5_biomedical_case_study", "figure", "Exp 10", "results/experiments/exp10_biomedical_case_study/figures", "manuscript_assets/figures/Figure5_biomedical_case_study.png", "Main text Figure 5", "ready", "Representative module network."),
        ("Experimental_Setup", "text", "All experiments", "results/experiments", "manuscript_assets/text/Experimental_Setup.md", "Section 5.1", "draft", "Requires author review for journal-specific style."),
        ("Results_Draft", "text", "All experiments", "results/experiments", "manuscript_assets/text/Results_Draft.md", "Sections 5.2-5.6", "draft", "Numbers are extracted from CSV outputs."),
        ("Figure_Table_Captions", "text", "All experiments", "results/experiments", "manuscript_assets/text/Figure_Table_Captions.md", "Captions", "draft", "Requires final figure numbering check."),
    ]
    for asset in assets:
        rows.append(dict(zip(["asset_name", "asset_type", "source_experiment", "source_file", "output_file", "intended_paper_location", "status", "notes"], asset)))
    with open(ROOT / "MANUSCRIPT_ASSET_MANIFEST.csv", "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    readme = """# Manuscript Assets

This directory contains manuscript-ready assets generated from the Phase 1.8 computer-science experiment suite.

- `tables/`: Markdown main-text tables.
- `figures/`: PNG figures for the manuscript draft.
- `figure_data/`: CSV files used to draw each figure.
- `table_data/`: CSV files used to prepare each table.
- `text/`: Experimental setup, Results draft, and captions.
- `latex/`: Copyable LaTeX table and figure snippets.

The organization follows the main-text Results structure: Experimental Setup, Problem Instance Characterization, Correctness and Runtime Efficiency, Scalability Analysis, Ablation Study, and Biomedical Case Study.
"""
    (ROOT / "README.md").write_text(readme, encoding="utf-8")


def main() -> None:
    ensure_dirs()
    table1()
    figure1()
    figure2()
    figure3()
    t2 = table2()
    figure4(t2)
    t3 = table3()
    figure5(t3)
    experimental_setup()
    results_draft()
    captions()
    manifest()
    print(ROOT)


if __name__ == "__main__":
    main()
