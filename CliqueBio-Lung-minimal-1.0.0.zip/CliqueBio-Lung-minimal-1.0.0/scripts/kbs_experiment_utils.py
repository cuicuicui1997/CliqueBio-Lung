from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import networkx as nx
import numpy as np
import pandas as pd

from src.utils import split_gene_list
from src.canonical import canonical_component, canonical_induced_edges, gene_key, vertex_key
from src.structural_metrics import structural_clique_metrics


RANDOM_SEED = 2026


def jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / len(a | b) if a or b else 0.0


def average_pairwise_jaccard(modules: pd.DataFrame) -> float:
    sets = [set(split_gene_list(value)) for value in modules.get("genes", [])]
    values = [jaccard(a, b) for i, a in enumerate(sets) for b in sets[i + 1 :]]
    return float(np.mean(values)) if values else 0.0


def seed_index(seeds: pd.DataFrame) -> tuple[dict[str, set[str]], dict[str, float]]:
    sets = {
        str(row.seed_id): set(split_gene_list(row.genes))
        for row in seeds.itertuples(index=False)
    }
    scores = dict(zip(seeds["seed_id"].astype(str), seeds["final_seed_score"].astype(float)))
    return sets, scores


def expand_connected(
    graph: nx.Graph,
    genes: Iterable[str],
    min_size: int,
    max_size: int,
    allowed: set[str] | None = None,
) -> set[str]:
    selected = set(genes) & set(graph)
    allowed_nodes = set(graph) if allowed is None else set(allowed) & set(graph)
    if not selected:
        return set()
    if not nx.is_connected(graph.subgraph(selected)):
        selected = canonical_component(nx.connected_components(graph.subgraph(selected)))
    while len(selected) > max_size:
        removable = [
            node for node in selected
            if len(selected) == 1 or nx.is_connected(graph.subgraph(selected - {node}))
        ]
        if not removable:
            break
        selected.remove(min(removable, key=lambda node: (
            graph.nodes[node].get("final_node_score", 0.0), graph.degree(node), node
        )))
    while len(selected) < min_size:
        boundary = set().union(*(set(graph.neighbors(node)) for node in selected))
        boundary = (boundary & allowed_nodes) - selected
        if not boundary:
            break
        best = sorted(boundary, key=lambda node: (
            -(graph.nodes[node].get("final_node_score", 0.0)
              + np.mean([
                  graph.edges[node, old].get("final_edge_score", 0.0)
                  for old in sorted(selected, key=gene_key) if graph.has_edge(node, old)
              ] or [0.0])),
            gene_key(node),
        ))[0]
        selected.add(best)
    return selected


def module_row(
    graph: nx.Graph,
    genes: Iterable[str],
    seed_sets: dict[str, set[str]],
    seed_scores: dict[str, float],
) -> dict[str, float | int | str]:
    gene_set = set(genes)
    supporting = [sid for sid, seed in seed_sets.items() if seed.issubset(gene_set)]
    sub = graph.subgraph(gene_set)
    ordered_genes = vertex_key(gene_set)
    edges = canonical_induced_edges(graph, ordered_genes)
    node_score = float(np.mean([
        graph.nodes[g].get("final_node_score", 0.0) for g in ordered_genes
    ])) if gene_set else 0.0
    edge_score = float(np.mean([
        data.get("final_edge_score", 0.0) for _, _, data in edges
    ])) if edges else 0.0
    string_score = float(np.mean([
        data.get("STRING_score", 0.0) for _, _, data in edges
    ])) if edges else 0.0
    r = len(next(iter(seed_sets.values()))) if seed_sets else 3
    structural = structural_clique_metrics(gene_set, graph, r)
    coverage = float(structural["structural_clique_coverage"])
    knowledge = [g for g in ordered_genes if graph.nodes[g].get("Knowledge_score", 0.0) > 0]
    bio = len(knowledge) / len(gene_set) if gene_set else 0.0
    mean_seed = float(np.mean([seed_scores[sid] for sid in supporting])) if supporting else 0.0
    seed_support = 0.5 * len(supporting) / max(1, len(seed_sets)) + 0.5 * mean_seed
    score = 0.30 * seed_support + 0.25 * node_score + 0.20 * edge_score + 0.15 * coverage + 0.10 * bio
    return {
        "genes": ";".join(sorted(gene_set)),
        "size": len(gene_set),
        "module_score": float(score),
        "avg_node_score": node_score,
        "avg_edge_score": edge_score,
        "avg_string_score": string_score,
        "ppi_density": nx.density(sub) if len(gene_set) > 1 else 0.0,
        "clique_coverage": coverage,
        "structural_clique_coverage": coverage,
        "structural_clique_count": int(structural["structural_clique_count"]),
        "num_clique_seeds": len(supporting),
        "mechanism_gene_fraction": bio,
    }


def select_candidates(
    method: str,
    graph: nx.Graph,
    candidates: Iterable[Iterable[str]],
    seeds: pd.DataFrame,
    min_size: int,
    max_size: int,
    budget: int,
    redundancy_threshold: float,
) -> pd.DataFrame:
    seed_sets, seed_scores = seed_index(seeds)
    unique: dict[tuple[str, ...], dict] = {}
    for genes in candidates:
        normalized = expand_connected(graph, genes, min_size, max_size)
        if len(normalized) < min_size or len(normalized) > max_size:
            continue
        if not nx.is_connected(graph.subgraph(normalized)):
            continue
        key = tuple(sorted(normalized))
        unique[key] = module_row(graph, normalized, seed_sets, seed_scores)
    ranked = sorted(unique.values(), key=lambda row: (-row["module_score"], vertex_key(split_gene_list(row["genes"]))))
    selected: list[dict] = []
    selected_sets: list[set[str]] = []
    for row in ranked:
        genes = set(split_gene_list(row["genes"]))
        max_overlap = max((jaccard(genes, old) for old in selected_sets), default=0.0)
        if max_overlap >= redundancy_threshold:
            continue
        selected.append({"method": method, "module_id": f"{method}_{len(selected)+1:02d}", **row})
        selected_sets.append(genes)
        if len(selected) >= budget:
            break
    return pd.DataFrame(selected)


def summarize_method(method: str, modules: pd.DataFrame, runtime: float) -> dict:
    numeric = lambda column: pd.to_numeric(modules.get(column, pd.Series(dtype=float)), errors="coerce")
    return {
        "method": method,
        "avg_module_score": numeric("module_score").mean(),
        "avg_node_score": numeric("avg_node_score").mean(),
        "avg_string_confidence": numeric("avg_string_score").mean(),
        "avg_ppi_density": numeric("ppi_density").mean(),
        "avg_clique_coverage": numeric("structural_clique_coverage").mean(),
        "avg_structural_clique_coverage": numeric("structural_clique_coverage").mean(),
        "avg_pairwise_jaccard": average_pairwise_jaccard(modules),
        "runtime_seconds": float(runtime),
        "returned_modules": int(len(modules)),
    }


def write_json(path: Path, payload: dict | list) -> None:
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
