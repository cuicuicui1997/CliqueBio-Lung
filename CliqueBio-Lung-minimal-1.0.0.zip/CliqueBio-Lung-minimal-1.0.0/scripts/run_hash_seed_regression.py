from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


HASH_SEEDS = (0, 1, 7, 42, 2026)
ARTIFACTS = (
    "retained_seeds.json",
    "seed_adjacency.json",
    "candidate_modules.json",
    "selected_modules.json",
    "module_q_prod.json",
    "table2_default.json",
    "leakage_reduced.json",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/phase1_luad.yaml")
    parser.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    parser.add_argument("--output-dir", default="reports/formal_consistency_fix/hash_seed_regression")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    out = root / args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    runs = {}
    for seed in HASH_SEEDS:
        run_dir = out / f"hash_seed_{seed}"
        run_dir.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env["PYTHONHASHSEED"] = str(seed)
        command = [
            sys.executable,
            str(root / "scripts" / "hash_seed_worker.py"),
            "--config", args.config,
            "--cache-dir", args.cache_dir,
            "--output-dir", str(run_dir),
        ]
        completed = subprocess.run(command, cwd=root, env=env, text=True, capture_output=True)
        (run_dir / "stdout.txt").write_text(completed.stdout, encoding="utf-8")
        (run_dir / "stderr.txt").write_text(completed.stderr, encoding="utf-8")
        if completed.returncode:
            raise SystemExit(f"hash seed {seed} failed with exit code {completed.returncode}: {completed.stderr}")
        runs[str(seed)] = {artifact: sha256(run_dir / artifact) for artifact in ARTIFACTS}
    invariant = all(
        len({runs[str(seed)][artifact] for seed in HASH_SEEDS}) == 1
        for artifact in ARTIFACTS
    )
    summary = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "status": "HASH_SEED_INVARIANT" if invariant else "HASH_SEED_REGRESSION_FAILED",
        "hash_seeds": HASH_SEEDS,
        "artifacts": ARTIFACTS,
        "sha256": runs,
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    report = [
        "# Determinism Audit",
        "",
        f"Status: `{summary['status']}`",
        "",
        "Five fresh Python subprocesses used `PYTHONHASHSEED=0,1,7,42,2026` with the frozen cache and unchanged Phase 1 configuration.",
        "",
        "| Artifact | Invariant | SHA-256 |",
        "|---|---:|---|",
    ]
    for artifact in ARTIFACTS:
        values = {runs[str(seed)][artifact] for seed in HASH_SEEDS}
        report.append(f"| {artifact} | {'yes' if len(values) == 1 else 'no'} | `{sorted(values)[0]}` |")
    report.extend([
        "",
        "Runtime values, timestamps, stdout, and stderr are excluded from normalized scientific artifacts. Candidate records retain module, source-seed, provenance, production-score, and structural-metric fields.",
        "",
    ])
    report_path = out.parent / "DETERMINISM_AUDIT.md"
    report_path.write_text("\n".join(report), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    if not invariant:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
