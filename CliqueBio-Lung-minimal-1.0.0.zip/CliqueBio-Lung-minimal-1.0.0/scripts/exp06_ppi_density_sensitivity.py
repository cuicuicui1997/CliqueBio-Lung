from __future__ import annotations

import argparse
import pandas as pd

from experiment_utils import exp_dir, load_cached_inputs, run_cached_setting, module_summary, write_report


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/phase1_luad.yaml")
    p.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    args = p.parse_args()
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    rows = []
    for thr in [400, 700, 900]:
        try:
            res = run_cached_setting(cfg, cache, {"candidate_graph.string_threshold": thr, "candidate_graph.max_candidate_genes": 1500}, 3)
            s = res["graph_stats"].iloc[0]; ms = module_summary(res["modules"])
            rows.append({"string_threshold": thr, "candidate_num_nodes": s["candidate_num_nodes"], "candidate_num_edges": s["candidate_num_edges"], "density": s["density"], "degeneracy": s["degeneracy"], "enumerated_cliques": res["enum_meta"]["num_enumerated_cliques"], "retained_seeds": res["enum_meta"]["num_retained_seeds"], **ms, "enumeration_time": res["enum_meta"]["runtime_enum"], "total_runtime_without_scoring": res["total"], "status": "success", "notes": ""})
        except Exception as exc:
            rows.append({"string_threshold": thr, "status": "failed", "notes": str(exc)})
    out = exp_dir("exp06_ppi_density_sensitivity")
    df = pd.DataFrame(rows); df.to_csv(out / "ppi_density_sensitivity.csv", index=False)
    write_report(out / "PPI_DENSITY_SENSITIVITY_REPORT.md", "Exp 6 PPI Density Sensitivity", "This experiment varies STRING threshold to observe how denser or sparser PPI filtering changes clique counts, runtime, and structural module quality.")


if __name__ == "__main__":
    main()
