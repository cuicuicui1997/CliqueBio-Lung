from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import pandas as pd

from experiment_utils import exp_dir, write_report


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--run-dir", default="results/runs/phase1_luad_real_LUAD_r3_20260702_190229")
    args = p.parse_args()
    run_dir = Path(args.run_dir)
    out = exp_dir("exp10_biomedical_case_study")
    (out / "figures").mkdir(exist_ok=True)
    modules = pd.read_csv(run_dir / "modules" / "top_modules.csv").head(3)
    eval_df = pd.read_csv(run_dir / "metrics" / "module_evaluation.csv")
    rows = []
    for _, row in modules.iterrows():
        ev = eval_df[eval_df["module_id"] == row["module_id"]].head(1)
        e = ev.iloc[0].to_dict() if not ev.empty else {}
        rows.append({"module_id": row["module_id"], "genes": row["genes"], "provenance_seed_count": row.get("num_provenance_seeds"), "structural_clique_count": row.get("structural_clique_count"), "structural_clique_coverage": row.get("structural_clique_coverage"), "mechanism_categories": row.get("mechanism_categories"), "diagnostic_AUC": e.get("AUC"), "logrank_p": e.get("logrank_p"), "hazard_ratio": e.get("hazard_ratio"), "c_index": e.get("c_index")})
    pd.DataFrame(rows).to_csv(out / "biomedical_case_study_summary.csv", index=False)
    for fig in (run_dir / "figures").glob("top_module_network*.png"):
        shutil.copyfile(fig, out / "figures" / fig.name)
        break
    write_report(out / "BIOMEDICAL_CASE_STUDY_REPORT.md", "Exp 10 Biomedical Case Study", "Top 2-3 representative CliqueBio modules are summarized with gene lists, supporting cliques, mechanism categories, diagnostic AUC, and survival metrics. These biomedical metrics are case-study evidence, not the primary optimization target.")


if __name__ == "__main__":
    main()
