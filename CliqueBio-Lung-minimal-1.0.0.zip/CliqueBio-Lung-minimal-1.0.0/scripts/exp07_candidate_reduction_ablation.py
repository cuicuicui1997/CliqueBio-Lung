from __future__ import annotations

import argparse
import pandas as pd

from experiment_utils import exp_dir, load_cached_inputs, run_cached_setting, module_summary, write_report


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/phase1_luad.yaml")
    p.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    args = p.parse_args()
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    settings = {
        "Full DiseaseAwareReduction": {},
        "NodeOnly": {"edge_scoring.weights.STRING_score": 0.0, "edge_scoring.weights.CoExpr_score": 0.0, "edge_scoring.weights.Pathway_score": 0.0, "candidate_graph.min_edge_score": 0.0},
        "EdgeOnly": {"candidate_graph.keep_top_node_score_genes": False, "candidate_graph.always_keep_knowledge_genes": False},
        "NoKnowledge": {},
        "RelaxedReduction": {"candidate_graph.max_candidate_genes": 3000, "candidate_graph.min_edge_score": 0.3},
    }
    rows = []
    for name, overrides in settings.items():
        local_cache = dict(cache)
        if name == "NoKnowledge":
            mech = cache["mechanism"].iloc[0:0].copy()
            local_cache["mechanism"] = mech
        overrides = {"candidate_graph.max_candidate_genes": 1500, **overrides}
        try:
            res = run_cached_setting(cfg, local_cache, overrides, 3)
            s = res["graph_stats"].iloc[0]; ms = module_summary(res["modules"])
            rows.append({"setting": name, "candidate_num_nodes": s["candidate_num_nodes"], "candidate_num_edges": s["candidate_num_edges"], "reduction_node_ratio": s["reduction_node_ratio"], "reduction_edge_ratio": s["reduction_edge_ratio"], "density": s["density"], "degeneracy": s["degeneracy"], "enumerated_cliques": res["enum_meta"]["num_enumerated_cliques"], "runtime": res["total"], **ms, "status": "success", "notes": ""})
        except Exception as exc:
            rows.append({"setting": name, "status": "failed", "notes": str(exc)})
    out = exp_dir("exp07_candidate_reduction_ablation")
    df = pd.DataFrame(rows); df.to_csv(out / "candidate_reduction_ablation.csv", index=False)
    write_report(out / "CANDIDATE_REDUCTION_ABLATION_REPORT.md", "Exp 7 Candidate Reduction Ablation", "Candidate reduction is evaluated as a way to transform the large weighted PPI instance into a tractable disease-relevant subproblem, not as a way to optimize AUC.")


if __name__ == "__main__":
    main()
