from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from experiment_utils import build_graph_from_cache, load_cached_inputs
from kbs_experiment_utils import select_candidates, summarize_method
from run_baseline_comparison import (
    k_core_candidates,
    mcode_like_candidates,
    percolation_candidates,
    top_weight_candidates,
    triangle_candidates,
)
from run_robustness_bootstrap import leakage_reduced_nodes
from src.clique_enum import enumerate_top_r_cliques
from src.module_builder import build_modules, build_seed_adjacency
from src.pipeline import apply_overrides
from src.scoring import label_vectors
from src.utils import set_random_seed, split_gene_list


def clean(value):
    if isinstance(value, dict):
        return {str(key): clean(item) for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))}
    if isinstance(value, (list, tuple)):
        return [clean(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not math.isfinite(float(value)) else float(value)
    if pd.isna(value):
        return None
    return value


def write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(clean(payload), sort_keys=True, separators=(",", ":"), ensure_ascii=False), encoding="utf-8")


def records(frame: pd.DataFrame) -> list[dict]:
    return clean(frame.to_dict(orient="records"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/phase1_luad.yaml")
    parser.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    set_random_seed(2026)
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    graph, _ = build_graph_from_cache(cfg, cache, {"candidate_graph.max_candidate_genes": 1500})
    r = int(cfg["clique"]["r"])
    seeds, _ = enumerate_top_r_cliques(graph, r, int(cfg["clique"]["max_clique_seeds"]))
    write_json(out / "retained_seeds.json", records(seeds))

    seed_sets = {
        str(row.seed_id): set(split_gene_list(row.genes))
        for row in seeds.itertuples(index=False)
    }
    module_cfg = cfg["module"]
    adjacency, pairs = build_seed_adjacency(
        graph,
        seed_sets,
        r,
        float(module_cfg["clique_jaccard_threshold"]),
        int(module_cfg["min_cross_edges"]),
        int(module_cfg["max_pair_checks"]),
    )
    write_json(out / "seed_adjacency.json", {
        "pairs": pairs,
        "adjacency": {seed_id: sorted(neighbors) for seed_id, neighbors in sorted(adjacency.items())},
    })

    pool_cfg = apply_overrides(cfg, {"module.top_B_modules": 500, "module.top_b": 500})
    candidates, _ = build_modules(graph, seeds, pool_cfg, no_expansion=False, redundancy=False)
    selected, _ = build_modules(graph, seeds, cfg, no_expansion=False, redundancy=True)
    write_json(out / "candidate_modules.json", records(candidates))
    write_json(out / "selected_modules.json", records(selected))
    write_json(out / "module_q_prod.json", [
        {"genes": row.genes, "source_seed_id": row.source_seed_id, "q_prod": row.q_prod}
        for row in candidates.itertuples(index=False)
    ])

    min_size = int(module_cfg["min_module_size"])
    max_size = int(module_cfg["max_module_size"])
    budget = int(module_cfg.get("top_B_modules", 10))
    tau = float(module_cfg.get("redundancy_threshold", 0.5))
    target_size = min_size
    table_modules = [selected.assign(method="CliqueBio")]
    table_summary = [summarize_method("CliqueBio", selected, 0.0)]
    methods = [
        ("TopWeight", top_weight_candidates(graph, target_size)),
        ("k-core", k_core_candidates(graph, target_size)),
        ("TriangleSupport", triangle_candidates(graph, target_size)),
        ("CliquePercolation", percolation_candidates(graph, r)),
        ("MCODE-like", mcode_like_candidates(graph, target_size)),
    ]
    for name, method_candidates in methods:
        modules = select_candidates(name, graph, method_candidates, seeds, min_size, max_size, budget, tau)
        table_modules.append(modules)
        table_summary.append(summarize_method(name, modules, 0.0))
    write_json(out / "table2_default.json", {
        "modules": records(pd.concat(table_modules, ignore_index=True, sort=False)),
        "summary": clean(table_summary),
    })

    samples, labels = label_vectors(cache["metadata"], cfg, list(cache["expression"].columns))
    tumor = [sample for sample, label in zip(samples, labels) if label == 1]
    normal = [sample for sample, label in zip(samples, labels) if label == 0]
    local_cache = dict(cache)
    local_cache["node_scores"] = leakage_reduced_nodes(cache, tumor, normal, cfg)
    leakage_graph, _ = build_graph_from_cache(cfg, local_cache, {"candidate_graph.max_candidate_genes": 1500})
    leakage_seeds, _ = enumerate_top_r_cliques(leakage_graph, r, int(cfg["clique"]["max_clique_seeds"]))
    leakage_modules, _ = build_modules(leakage_graph, leakage_seeds, cfg, no_expansion=False, redundancy=True)
    write_json(out / "leakage_reduced.json", {
        "seeds": records(leakage_seeds),
        "modules": records(leakage_modules),
    })


if __name__ == "__main__":
    main()
