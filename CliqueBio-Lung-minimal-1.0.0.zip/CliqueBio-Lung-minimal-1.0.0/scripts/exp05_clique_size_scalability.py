from __future__ import annotations

import argparse
import signal
import pandas as pd

from experiment_utils import exp_dir, load_cached_inputs, run_cached_setting, module_summary, write_report


class TimeoutError(Exception):
    pass


def handler(signum, frame):
    raise TimeoutError()


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/phase1_luad.yaml")
    p.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    p.add_argument("--timeout-minutes", type=int, default=60)
    args = p.parse_args()
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    rows = []
    if hasattr(signal, "SIGALRM"):
        signal.signal(signal.SIGALRM, handler)
    for r in [3, 4, 5]:
        for max_genes in [500, 1000, 1500]:
            try:
                if hasattr(signal, "alarm"):
                    signal.alarm(args.timeout_minutes * 60)
                res = run_cached_setting(cfg, cache, {"candidate_graph.max_candidate_genes": max_genes}, r)
                if hasattr(signal, "alarm"):
                    signal.alarm(0)
                s = res["graph_stats"].iloc[0]; ms = module_summary(res["modules"])
                sizes = pd.to_numeric(res["modules"].get("size", pd.Series(dtype=float)), errors="coerce")
                rows.append({"r": r, "max_candidate_genes": max_genes, "candidate_num_nodes": s["candidate_num_nodes"], "candidate_num_edges": s["candidate_num_edges"], "degeneracy": s["degeneracy"], "enumerated_cliques": res["enum_meta"]["num_enumerated_cliques"], "retained_seeds": res["enum_meta"]["num_retained_seeds"], **ms, "module_size_min": sizes.min(), "module_size_max": sizes.max(), "enumeration_time": res["enum_meta"]["runtime_enum"], "total_runtime_without_scoring": res["total"], "status": "success", "notes": ""})
            except TimeoutError:
                rows.append({"r": r, "max_candidate_genes": max_genes, "status": "timeout", "notes": f"timeout after {args.timeout_minutes} minutes"})
            except Exception as exc:
                rows.append({"r": r, "max_candidate_genes": max_genes, "status": "failed", "notes": str(exc)})
    out = exp_dir("exp05_clique_size_scalability")
    df = pd.DataFrame(rows); df.to_csv(out / "clique_size_scalability.csv", index=False)
    write_report(out / "CLIQUE_SIZE_SCALABILITY_REPORT.md", "Exp 5 Clique-Size Scalability", f"Completed status counts:\n\n```text\n{df['status'].value_counts().to_string()}\n```\n\nr=5 failures, zero-clique settings, or timeouts are retained as scalability evidence.")


if __name__ == "__main__":
    main()
