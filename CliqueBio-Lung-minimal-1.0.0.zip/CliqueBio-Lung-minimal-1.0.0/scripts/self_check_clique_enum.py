from __future__ import annotations

import itertools
import sys
from pathlib import Path

import networkx as nx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.clique_enum import enumerate_top_r_cliques
from src.scoring import clique_score
from src.utils import split_gene_list


def build_test_graph() -> nx.Graph:
    g = nx.Graph()
    nodes = list("ABCDEF")
    for i, node in enumerate(nodes):
        g.add_node(
            node,
            final_node_score=(i + 1) / 10,
            Stability_score=float("nan"),
            Knowledge_score=1.0 if node in {"A", "B"} else 0.0,
            mechanism_categories="test" if node in {"A", "B"} else "",
        )
    edges = [
        ("A", "B"), ("A", "C"), ("B", "C"),
        ("A", "D"), ("B", "D"), ("C", "D"),
        ("C", "E"), ("D", "E"),
        ("D", "F"), ("E", "F"), ("C", "F"),
    ]
    for i, (u, v) in enumerate(edges):
        score = 0.55 + i * 0.03
        g.add_edge(u, v, final_edge_score=score, STRING_score=score, CoExpr_score=score, Pathway_score=0.0)
    return g


def brute_force_cliques(graph: nx.Graph, r: int) -> set[tuple[str, ...]]:
    out = set()
    for combo in itertools.combinations(sorted(graph.nodes()), r):
        if all(graph.has_edge(u, v) for u, v in itertools.combinations(combo, 2)):
            out.add(tuple(combo))
    return out


def from_result(df) -> set[tuple[str, ...]]:
    return {tuple(sorted(split_gene_list(value))) for value in df["genes"]}


def assert_equal(name: str, left, right) -> None:
    if left != right:
        raise AssertionError(f"{name} mismatch\nleft={sorted(left)}\nright={sorted(right)}")


def main() -> None:
    graph = build_test_graph()
    for r in (3, 4):
        expected = brute_force_cliques(graph, r)
        seeds, meta = enumerate_top_r_cliques(graph, r, max_clique_seeds=100)
        actual = from_result(seeds)
        assert_equal(f"r={r} brute force", actual, expected)
        if len(actual) != len(seeds):
            raise AssertionError(f"r={r} produced duplicate cliques")
        nx_expected = {
            tuple(sorted(c))
            for c in nx.enumerate_all_cliques(graph)
            if len(c) == r
        }
        assert_equal(f"r={r} networkx", actual, nx_expected)
        scores = list(seeds["final_seed_score"])
        if scores != sorted(scores, reverse=True):
            raise AssertionError(f"r={r} seed scores are not sorted descending")
        if meta["num_enumerated_cliques"] != len(expected):
            raise AssertionError(f"r={r} enumeration count mismatch")

    all_r3 = brute_force_cliques(graph, 3)
    top2, _ = enumerate_top_r_cliques(graph, 3, max_clique_seeds=2)
    expected_top2 = sorted(
        all_r3,
        key=lambda genes: clique_score(genes, graph)["final_seed_score"],
        reverse=True,
    )[:2]
    assert_equal("top-K truncation", from_result(top2), set(expected_top2))
    print("Clique enumeration self-check PASS")
    print("r=3 cliques:", len(all_r3))
    print("r=4 cliques:", len(brute_force_cliques(graph, 4)))


if __name__ == "__main__":
    main()
