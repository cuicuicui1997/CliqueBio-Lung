from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

import networkx as nx
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from experiment_utils import build_graph_from_cache, load_cached_inputs
from kbs_experiment_utils import RANDOM_SEED, select_candidates, summarize_method, write_json
from src.clique_enum import enumerate_top_r_cliques
from src.module_builder import build_modules
from src.pipeline import apply_overrides
from src.utils import set_random_seed
from src.canonical import gene_key


def greedy_connected(graph: nx.Graph, seed: str, size: int, allowed: set[str] | None = None) -> set[str]:
    genes = {seed}
    allowed_nodes = set(graph) if allowed is None else allowed
    while len(genes) < size:
        boundary = set().union(*(set(graph.neighbors(g)) for g in genes)) & allowed_nodes - genes
        if not boundary:
            break
        genes.add(sorted(boundary, key=lambda gene: (
            -(graph.nodes[gene].get("final_node_score", 0.0)
              + sum(graph.edges[gene, old].get("final_edge_score", 0.0) for old in sorted(genes, key=gene_key) if graph.has_edge(gene, old))),
            gene_key(gene),
        ))[0])
    return genes


def top_weight_candidates(graph: nx.Graph, size: int) -> list[set[str]]:
    ranked = sorted(graph, key=lambda gene: (-graph.nodes[gene].get("final_node_score", 0.0), gene_key(gene)))
    return [greedy_connected(graph, seed, size) for seed in ranked[:100]]


def k_core_candidates(graph: nx.Graph, size: int) -> list[set[str]]:
    core = nx.core_number(graph)
    ranked = sorted(graph, key=lambda gene: (-core[gene], -graph.nodes[gene].get("final_node_score", 0.0), gene_key(gene)))
    out = []
    for seed in ranked[:150]:
        allowed = {g for g, value in core.items() if value >= core[seed]}
        out.append(greedy_connected(graph, seed, size, allowed))
    return out


def triangle_candidates(graph: nx.Graph, size: int) -> list[set[str]]:
    support = {g: 0 for g in graph}
    for u, v in graph.edges():
        value = len(set(graph.neighbors(u)) & set(graph.neighbors(v)))
        support[u] += value
        support[v] += value
    ranked = sorted(graph, key=lambda gene: (-support[gene], -graph.nodes[gene].get("final_node_score", 0.0), gene_key(gene)))
    triangle_nodes = {g for g, value in support.items() if value > 0}
    return [greedy_connected(graph, seed, size, triangle_nodes) for seed in ranked[:150] if seed in triangle_nodes]


def percolation_candidates(graph: nx.Graph, r: int) -> list[set[str]]:
    return [set(group) for group in nx.algorithms.community.k_clique_communities(graph, r)]


def mcode_like_candidates(graph: nx.Graph, size: int) -> list[set[str]]:
    scores = {}
    for node in graph:
        neighborhood = set(graph.neighbors(node)) | {node}
        scores[node] = nx.density(graph.subgraph(neighborhood)) * graph.nodes[node].get("final_node_score", 0.0)
    return [greedy_connected(graph, seed, size) for seed, _ in sorted(scores.items(), key=lambda item: (-item[1], gene_key(item[0])))[:150]]


def main() -> None:
    parser = argparse.ArgumentParser(description="KBS baseline comparison on a common LUAD candidate graph.")
    parser.add_argument("--config", default="configs/phase1_luad.yaml")
    parser.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    parser.add_argument("--candidate-budget", type=int, default=1500)
    parser.add_argument("--output-dir", default="results/baselines")
    args = parser.parse_args()
    set_random_seed(RANDOM_SEED)
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    local = apply_overrides(cfg, {"candidate_graph.max_candidate_genes": args.candidate_budget})
    graph, graph_stats = build_graph_from_cache(cfg, cache, {"candidate_graph.max_candidate_genes": args.candidate_budget})
    module_cfg = local["module"]
    min_size = int(module_cfg["min_module_size"])
    max_size = int(module_cfg["max_module_size"])
    budget = int(module_cfg.get("top_B_modules", 10))
    tau = float(module_cfg.get("redundancy_threshold", 0.5))
    r = int(local["clique"]["r"])
    target_size = min_size
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    log_lines = [
        f"random_seed={RANDOM_SEED}", f"PYTHONHASHSEED={os.environ.get('PYTHONHASHSEED', 'unset')}", f"config={Path(args.config).resolve()}",
        f"cache={Path(args.cache_dir).resolve()}", f"candidate_budget={args.candidate_budget}",
        f"r={r}, L={min_size}, U={max_size}, B={budget}, tau={tau}",
    ]
    print("\n".join(log_lines))

    all_modules = []
    summaries = []
    t0 = time.perf_counter()
    cb_seeds, _ = enumerate_top_r_cliques(graph, r, int(local["clique"]["max_clique_seeds"]))
    cb_modules, _ = build_modules(graph, cb_seeds, local, no_expansion=False, redundancy=True)
    cb_runtime = time.perf_counter() - t0
    cb_modules.insert(0, "method", "CliqueBio")
    all_modules.append(cb_modules)
    summaries.append(summarize_method("CliqueBio", cb_modules, cb_runtime))

    methods = [
        ("TopWeight", lambda: top_weight_candidates(graph, target_size)),
        ("k-core", lambda: k_core_candidates(graph, target_size)),
        ("TriangleSupport", lambda: triangle_candidates(graph, target_size)),
        ("CliquePercolation", lambda: percolation_candidates(graph, r)),
        ("MCODE-like", lambda: mcode_like_candidates(graph, target_size)),
    ]
    for name, builder in methods:
        start = time.perf_counter()
        candidates = builder()
        modules = select_candidates(name, graph, candidates, cb_seeds, min_size, max_size, budget, tau)
        elapsed = time.perf_counter() - start
        all_modules.append(modules)
        summaries.append(summarize_method(name, modules, elapsed))
        log_lines.append(f"{name}: candidates={len(candidates)}, returned={len(modules)}, runtime={elapsed:.6f}s")

    modules_df = pd.concat(all_modules, ignore_index=True, sort=False)
    summary_df = pd.DataFrame(summaries)
    modules_df.to_csv(out / "baseline_modules.csv", index=False)
    summary_df.to_csv(out / "baseline_comparison.csv", index=False)
    write_json(out / "baseline_comparison.json", {
        "random_seed": RANDOM_SEED,
        "inputs": cache["manifest"].get("input_file_paths", {}),
        "parameters": {"candidate_budget": args.candidate_budget, "r": r, "L": min_size, "U": max_size, "B": budget, "tau": tau},
        "graph": graph_stats.iloc[0].to_dict(),
        "results": summary_df.to_dict(orient="records"),
    })
    (out / "run.log").write_text("\n".join(log_lines) + "\n", encoding="utf-8")
    print(summary_df.to_string(index=False))


if __name__ == "__main__":
    main()
