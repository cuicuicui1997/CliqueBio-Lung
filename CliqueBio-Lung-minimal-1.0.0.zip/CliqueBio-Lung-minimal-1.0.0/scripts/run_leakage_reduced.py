from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from experiment_utils import build_graph_from_cache, load_cached_inputs, module_summary
from kbs_experiment_utils import RANDOM_SEED, average_pairwise_jaccard, write_json
from run_robustness_bootstrap import leakage_reduced_nodes
from src.clique_enum import enumerate_top_r_cliques
from src.evaluation import evaluate_modules
from src.module_builder import build_modules
from src.scoring import label_vectors
from src.utils import set_random_seed


def main() -> None:
    parser = argparse.ArgumentParser(description="Leakage-reduced discovery without AUC or Cox node-score components.")
    parser.add_argument("--config", default="configs/phase1_luad.yaml")
    parser.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    parser.add_argument("--output-dir", default="results/leakage_reduced")
    args = parser.parse_args()
    set_random_seed(RANDOM_SEED)
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    samples, labels = label_vectors(cache["metadata"], cfg, list(cache["expression"].columns))
    tumor = [s for s, y in zip(samples, labels) if y == 1]
    normal = [s for s, y in zip(samples, labels) if y == 0]
    local_cache = dict(cache)
    local_cache["node_scores"] = leakage_reduced_nodes(cache, tumor, normal, cfg)
    print(f"random_seed={RANDOM_SEED}")
    print(f"PYTHONHASHSEED={os.environ.get('PYTHONHASHSEED', 'unset')}")
    print(f"config={Path(args.config).resolve()}")
    print(f"cache={Path(args.cache_dir).resolve()}")
    print("node weights loaded from config; AUC=Cox=Stability=0")
    start = time.perf_counter()
    graph, graph_stats = build_graph_from_cache(cfg, local_cache, {"candidate_graph.max_candidate_genes": 1500})
    seeds, _ = enumerate_top_r_cliques(graph, 3, int(cfg["clique"]["max_clique_seeds"]))
    modules, _ = build_modules(graph, seeds, cfg, no_expansion=False, redundancy=True)
    runtime = time.perf_counter() - start
    evaluation = evaluate_modules(modules, cache["expression"], cache["metadata"], cache["clinical"], cfg, "discovery", "leakage_reduced")
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    modules.to_csv(out / "leakage_reduced_modules.csv", index=False)
    evaluation.to_csv(out / "auxiliary_biomedical_context.csv", index=False)
    weights = cfg.get("node_scoring", {}).get("weights", {})
    de_weight = float(weights.get("DE_score", 0.0))
    knowledge_weight = float(weights.get("Knowledge_score", 0.0))
    active_weight = de_weight + knowledge_weight
    summary = {
        "random_seed": RANDOM_SEED,
        "removed_discovery_components": ["AUC_score", "Cox_score"],
        "remaining_node_weights_renormalized": {
            "DE_score": de_weight / active_weight if active_weight else 0.0,
            "Knowledge_score": knowledge_weight / active_weight if active_weight else 0.0,
        },
        "graph": graph_stats.iloc[0].to_dict(),
        "modules": module_summary(modules),
        "avg_pairwise_jaccard": average_pairwise_jaccard(modules),
        "runtime_seconds": runtime,
        "auxiliary_mean_auc": pd.to_numeric(evaluation.get("AUC", pd.Series(dtype=float)), errors="coerce").mean(),
        "auxiliary_min_logrank_p": pd.to_numeric(evaluation.get("logrank_p", pd.Series(dtype=float)), errors="coerce").min(),
        "external_validation": False,
    }
    write_json(out / "leakage_reduced_summary.json", summary)
    (out / "run.log").write_text("\n".join([
        f"random_seed={RANDOM_SEED}", f"PYTHONHASHSEED={os.environ.get('PYTHONHASHSEED', 'unset')}", f"config={Path(args.config).resolve()}",
        f"cache={Path(args.cache_dir).resolve()}", str(summary),
    ]) + "\n", encoding="utf-8")
    print(summary)


if __name__ == "__main__":
    main()
