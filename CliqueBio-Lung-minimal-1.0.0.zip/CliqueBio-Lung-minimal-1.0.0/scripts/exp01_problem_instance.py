from __future__ import annotations

import argparse
import pandas as pd

from experiment_utils import exp_dir, load_cached_inputs, build_graph_from_cache, write_report
from src.clique_enum import enumerate_top_r_cliques


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/phase1_luad.yaml")
    p.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    args = p.parse_args()
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    rows = []
    for max_genes in [500, 1000, 1500, 2000, 3000]:
        for r in [3, 4]:
            try:
                graph, stats = build_graph_from_cache(cfg, cache, {"candidate_graph.max_candidate_genes": max_genes})
                seeds, meta = enumerate_top_r_cliques(graph, r, int(cfg["clique"]["max_clique_seeds"]))
                s = stats.iloc[0]
                rows.append({
                    "max_candidate_genes": max_genes, "r": r,
                    "candidate_num_nodes": s["candidate_num_nodes"], "candidate_num_edges": s["candidate_num_edges"],
                    "density": s["density"], "average_degree": s["average_degree"], "degeneracy": s["degeneracy"],
                    "num_r_cliques": meta["num_enumerated_cliques"],
                    "avg_string_confidence": pd.to_numeric([d.get("STRING_score") for _, _, d in graph.edges(data=True)]).mean(),
                    "reduction_node_ratio": s["reduction_node_ratio"], "reduction_edge_ratio": s["reduction_edge_ratio"],
                    "runtime_enum": meta["runtime_enum"], "status": "success", "notes": "",
                })
            except Exception as exc:
                rows.append({"max_candidate_genes": max_genes, "r": r, "status": "failed", "notes": str(exc)})
    out = exp_dir("exp01_problem_instance")
    df = pd.DataFrame(rows)
    df.to_csv(out / "problem_instance_stats.csv", index=False)
    ok = df[df["status"] == "success"]
    write_report(out / "PROBLEM_INSTANCE_REPORT.md", "Exp 1 Problem Instance Characterization",
                 f"Completed {len(ok)}/{len(df)} settings. The LUAD weighted PPI instances contain non-trivial r-clique structure: max enumerated cliques = {ok['num_r_cliques'].max() if not ok.empty else 'NA'}, max degeneracy = {ok['degeneracy'].max() if not ok.empty else 'NA'}. This supports the problem as a non-trivial graph-mining instance rather than a simple biomarker ranking task.")


if __name__ == "__main__":
    main()
