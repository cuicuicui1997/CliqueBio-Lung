from __future__ import annotations

import argparse
import pandas as pd

from experiment_utils import exp_dir, load_cached_inputs, run_cached_setting, module_summary, avg_pairwise_jaccard, write_report


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/phase1_luad.yaml")
    p.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    args = p.parse_args()
    cfg, _, cache = load_cached_inputs(args.config, args.cache_dir)
    settings = [
        ("Full", {}, False, True),
        ("w/o degeneracy order", {}, False, True),
        ("w/o edge score", {"edge_scoring.weights.STRING_score": 0.0, "edge_scoring.weights.CoExpr_score": 0.0, "edge_scoring.weights.Pathway_score": 0.0, "candidate_graph.min_edge_score": 0.0}, False, True),
        ("w/o knowledge score", {}, False, True),
        ("w/o redundancy selection", {}, False, False),
    ]
    rows = []
    for name, overrides, no_expansion, redundancy in settings:
        local_cache = dict(cache)
        notes = ""
        if name == "w/o degeneracy order":
            notes = "Current prototype exposes degeneracy-order enumeration only; recorded as same implementation pending alternate order hook."
        if name == "w/o knowledge score":
            local_cache["mechanism"] = cache["mechanism"].iloc[0:0].copy()
        try:
            res = run_cached_setting(cfg, local_cache, {"candidate_graph.max_candidate_genes": 1500, **overrides}, 3, no_expansion=no_expansion, redundancy=redundancy)
            s = res["graph_stats"].iloc[0]; ms = module_summary(res["modules"])
            rows.append({"setting": name, "candidate_num_nodes": s["candidate_num_nodes"], "candidate_num_edges": s["candidate_num_edges"], "enumerated_cliques": res["enum_meta"]["num_enumerated_cliques"], "retained_seeds": res["enum_meta"]["num_retained_seeds"], **ms, "runtime": res["total"], "avg_pairwise_jaccard": avg_pairwise_jaccard(res["modules"]), "status": "success", "notes": notes})
        except Exception as exc:
            rows.append({"setting": name, "status": "failed", "notes": str(exc)})
    out = exp_dir("exp08_core_component_ablation")
    df = pd.DataFrame(rows); df.to_csv(out / "core_component_ablation.csv", index=False)
    write_report(out / "CORE_COMPONENT_ABLATION_REPORT.md", "Exp 8 Core Component Ablation", "Core component ablations are generated from config/flag changes where available. The no-degeneracy-order setting is marked as a future hook because Phase 1.8 does not change enumeration semantics.")


if __name__ == "__main__":
    main()
