from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.data_io import load_clinical_survival, load_expression, load_sample_metadata, load_string_ppi
from src.pipeline import experiment_mode, load_config
from src.scoring import label_vectors
from src.utils import ensure_run_dirs, make_run_id, read_table_auto, resolve_path, write_yaml


def add(rows: list[dict], check: str, status: str, message: str, critical: bool = False, value: object = "") -> None:
    rows.append({"check": check, "status": status, "critical": critical, "value": value, "message": message})


def main() -> None:
    parser = argparse.ArgumentParser(description="Check CliqueBio-Lung Phase 1.5 real-data inputs.")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config, base = load_config(args.config)
    mode = experiment_mode(config)
    r = int(config.get("clique", {}).get("r", 3))
    run_id = make_run_id(config, r, datetime.now()) + "_input_check"
    out_base = resolve_path(config.get("paths", {}).get("output_dir", "results"), base)
    dirs = ensure_run_dirs(out_base, run_id)
    write_yaml(config, dirs["run"] / "config_used.yaml")

    rows: list[dict] = []
    paths = config.get("paths", {})
    cols = config.get("columns", {})
    resolved = {key: resolve_path(value, base) for key, value in paths.items() if key != "output_dir"}

    required = ["expression_matrix", "sample_metadata", "string_ppi"]
    for key in required:
        p = resolved.get(key)
        ok = p is not None and p.exists()
        add(rows, f"{key}_exists", "PASS" if ok else "FAIL", str(p) if p else "not configured", critical=True)
    for key in ["clinical_survival", "mechanism_gene_bank"]:
        p = resolved.get(key)
        if p is not None:
            add(rows, f"{key}_exists", "PASS" if p.exists() else "FAIL", str(p), critical=mode == "real")

    ext_expr = resolved.get("external_validation_expression")
    ext_meta = resolved.get("external_validation_metadata")
    ext_pair_ok = (ext_expr is None and ext_meta is None) or (ext_expr is not None and ext_meta is not None and ext_expr.exists() and ext_meta.exists())
    add(rows, "external_validation_pair", "PASS" if ext_pair_ok else "FAIL", f"expression={ext_expr}; metadata={ext_meta}", critical=mode == "real" and (ext_expr is not None or ext_meta is not None))

    expression = metadata = ppi = survival = None
    try:
        raw_expr = read_table_auto(resolved["expression_matrix"])
        gene_col = cols.get("gene") if cols.get("gene") in raw_expr.columns else raw_expr.columns[0]
        dup_count = int(raw_expr[gene_col].astype(str).str.upper().duplicated().sum())
        add(rows, "expression_gene_x_sample_shape", "PASS" if raw_expr.shape[1] > 1 else "FAIL", f"shape={raw_expr.shape}", critical=True)
        add(rows, "duplicated_gene_symbols", "WARN" if dup_count else "PASS", f"duplicate rows={dup_count}; collapse={config.get('data', {}).get('duplicated_gene_collapse', 'mean')}", value=dup_count)
        expression = load_expression(resolved["expression_matrix"], config)
        add(rows, "expression_loaded", "PASS", f"genes={expression.shape[0]}, samples={expression.shape[1]}", critical=True)
    except Exception as exc:
        add(rows, "expression_loaded", "FAIL", str(exc), critical=True)

    try:
        metadata = load_sample_metadata(resolved["sample_metadata"], cols.get("sample_id", "sample_id"), cols.get("label", "label"), config)
        if expression is not None:
            overlap = len(set(expression.columns.astype(str)) & set(metadata[cols.get("sample_id", "sample_id")].astype(str)))
            add(rows, "metadata_expression_sample_overlap", "PASS" if overlap > 0 else "FAIL", f"overlap={overlap}", critical=True, value=overlap)
            samples, y = label_vectors(metadata, config, list(expression.columns))
            add(rows, "tumor_normal_two_classes", "PASS" if len(set(y)) == 2 else "FAIL", f"mapped_samples={len(samples)}, classes={sorted(set(y.tolist()))}", critical=True)
    except Exception as exc:
        add(rows, "metadata_loaded", "FAIL", str(exc), critical=True)

    try:
        ppi_raw = read_table_auto(resolved["string_ppi"])
        required_ppi = {cols.get("gene_a", "geneA"), cols.get("gene_b", "geneB"), cols.get("string_score", "combined_score")}
        missing = required_ppi - set(ppi_raw.columns)
        add(rows, "string_required_columns", "PASS" if not missing else "FAIL", f"missing={sorted(missing)}", critical=True)
        if not missing:
            a_col, b_col = cols.get("gene_a", "geneA"), cols.get("gene_b", "geneB")
            self_loops = int((ppi_raw[a_col].astype(str).str.upper() == ppi_raw[b_col].astype(str).str.upper()).sum())
            pairs = ppi_raw[[a_col, b_col]].astype(str).apply(lambda x: tuple(sorted([x[a_col].upper(), x[b_col].upper()])), axis=1)
            dup_edges = int(pairs.duplicated().sum())
            add(rows, "string_self_loops", "WARN" if self_loops else "PASS", f"self_loops={self_loops}", value=self_loops)
            add(rows, "string_duplicate_edges", "WARN" if dup_edges else "PASS", f"duplicate_edges={dup_edges}", value=dup_edges)
        ppi = load_string_ppi(resolved["string_ppi"], cols.get("gene_a", "geneA"), cols.get("gene_b", "geneB"), cols.get("string_score", "combined_score"))
        add(rows, "string_loaded", "PASS", f"edges={len(ppi)}", critical=True)
        if expression is not None:
            ppi_genes = set(ppi["geneA"]) | set(ppi["geneB"])
            overlap = len(set(expression.index) & ppi_genes)
            min_overlap = int(config.get("data", {}).get("min_expression_string_overlap", 100))
            add(rows, "expression_string_gene_overlap", "PASS" if overlap >= min_overlap else "WARN", f"overlap={overlap}; min={min_overlap}", critical=False, value=overlap)
    except Exception as exc:
        add(rows, "string_loaded", "FAIL", str(exc), critical=True)

    surv_path = resolved.get("clinical_survival")
    if surv_path is not None and surv_path.exists():
        try:
            survival = load_clinical_survival(surv_path, cols.get("sample_id", "sample_id"), cols.get("os_time", "OS_time"), cols.get("os_status", "OS_status"), config)
            time_col, status_col = cols.get("os_time", "OS_time"), cols.get("os_status", "OS_status")
            usable = survival[time_col].notna() & survival[status_col].notna()
            positive = bool((survival.loc[usable, time_col] > 0).all()) if usable.any() else False
            status_ok = set(survival.loc[usable, status_col].dropna().unique()).issubset({0, 1})
            add(rows, "survival_columns_usable", "PASS" if usable.any() else "FAIL", f"usable_rows={int(usable.sum())}", critical=False)
            add(rows, "survival_os_time_positive", "PASS" if positive else "FAIL", "OS time must be positive", critical=False)
            add(rows, "survival_status_binary", "PASS" if status_ok else "FAIL", "OS status mapped to 0/1", critical=False)
        except Exception as exc:
            add(rows, "survival_loaded", "FAIL", str(exc), critical=mode == "real")

    report = pd.DataFrame(rows)
    report.insert(0, "experiment_mode", mode)
    report.insert(0, "run_id", run_id)
    report.to_csv(dirs["logs"] / "input_check_report.csv", index=False)
    lines = [f"CliqueBio-Lung input check", f"mode: {mode}", f"run_id: {run_id}", ""]
    for row in rows:
        lines.append(f"[{row['status']}] {row['check']}: {row['message']}")
    (dirs["logs"] / "input_check_report.txt").write_text("\n".join(lines), encoding="utf-8")

    failed_critical = report[(report["status"] == "FAIL") & (report["critical"] == True)]
    print(f"run_id={run_id}")
    print(f"report_csv={dirs['logs'] / 'input_check_report.csv'}")
    print(f"report_txt={dirs['logs'] / 'input_check_report.txt'}")
    if mode == "real" and not failed_critical.empty:
        print(f"critical_failures={len(failed_critical)}")
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
