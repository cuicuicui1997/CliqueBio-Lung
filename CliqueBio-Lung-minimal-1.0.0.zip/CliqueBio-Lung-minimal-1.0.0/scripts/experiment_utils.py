from __future__ import annotations

import itertools
import os
import sys
import time
from pathlib import Path
from typing import Any

import networkx as nx
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.cache import load_score_cache
from src.clique_enum import enumerate_top_r_cliques
from src.graph_builder import build_candidate_graph
from src.module_builder import build_modules
from src.pipeline import apply_overrides, load_config
from src.scoring import clique_score
from src.utils import split_gene_list


DEFAULT_CACHE = "data/processed/cache/phase1_luad_real"


def exp_dir(name: str) -> Path:
    path = Path(os.environ.get("CLIQUEBIO_EXPERIMENT_ROOT", "results/experiments")) / name
    path.mkdir(parents=True, exist_ok=True)
    return path


def load_cached_inputs(config_path: str, cache_dir: str = DEFAULT_CACHE) -> tuple[dict[str, Any], Path, dict[str, Any]]:
    cfg, base = load_config(config_path)
    cache = load_score_cache(cache_dir)
    mechanism = pd.read_csv(cfg["paths"]["mechanism_gene_bank"], sep="\t")
    mechanism = mechanism.rename(columns={cfg["columns"].get("mechanism_category", "category"): "mechanism_category"})
    cache["mechanism"] = mechanism
    return cfg, base, cache


def strip_tags(df: pd.DataFrame) -> pd.DataFrame:
    return df.drop(columns=[c for c in ["run_id", "experiment_mode"] if c in df.columns])


def build_graph_from_cache(cfg: dict[str, Any], cache: dict[str, Any], overrides: dict[str, Any]) -> tuple[nx.Graph, pd.DataFrame]:
    local = apply_overrides(cfg, overrides)
    return build_candidate_graph(strip_tags(cache["node_scores"]), strip_tags(cache["edge_scores"]), cache["mechanism"], local)


def run_cached_setting(cfg: dict[str, Any], cache: dict[str, Any], overrides: dict[str, Any], r: int, no_expansion: bool = False, redundancy: bool = True) -> dict[str, Any]:
    t0 = time.perf_counter()
    graph, graph_stats = build_graph_from_cache(cfg, cache, overrides)
    max_seeds = int(apply_overrides(cfg, overrides).get("clique", {}).get("max_clique_seeds", 5000))
    seeds, enum_meta = enumerate_top_r_cliques(graph, r, max_seeds)
    modules, module_meta = build_modules(graph, seeds, apply_overrides(cfg, overrides), no_expansion=no_expansion, redundancy=redundancy)
    total = time.perf_counter() - t0
    return {"graph": graph, "graph_stats": graph_stats, "seeds": seeds, "enum_meta": enum_meta, "modules": modules, "module_meta": module_meta, "total": total}


def module_summary(modules: pd.DataFrame) -> dict[str, Any]:
    if modules.empty:
        return {
            "top_modules": 0,
            "avg_module_score": np.nan,
            "best_module_score": np.nan,
            "avg_clique_coverage": np.nan,
            "avg_string_confidence": np.nan,
            "mechanism_gene_fraction": np.nan,
        }
    return {
        "top_modules": len(modules),
        "avg_module_score": pd.to_numeric(modules.get("module_score"), errors="coerce").mean(),
        "best_module_score": pd.to_numeric(modules.get("module_score"), errors="coerce").max(),
        "avg_clique_coverage": pd.to_numeric(modules.get("clique_coverage"), errors="coerce").mean(),
        "avg_string_confidence": pd.to_numeric(modules.get("avg_string_score"), errors="coerce").mean(),
        "mechanism_gene_fraction": pd.to_numeric(modules.get("mechanism_gene_fraction", pd.Series(dtype=float)), errors="coerce").mean(),
    }


def avg_pairwise_jaccard(modules: pd.DataFrame) -> float:
    sets = [set(split_gene_list(g)) for g in modules.get("genes", [])]
    vals = [len(a & b) / len(a | b) for i, a in enumerate(sets) for b in sets[i + 1 :] if a or b]
    return float(np.mean(vals)) if vals else 0.0


def naive_cliques(graph: nx.Graph, r: int) -> set[tuple[str, ...]]:
    return {
        tuple(combo)
        for combo in itertools.combinations(sorted(graph.nodes()), r)
        if all(graph.has_edge(a, b) for a, b in itertools.combinations(combo, 2))
    }


def write_report(path: Path, title: str, body: str) -> None:
    path.write_text(f"# {title}\n\n{body.strip()}\n", encoding="utf-8")
