from __future__ import annotations

import json
import os
from pathlib import Path

import pandas as pd
import yaml


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "manuscript" / "src" / "tables" / "generated"
RESULTS = Path(os.environ.get("CLIQUEBIO_RESULT_ROOT", str(ROOT / "results")))


def save(name: str, text: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / name).write_text(text.strip() + "\n", encoding="utf-8")
    print(OUT / name)


def baseline_table() -> None:
    df = pd.read_csv(RESULTS / "baselines" / "baseline_comparison.csv")
    labels = {
        "CliqueBio": r"\textbf{CliqueBio}", "TopWeight": "TopWeight", "k-core": r"$k$-core",
        "TriangleSupport": "Triangle support", "CliquePercolation": "Clique percolation",
        "MCODE-like": "MCODE-like",
    }
    rows = []
    for row in df.itertuples(index=False):
        rows.append(
            f"{labels[row.method]} & {row.avg_string_confidence:.3f} & {row.avg_ppi_density:.3f} & "
            f"{row.avg_structural_clique_coverage:.3f} & {row.avg_pairwise_jaccard:.3f} & {row.runtime_seconds:.3f} & {int(row.returned_modules)} \\\\"
        )
    save("baseline_comparison.tex", r"""
\begin{table*}[t]
\caption{Comparison with representative graph and network-module baselines on the same LUAD candidate graph. Structural clique coverage is computed identically for every method by exactly enumerating size-\(r\) cliques in each induced module. All methods use \(L=5\), \(U=30\), \(B=10\), and the same redundancy threshold. Runtime excludes the common score-cache construction.}
\label{tab:baseline-comparison}
\centering
\small
\setlength{\tabcolsep}{4.2pt}
\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrrrrr}
\toprule
Method & STRING\(\uparrow\) & Density\(\uparrow\) & Structural cov.\(\uparrow\) & Jaccard\(\downarrow\) & Time (s)\(\downarrow\) & \# modules \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular*}
\end{table*}
""")


def objective_table() -> None:
    df = pd.read_csv(RESULTS / "objective_gap" / "objective_gap_small_instances.csv")
    rows = [
        f"{int(r.candidate_budget)} & {int(r.candidate_nodes)} & {int(r.pool_size)} & {int(r.B)} & {r.optimal_objective:.3f} & {r.cliquebio_objective:.3f} & {r.cliquebio_ratio:.3f} & {r.exact_time_seconds:.4f} & {r.cliquebio_time_seconds:.5f} \\\\"
        for r in df.itertuples(index=False)
    ]
    save("objective_gap_small_instances.tex", r"""
\begin{table}[H]
\caption{Exhaustive comparison within generated small-instance candidate pools (\(\lambda=0.2\), \(B=3\)).}
\label{tab:objective-gap}
\centering
\small
\begin{tabular}{rrrrrrrrr}
\toprule
\(K_V\) & Nodes & Pool & \(B\) & Opt. \(\mathcal R\) & Greedy \(\mathcal R\) & Ratio & Exh. (s) & Greedy (s) \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
""")


def robustness_table() -> None:
    summary = json.loads((RESULTS / "robustness" / "bootstrap_summary.json").read_text(encoding="utf-8"))
    themes = summary["theme_median_max_jaccard"]
    rows = [
        f"Mean matched output Jaccard & {summary['mean_matched_output_jaccard']:.3f} \\\\",
        f"Median matched output Jaccard & {summary['median_matched_output_jaccard']:.3f} \\\\",
        f"Top-10 gene mean recurrence & {summary['top10_gene_mean_recurrence']:.3f} \\\\",
        f"ECM/collagen median max Jaccard & {themes['ECM/collagen']:.3f} \\\\",
        f"Immune-checkpoint median max Jaccard & {themes['immune checkpoint']:.3f} \\\\",
        f"RNA-binding-protein median max Jaccard & {themes['RNA-binding protein']:.3f} \\\\",
    ]
    save("bootstrap_stability.tex", r"""
\begin{table}[H]
\caption{Leakage-reduced stability under 10 stratified 80\% subsampling runs (seed 2026).}
\label{tab:bootstrap-stability}
\centering
\small
\begin{tabular}{lr}
\toprule
Statistic & Value \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
""")


def leakage_table() -> None:
    baseline = pd.read_csv(RESULTS / "baselines" / "baseline_comparison.csv")
    full = baseline[baseline["method"] == "CliqueBio"].iloc[0]
    reduced = json.loads((RESULTS / "leakage_reduced" / "leakage_reduced_summary.json").read_text(encoding="utf-8"))
    save("leakage_reduced.tex", rf"""
\begin{{table}}[H]
\caption{{Discovery-score sensitivity after removing AUC and Cox components. Biomedical endpoints are not treated as independent validation.}}
\label{{tab:leakage-reduced}}
\centering
\small
\begin{{tabular}}{{lrrrrr}}
\toprule
Setting & \(Q_{{\mathrm{{prod}}}}\) & Structural cov. & STRING & Jaccard & \# modules \\
\midrule
Full discovery score & {full.avg_module_score:.3f} & {full.avg_structural_clique_coverage:.3f} & {full.avg_string_confidence:.3f} & {full.avg_pairwise_jaccard:.3f} & {int(full.returned_modules)} \\
AUC/Cox removed & {reduced['modules']['avg_module_score']:.3f} & {reduced['modules']['avg_clique_coverage']:.3f} & {reduced['modules']['avg_string_confidence']:.3f} & {reduced['avg_pairwise_jaccard']:.3f} & {int(reduced['modules']['top_modules'])} \\
\bottomrule
\end{{tabular}}
\end{{table}}
""")


def reproducibility_tables() -> None:
    cfg = yaml.safe_load((ROOT / "configs" / "phase1_luad.yaml").read_text(encoding="utf-8"))
    nw, ew = cfg["node_scoring"]["weights"], cfg["edge_scoring"]["weights"]
    scoring_rows = [
        ("Differential expression", r"Normalized \(|\Delta\mu|[-\log_{10}(p)]\)", "TCGA-LUAD", "Min--max to [0,1]", nw["DE_score"]),
        ("Diagnostic score", "Direction-invariant gene AUC", "TCGA-LUAD labels", "Min--max to [0,1]", nw["AUC_score"]),
        ("Survival score", r"\(-\log_{10}(p_{Cox})\)", "TCGA-LUAD OS", "Min--max to [0,1]", nw["Cox_score"]),
        ("Stability score", "Omitted; remaining node terms renormalized", "Not used", "N/A", nw["Stability_score"]),
        ("Knowledge score", "Curated-bank membership", "LUAD mechanism bank", "Binary", nw["Knowledge_score"]),
        ("STRING confidence", "Physical-interaction score / 1000", "STRING v12.0", "Native [0,1]", ew["STRING_score"]),
        ("Co-expression", "Absolute Pearson correlation", "TCGA-LUAD", "Native [0,1]", ew["CoExpr_score"]),
        ("Pathway co-membership", "Shared curated mechanism category", "LUAD mechanism bank", "Binary", ew["Pathway_score"]),
        (r"Seed score \(S(C)\)", "Node, edge, knowledge, and coherence", "Derived", "Active weights renormalized", "0.389/0.333/0.167/0.111"),
        (r"Production score \(Q_{\mathrm{prod}}(X)\)", "Provenance seed, node, edge, provenance coverage, and knowledge", "Derived", "Weighted [0,1] components", "0.30/0.25/0.20/0.15/0.10"),
    ]
    rows = [f"{a} & {b} & {c} & {d} & {e} \\\\" for a, b, c, d, e in scoring_rows]
    save("scoring_components.tex", r"""
\begin{table}[H]
\caption{Scoring components used in the default discovery setting. Stability is omitted, and the remaining active components are renormalized.}
\label{tab:scoring-components}
\centering
\scriptsize
\begin{tabularx}{\textwidth}{lXlll}
\toprule
Component & Definition & Source & Normalization & Default weight \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabularx}
\end{table}
""")
    params = [
        ("random seed", 2026, "All stochastic procedures"), (r"\(r\)", 3, "Clique size"),
        (r"\(L\)", 5, "Minimum module size"), (r"\(U\)", 30, "Maximum module size"),
        (r"\(B\)", 10, "Output budget"), (r"\(K_V\)", 1500, "Candidate-gene budget in main experiments"),
        (r"\(\theta_{\mathrm{STRING}}\)", 700, "Minimum raw STRING confidence"),
        (r"\(\theta_E\)", 0.5, "Minimum final edge score"),
        (r"\(K_S\)", 5000, "Retained seed cap"), (r"\(\tau\)", 0.5, "Output Jaccard threshold"),
        (r"\(\lambda\)", 0.2, "Objective-gap experiment only"),
    ]
    rows = [f"{a} & {b} & {c} \\\\" for a, b, c in params]
    save("parameter_settings.tex", r"""
\begin{table}[H]
\caption{Default parameters and the additional objective-gap setting.}
\label{tab:parameter-settings}
\centering
\small
\begin{tabularx}{\textwidth}{llX}
\toprule
Parameter & Value & Meaning \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabularx}
\end{table}
""")


def main() -> None:
    baseline_table()
    objective_table()
    robustness_table()
    leakage_table()
    reproducibility_tables()


if __name__ == "__main__":
    main()
