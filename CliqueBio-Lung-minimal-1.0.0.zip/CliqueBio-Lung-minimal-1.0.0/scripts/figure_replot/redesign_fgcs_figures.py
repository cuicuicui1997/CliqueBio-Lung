from __future__ import annotations

import math
import os
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.gridspec import GridSpec
from matplotlib.ticker import FuncFormatter, LogFormatterMathtext, LogLocator
import numpy as np
import pandas as pd

try:
    import seaborn as sns
except Exception:  # pragma: no cover - optional style dependency
    sns = None


ROOT = Path(__file__).resolve().parents[2]
RESULTS_ROOT = Path(os.environ.get("CLIQUEBIO_RESULT_ROOT", str(ROOT / "results")))
FIGURE_DATA = ROOT / "manuscript_assets" / "figure_data"
OUT_DIR = ROOT / "manuscript" / "src" / "figures" / "polished"

PALETTE = {
    "blue": "#2E5E8C",
    "navy": "#17324D",
    "teal": "#2F9C95",
    "green": "#5D9A72",
    "orange": "#D9822B",
    "purple": "#6C6A96",
    "red": "#B95B5B",
    "gray": "#7B8490",
    "mid_gray": "#B4BBC4",
    "light_gray": "#E3E7EC",
    "pale": "#F6F8FA",
    "dark": "#263238",
}

METHOD_COLORS = {
    "NaiveEnum": PALETTE["gray"],
    "DegEnum": PALETTE["blue"],
    "DegEnum+TopSeed": PALETTE["green"],
    "CliqueBio-Full": PALETTE["navy"],
}

METHOD_MARKERS = {
    "NaiveEnum": "o",
    "DegEnum": "s",
    "DegEnum+TopSeed": "^",
    "CliqueBio-Full": "D",
}


def set_publication_style() -> str:
    style_backend = "matplotlib journal overrides"
    try:
        import scienceplots  # noqa: F401

        plt.style.use(["science", "no-latex"])
        style_backend = "SciencePlots base with journal overrides"
    except Exception:
        plt.style.use("default")

    if sns is not None:
        sns.set_theme(style="white", context="paper")
        style_backend = f"{style_backend} + seaborn palette"

    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "font.size": 6.8,
            "axes.titlesize": 7.4,
            "axes.labelsize": 6.8,
            "xtick.labelsize": 6.2,
            "ytick.labelsize": 6.2,
            "legend.fontsize": 6.2,
            "axes.linewidth": 0.55,
            "lines.linewidth": 1.05,
            "lines.markersize": 2.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.03,
            "legend.frameon": False,
            "xtick.top": False,
            "ytick.right": False,
            "xtick.minor.top": False,
            "ytick.minor.right": False,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "axes.grid": False,
        }
    )
    if sns is not None:
        sns.set_palette(
            [
                PALETTE["blue"],
                PALETTE["teal"],
                PALETTE["green"],
                PALETTE["orange"],
                PALETTE["purple"],
                PALETTE["gray"],
            ]
        )
    return style_backend


def clean_axis(ax: plt.Axes, grid_axis: str = "y") -> None:
    ax.minorticks_off()
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_linewidth(0.6)
    ax.spines["bottom"].set_linewidth(0.6)
    ax.tick_params(width=0.55, length=2.2, pad=2, top=False, right=False)
    if grid_axis:
        ax.grid(True, axis=grid_axis, color=PALETTE["light_gray"], linewidth=0.45, alpha=0.8)
    ax.set_axisbelow(True)


def panel_label(ax: plt.Axes, label: str, x: float = -0.13, y: float = 1.08) -> None:
    ax.text(
        x,
        y,
        label.lower(),
        transform=ax.transAxes,
        fontsize=8.2,
        fontweight="bold",
        va="top",
        ha="left",
    )


def compact_number(x: float) -> str:
    if pd.isna(x):
        return "--"
    value = float(x)
    if abs(value) >= 1_000_000:
        return f"{value / 1_000_000:.1f}M".replace(".0M", "M")
    if abs(value) >= 1000:
        return f"{value / 1000:.1f}k".replace(".0k", "k")
    if abs(value) >= 100:
        return f"{value:.0f}"
    if abs(value) >= 10:
        return f"{value:.1f}".rstrip("0").rstrip(".")
    if abs(value) >= 1:
        return f"{value:.2f}".rstrip("0").rstrip(".")
    return f"{value:.3f}".rstrip("0").rstrip(".")


def thousands_formatter(x: float, _pos: int | None = None) -> str:
    if abs(x) >= 1000:
        return f"{x / 1000:.1f}k".replace(".0k", "k")
    return f"{x:g}"


def save_figure(fig: plt.Figure, stem: str) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT_DIR / f"{stem}.pdf")
    fig.savefig(OUT_DIR / f"{stem}.png", dpi=600)
    plt.close(fig)


def annotate_last(ax: plt.Axes, x: float, y: float, text: str, color: str) -> None:
    ax.annotate(
        text,
        xy=(x, y),
        xytext=(-4, 7),
        textcoords="offset points",
        ha="right",
        va="bottom",
        fontsize=6.5,
        color=color,
    )


def normalize_row(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    lo, hi = np.nanmin(values), np.nanmax(values)
    if hi == lo:
        return np.ones_like(values) * 0.5
    return (values - lo) / (hi - lo)


def remove_frame(ax: plt.Axes) -> None:
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)


def short_label(text: str) -> str:
    return {
        "Full DiseaseAwareReduction": "Full",
        "RelaxedReduction": "Relaxed",
        "NoKnowledge": "No knowledge",
        "NodeOnly": "Node only",
        "EdgeOnly": "Edge only",
        "w/o degeneracy order": "No degeneracy",
        "w/o edge score": "No edge score",
        "w/o knowledge score": "No knowledge",
        "w/o redundancy selection": "No redundancy",
        "FullModuleConstruction": "Full",
        "IsolatedClique": "Isolated",
        "CliqueUnion": "Clique union",
        "CliquePercolation": "Percolation",
    }.get(str(text), str(text))


def draw_card(ax: plt.Axes, y: float, label: str, value: str, color: str) -> None:
    ax.hlines(y - 0.105, 0.03, 0.97, transform=ax.transAxes, color=PALETTE["light_gray"], linewidth=0.55)
    ax.scatter(0.075, y, s=24, marker="o", color=color, transform=ax.transAxes, zorder=3)
    ax.text(0.13, y + 0.035, label, transform=ax.transAxes, ha="left", va="center", fontsize=6.7, color=PALETTE["dark"])
    ax.text(0.13, y - 0.045, value, transform=ax.transAxes, ha="left", va="center", fontsize=6.4, color=color, fontweight="bold")


def figure2_enumeration() -> None:
    df = pd.read_csv(FIGURE_DATA / "Figure1_correctness_runtime.csv")
    df = df[df["status"].eq("success")].copy()
    correctness = pd.read_csv(
        RESULTS_ROOT / "experiments" / "exp02_correctness" / "correctness_comparison.csv"
    )
    median_speedup = float(correctness["speedup"].median())
    methods = ["NaiveEnum", "DegEnum", "DegEnum+TopSeed", "CliqueBio-Full"]
    display_labels = {
        "NaiveEnum": "Exhaustive subsets",
        "DegEnum": "DegEnum",
        "DegEnum+TopSeed": "DegEnum+TopSeed",
        "CliqueBio-Full": "CliqueBio-Full",
    }
    df["runtime_for_plot"] = np.where(
        df["method"].eq("CliqueBio-Full"),
        df["total_runtime_without_scoring"],
        df["enumeration_time"],
    )
    gene_budgets = sorted(df["max_candidate_genes"].unique())
    x_lookup = {budget: position for position, budget in enumerate(gene_budgets)}

    fig = plt.figure(figsize=(7.15, 2.55))
    gs = GridSpec(1, 3, width_ratios=[1.25, 1.05, 0.9], wspace=0.34, figure=fig)

    ax = fig.add_subplot(gs[0, 0])
    for method in methods:
        group = df[df["method"].eq(method)].sort_values("max_candidate_genes")
        ax.plot(
            group["max_candidate_genes"].map(x_lookup),
            group["runtime_for_plot"],
            marker=METHOD_MARKERS[method],
            color=METHOD_COLORS[method],
            label=display_labels[method],
            markeredgecolor="white",
            markeredgewidth=0.45,
            zorder=3,
        )
    ax.set_yscale("log")
    ax.yaxis.set_major_locator(LogLocator(base=10, numticks=5))
    ax.yaxis.set_major_formatter(LogFormatterMathtext(base=10))
    ax.set_title("Runtime comparison", loc="left", fontweight="bold")
    ax.set_xlabel("Candidate genes")
    ax.set_ylabel("Runtime (s, log scale)")
    ax.set_xticks(range(len(gene_budgets)), labels=[str(value) for value in gene_budgets])
    ax.set_xlim(-0.25, len(gene_budgets) - 0.75)
    clean_axis(ax)
    panel_label(ax, "A")
    ax.legend(loc="upper left", handlelength=1.3, borderaxespad=0.1)

    ax = fig.add_subplot(gs[0, 1])
    for method in ["DegEnum", "DegEnum+TopSeed", "CliqueBio-Full"]:
        group = df[df["method"].eq(method)].sort_values("max_candidate_genes")
        ax.plot(
            group["max_candidate_genes"].map(x_lookup),
            group["speedup_vs_naive"],
            marker=METHOD_MARKERS[method],
            color=METHOD_COLORS[method],
            label=method,
            markeredgecolor="white",
            markeredgewidth=0.45,
            zorder=3,
        )
    ax.axhline(1, color=PALETTE["light_gray"], linestyle="--", linewidth=0.7)
    ax.text(0.03, 1.13, "1x baseline", color=PALETTE["gray"], fontsize=6.2, va="bottom")
    ax.set_yscale("log")
    ax.yaxis.set_major_locator(LogLocator(base=10, numticks=4))
    ax.yaxis.set_major_formatter(LogFormatterMathtext(base=10))
    ax.set_title("Relative to exhaustive subset testing", loc="left", fontweight="bold")
    ax.set_xlabel("Candidate genes")
    ax.set_ylabel("Speedup (fold, log scale)")
    ax.set_xticks(range(len(gene_budgets)), labels=[str(value) for value in gene_budgets])
    ax.set_xlim(-0.25, len(gene_budgets) - 0.75)
    clean_axis(ax)
    panel_label(ax, "B")

    ax = fig.add_subplot(gs[0, 2])
    ax.set_axis_off()
    panel_label(ax, "C", x=-0.08, y=1.08)
    ax.text(0.02, 0.94, "Exactness summary", transform=ax.transAxes, ha="left", va="top", fontsize=7.6, fontweight="bold")
    draw_card(ax, 0.68, "Seed set match", "Yes", PALETTE["teal"])
    draw_card(ax, 0.43, "Top seed score match", "Yes", PALETTE["teal"])
    draw_card(ax, 0.18, "Median speedup", f"{median_speedup:.2f}x", PALETTE["navy"])

    save_figure(fig, "fig2_enumeration_redesign")


def figure3_scalability() -> None:
    df = pd.read_csv(FIGURE_DATA / "Figure2_graph_size_scalability.csv").sort_values("max_candidate_genes")
    fig = plt.figure(figsize=(7.15, 2.72))
    fig.subplots_adjust(bottom=0.22, top=0.88)
    gs = GridSpec(1, 2, width_ratios=[1.38, 1.0], wspace=0.48, figure=fig)

    ax = fig.add_subplot(gs[0, 0])
    sizes = 28 + 175 * normalize_row(np.sqrt(df["enumerated_cliques"].to_numpy(dtype=float)))
    norm = mpl.colors.Normalize(vmin=df["degeneracy"].min(), vmax=df["degeneracy"].max())
    ax.plot(
        df["max_candidate_genes"],
        df["total_runtime_without_scoring"],
        color=PALETTE["light_gray"],
        linewidth=1.1,
        zorder=1,
    )
    sc = ax.scatter(
        df["max_candidate_genes"],
        df["total_runtime_without_scoring"],
        s=sizes,
        c=df["degeneracy"],
        cmap="viridis",
        norm=norm,
        edgecolor="white",
        linewidth=0.8,
        zorder=3,
    )
    last = df.iloc[-1]
    for _, row in df.iterrows():
        if row["max_candidate_genes"] == last["max_candidate_genes"]:
            continue
        ax.text(
            row["max_candidate_genes"],
            row["total_runtime_without_scoring"] + 0.18,
            compact_number(row["max_candidate_genes"]),
            ha="center",
            va="bottom",
            fontsize=5.9,
            color=PALETTE["gray"],
        )
    ax.annotate(
        f"{last['total_runtime_without_scoring']:.2f} s\n{compact_number(last['enumerated_cliques'])} seeds\nDeg. {int(last['degeneracy'])}",
        xy=(last["max_candidate_genes"], last["total_runtime_without_scoring"]),
        xytext=(-10, 4),
        textcoords="offset points",
        ha="right",
        va="bottom",
        fontsize=5.9,
        color=PALETTE["navy"],
        annotation_clip=True,
    )
    ax.set_title("Runtime increases with structural load", loc="left", fontweight="bold", fontsize=6.6)
    ax.set_xlabel("Candidate genes")
    ax.set_ylabel("Runtime (s)")
    ax.set_xticks([500, 1000, 1500, 2000, 3000])
    ax.xaxis.set_major_formatter(FuncFormatter(thousands_formatter))
    ymax = float(df["total_runtime_without_scoring"].max())
    ax.set_ylim(0, max(10.5, ymax * 1.15))
    clean_axis(ax)
    panel_label(ax, "a")
    cb = fig.colorbar(sc, ax=ax, fraction=0.028, pad=0.012)
    cb.ax.set_title("Deg.", fontsize=5.8, pad=2)
    cb.ax.tick_params(labelsize=5.8, length=2, width=0.4)
    ax.text(
        0.02,
        0.96,
        "Bubble area = enumerated clique seeds",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=6.0,
        color=PALETTE["gray"],
    )

    ax = fig.add_subplot(gs[0, 1])
    budgets = df["max_candidate_genes"].astype(int).tolist()
    rows = [
        ("Runtime", df["total_runtime_without_scoring"].to_numpy(dtype=float), "s"),
        ("Clique seeds", df["enumerated_cliques"].to_numpy(dtype=float), ""),
        ("Degeneracy", df["degeneracy"].to_numpy(dtype=float), ""),
    ]
    matrix = np.vstack([normalize_row(values) for _, values, _ in rows])
    cmap = sns.light_palette(PALETTE["blue"], as_cmap=True) if sns is not None else "Blues"
    ax.imshow(matrix, cmap=cmap, aspect="auto", vmin=0, vmax=1)
    ax.set_title("Driver matrix", loc="left", fontweight="bold", fontsize=7.0)
    ax.set_xticks(range(len(budgets)))
    ax.set_xticklabels([compact_number(x) for x in budgets], rotation=0)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels([name for name, _, _ in rows], fontsize=6.0)
    ax.tick_params(length=0)
    for i, (_, values, suffix) in enumerate(rows):
        for j, value in enumerate(values):
            txt = compact_number(value)
            if suffix == "s":
                txt = f"{txt}s"
            ax.text(j, i, txt, ha="center", va="center", fontsize=5.7, color=PALETTE["dark"])
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_xlabel("Candidate genes")
    panel_label(ax, "b", x=-0.16)

    save_figure(fig, "fig3_scalability_dashboard")


def heatmap_panel(
    ax: plt.Axes,
    data: pd.DataFrame,
    value_col: str,
    title: str,
    norm: LogNorm | None,
) -> None:
    budgets = [500, 1000, 1500]
    rs = [3, 4, 5]
    matrix = np.array(
        [
            [
                float(data[(data["r"].eq(r)) & (data["max_candidate_genes"].eq(budget))][value_col].iloc[0])
                for budget in budgets
            ]
            for r in rs
        ]
    )
    cmap = sns.light_palette(PALETTE["teal"], as_cmap=True) if sns is not None else "YlGnBu"
    im = ax.imshow(matrix, cmap=cmap, aspect="auto", norm=norm)
    ax.set_title(title, loc="left", fontweight="bold")
    ax.set_xticks(range(len(budgets)))
    ax.set_xticklabels([str(x) for x in budgets])
    ax.set_yticks(range(len(rs)))
    ax.set_yticklabels([f"r={r}" for r in rs])
    ax.set_xlabel("Candidate genes")
    ax.set_ylabel("Clique size")
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            value = matrix[i, j]
            text = compact_number(value)
            rgba = im.cmap(im.norm(value))
            luminance = 0.299 * rgba[0] + 0.587 * rgba[1] + 0.114 * rgba[2]
            color = "white" if luminance < 0.48 else PALETTE["dark"]
            ax.text(j, i, text, ha="center", va="center", fontsize=6.4, color=color, fontweight="bold" if luminance < 0.48 else "normal")
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(length=0)
    ax.set_xticks(np.arange(-0.5, len(budgets), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(rs), 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=1.0)
    ax.tick_params(which="minor", length=0)


def figure4_sensitivity() -> None:
    df = pd.read_csv(FIGURE_DATA / "Figure3_clique_size_density.csv")
    clique = df[df["source"].eq("clique_size")].copy()
    clique["r"] = clique["r"].astype(int)
    clique["max_candidate_genes"] = clique["max_candidate_genes"].astype(int)
    density = df[df["source"].eq("ppi_density")].copy().sort_values("string_threshold")

    fig = plt.figure(figsize=(7.15, 2.55))
    gs = GridSpec(1, 3, width_ratios=[1.05, 1.05, 1.0], wspace=0.42, figure=fig)

    ax = fig.add_subplot(gs[0, 0])
    heatmap_panel(
        ax,
        clique,
        "enumerated_cliques",
        "Clique counts",
        LogNorm(vmin=clique["enumerated_cliques"].min(), vmax=clique["enumerated_cliques"].max()),
    )
    panel_label(ax, "a", x=-0.18)

    ax = fig.add_subplot(gs[0, 1])
    heatmap_panel(
        ax,
        clique,
        "total_runtime_without_scoring",
        "Runtime",
        LogNorm(vmin=clique["total_runtime_without_scoring"].min(), vmax=clique["total_runtime_without_scoring"].max()),
    )
    panel_label(ax, "b", x=-0.18)

    ax = fig.add_subplot(gs[0, 2])
    thresholds = density["string_threshold"].astype(int).tolist()
    seeds = density["enumerated_cliques"].to_numpy(dtype=float)
    y = np.arange(len(thresholds))
    colors = [PALETTE["teal"], PALETTE["teal"], PALETTE["orange"]]
    ax.barh(y, seeds, height=0.52, color=colors, edgecolor="none", alpha=0.92)
    ax.axvline(seeds[1], color=PALETTE["light_gray"], linewidth=0.8, linestyle="--")
    for yi, seed, threshold in zip(y, seeds, thresholds):
        ax.text(seed + 70, yi, compact_number(seed), va="center", ha="left", fontsize=6.4, color=PALETTE["dark"])
        ax.text(-115, yi, str(threshold), va="center", ha="right", fontsize=6.4, color=PALETTE["dark"])
    drop = (1 - seeds[-1] / seeds[1]) * 100
    ax.annotate(
        f"{drop:.0f}% fewer\nat 900",
        xy=(seeds[-1], y[-1]),
        xytext=(max(seeds) * 0.78, y[-1] + 0.34),
        textcoords="data",
        arrowprops=dict(arrowstyle="-", color=PALETTE["orange"], linewidth=0.65),
        ha="center",
        va="bottom",
        fontsize=6.0,
        color=PALETTE["orange"],
        fontweight="bold",
    )
    ax.set_title("STRING threshold", loc="left", fontweight="bold")
    ax.set_xlabel("Enumerated clique seeds")
    ax.set_yticks([])
    ax.set_xlim(0, max(seeds) * 1.2)
    ax.set_ylim(-0.48, len(thresholds) - 0.25)
    ax.xaxis.set_major_formatter(FuncFormatter(thousands_formatter))
    clean_axis(ax, "x")
    ax.text(-0.18, 0.5, "Threshold", transform=ax.transAxes, rotation=90, ha="center", va="center", fontsize=6.3, color=PALETTE["gray"])
    panel_label(ax, "c")

    save_figure(fig, "fig4_sensitivity_matrix")


def dot_panel(
    ax: plt.Axes,
    df: pd.DataFrame,
    value_col: str,
    title: str,
    xlabel: str,
    color_fn,
    note: str | None = None,
) -> None:
    values = pd.to_numeric(df[value_col], errors="coerce")
    labels = [short_label(s) for s in df["setting"]]
    y = np.arange(len(labels))
    colors = [color_fn(s) for s in df["setting"]]
    ax.hlines(y, 0, values, color=PALETTE["light_gray"], linewidth=0.8, zorder=1)
    ax.scatter(values, y, s=22, color=colors, edgecolor="white", linewidth=0.45, zorder=3)
    for yi, value in zip(y, values):
        ax.text(value + 0.025, yi, compact_number(value), va="center", ha="left", fontsize=6.0)
    ax.set_yticks(y)
    ax.set_yticklabels(labels)
    ax.invert_yaxis()
    ax.set_xlim(0, 1.08)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    if note:
        ax.text(0.98, 0.07, note, transform=ax.transAxes, ha="right", va="bottom", fontsize=6.0, color=PALETTE["gray"])
    clean_axis(ax, "x")


def figure5_ablation() -> None:
    cand = pd.read_csv(
        RESULTS_ROOT / "experiments" / "exp07_candidate_reduction_ablation"
        / "candidate_reduction_ablation.csv"
    )
    core = pd.read_csv(
        RESULTS_ROOT / "experiments" / "exp08_core_component_ablation"
        / "core_component_ablation.csv"
    )
    mod = pd.read_csv(
        RESULTS_ROOT / "experiments" / "exp09_module_construction_ablation"
        / "module_construction_ablation.csv"
    )
    fig = plt.figure(figsize=(7.15, 4.45))
    gs = GridSpec(2, 2, height_ratios=[1.0, 1.05], hspace=0.68, wspace=0.48, figure=fig)

    cand["runtime"] = pd.to_numeric(cand["runtime"], errors="coerce")
    full_runtime = float(cand[cand["setting"].eq("Full DiseaseAwareReduction")]["runtime"].iloc[0])
    cand["runtime_fold"] = cand["runtime"] / full_runtime
    cand = cand.set_index("setting").loc[["NodeOnly", "NoKnowledge", "RelaxedReduction", "EdgeOnly"]].reset_index()
    ax = fig.add_subplot(gs[0, 0])
    y = np.arange(len(cand))
    colors = [PALETTE["orange"] if s == "EdgeOnly" else PALETTE["mid_gray"] for s in cand["setting"]]
    ax.barh(y, cand["runtime_fold"], color=colors, height=0.54, edgecolor="none")
    ax.axvline(1, color=PALETTE["navy"], linestyle="--", linewidth=0.75)
    ax.text(1.02, -0.45, "CliqueBio = 1x", fontsize=6.2, color=PALETTE["navy"], ha="left", va="center")
    for yi, value in zip(y, cand["runtime_fold"]):
        ax.text(value + 0.28, yi, f"{value:.1f}x", va="center", ha="left", fontsize=6.2)
    ax.set_yticks(y)
    ax.set_yticklabels([short_label(s) for s in cand["setting"]])
    ax.invert_yaxis()
    ax.set_xlim(0, math.ceil(cand["runtime_fold"].max()) + 2)
    ax.set_title("Runtime effect of\ncandidate reduction", loc="left", fontweight="bold")
    ax.set_xlabel("Fold-change over CliqueBio")
    clean_axis(ax, "x")
    panel_label(ax, "a", x=-0.08)

    core = core.set_index("setting").loc[
        ["Full", "w/o degeneracy order", "w/o edge score", "w/o knowledge score", "w/o redundancy selection"]
    ].reset_index()
    ax = fig.add_subplot(gs[0, 1])
    core["avg_pairwise_jaccard"] = pd.to_numeric(core["avg_pairwise_jaccard"], errors="coerce")
    xvals = core["avg_pairwise_jaccard"].to_numpy(dtype=float)
    y_offsets = {
        "Full": 0.075,
        "w/o degeneracy order": -0.075,
        "w/o edge score": 0.0,
        "w/o knowledge score": -0.15,
        "w/o redundancy selection": 0.0,
    }
    y0 = np.array([y_offsets[s] for s in core["setting"]], dtype=float)
    ax.hlines(0, 0, 1, color=PALETTE["light_gray"], linewidth=2.2, zorder=1)
    ax.axvspan(0, 0.065, color="#EDF3F7", zorder=0)
    colors = [PALETTE["blue"] if s == "Full" else (PALETTE["orange"] if s == "w/o redundancy selection" else PALETTE["mid_gray"]) for s in core["setting"]]
    ax.scatter(xvals, y0, s=[44 if s in ["Full", "w/o redundancy selection"] else 28 for s in core["setting"]], color=colors, edgecolor="white", linewidth=0.7, zorder=3)
    low_cluster = core[core["setting"].ne("w/o redundancy selection")]["avg_pairwise_jaccard"]
    ax.annotate(
        f"Low-overlap cluster\n{low_cluster.min():.3f} to {low_cluster.max():.3f} Jaccard",
        (low_cluster.max(), 0.075),
        xytext=(0.12, 0.22),
        textcoords="data",
        arrowprops=dict(arrowstyle="-", color=PALETTE["gray"], linewidth=0.6),
        ha="left",
        va="bottom",
        fontsize=5.9,
        color=PALETTE["dark"],
    )
    no_red = core[core["setting"].eq("w/o redundancy selection")].iloc[0]
    ax.annotate(
        "No redundancy\n1.00 J",
        (no_red["avg_pairwise_jaccard"], y_offsets[no_red["setting"]]),
        xytext=(-10, 22),
        textcoords="offset points",
        ha="right",
        va="bottom",
        fontsize=6.0,
        color=PALETTE["orange"],
    )
    ax.set_xlim(-0.02, 1.05)
    ax.set_ylim(-0.32, 0.34)
    ax.set_yticks([])
    ax.set_xlabel("Pairwise Jaccard")
    ax.set_title("Redundancy-aware selection\nreduces overlap", loc="left", fontweight="bold")
    clean_axis(ax, "x")
    panel_label(ax, "b", x=-0.08)

    mod = mod.set_index("setting").loc[
        ["FullModuleConstruction", "IsolatedClique", "CliqueUnion", "CliquePercolation"]
    ].reset_index()
    ax = fig.add_subplot(gs[1, :])
    mod["avg_pairwise_jaccard"] = pd.to_numeric(mod["avg_pairwise_jaccard"], errors="coerce")
    mod["avg_clique_coverage"] = pd.to_numeric(mod["avg_clique_coverage"], errors="coerce")
    ax.add_patch(
        plt.Rectangle(
            (-0.04, 0.93),
            0.24,
            0.085,
            facecolor="#DCEEEF",
            edgecolor="none",
            alpha=0.7,
            zorder=0,
        )
    )
    ax.text(0.11, 1.012, "low-overlap, high-coverage region", fontsize=5.7, color=PALETTE["teal"], ha="center", va="top")
    colors = [
        PALETTE["blue"] if s == "FullModuleConstruction" else (PALETTE["orange"] if s == "CliquePercolation" else PALETTE["mid_gray"])
        for s in mod["setting"]
    ]
    sizes = [58 if s == "FullModuleConstruction" else 36 for s in mod["setting"]]
    ax.scatter(mod["avg_pairwise_jaccard"], mod["avg_clique_coverage"], s=sizes, color=colors, edgecolor="white", linewidth=0.8, zorder=3)
    offsets = {
        "FullModuleConstruction": (10, -17),
        "IsolatedClique": (8, 8),
        "CliqueUnion": (8, -17),
        "CliquePercolation": (-8, -17),
    }
    for _, row in mod.iterrows():
        dx, dy = offsets[row["setting"]]
        label = short_label(row["setting"])
        if row["setting"] == "FullModuleConstruction":
            label = (
                "CliqueBio\n"
                f"{row['avg_pairwise_jaccard']:.3f} J, "
                f"{row['avg_clique_coverage']:.2f} cov."
            )
        ax.annotate(
            label,
            (row["avg_pairwise_jaccard"], row["avg_clique_coverage"]),
            xytext=(dx, dy),
            textcoords="offset points",
            fontsize=6.1,
            ha="left" if dx > 0 else "right",
            va="center",
        )
    ax.set_xlim(-0.04, 1.08)
    ax.set_ylim(0.91, 1.02)
    ax.set_title("Coverage--redundancy trade-off", loc="left", fontweight="bold")
    ax.set_xlabel("Pairwise Jaccard")
    ax.set_ylabel("Structural clique coverage")
    clean_axis(ax)
    panel_label(ax, "c", x=-0.07)

    save_figure(fig, "fig5_ablation_effects")


def main() -> None:
    backend = set_publication_style()
    print(f"Using plotting style: {backend}")
    figure2_enumeration()
    figure3_scalability()
    figure4_sensitivity()
    figure5_ablation()
    print(f"Figures written to {OUT_DIR}")


if __name__ == "__main__":
    main()
