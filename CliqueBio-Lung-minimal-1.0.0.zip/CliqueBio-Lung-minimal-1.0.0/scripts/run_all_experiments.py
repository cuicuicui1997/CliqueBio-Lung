from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run(arguments: list[str], env: dict[str, str]) -> None:
    command = [sys.executable, *arguments]
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=ROOT, env=env, check=True)


def newest_run(result_root: Path) -> Path:
    candidates = [path for path in (result_root / "runs").glob("*") if path.is_dir()]
    if not candidates:
        raise FileNotFoundError(f"No pipeline run was created under {result_root / 'runs'}")
    return max(candidates, key=lambda path: path.stat().st_mtime)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Reproduce the CliqueBio-Lung pipeline and manuscript experiments."
    )
    parser.add_argument("--config", default="configs/phase1_luad.yaml")
    parser.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    parser.add_argument("--output-root", default="results")
    parser.add_argument(
        "--reuse-cache",
        action="store_true",
        help="Use an existing score cache instead of rebuilding it.",
    )
    parser.add_argument(
        "--prepare-data",
        action="store_true",
        help="Download and prepare the pinned UCSC Xena and STRING v12.0 inputs first.",
    )
    parser.add_argument(
        "--include-determinism",
        action="store_true",
        help="Also run the five-PYTHONHASHSEED regression (adds repeated work).",
    )
    parser.add_argument(
        "--skip-assets",
        action="store_true",
        help="Skip regeneration of manuscript tables and figures.",
    )
    args = parser.parse_args()

    output_root = (ROOT / args.output_root).resolve()
    cache_dir = (ROOT / args.cache_dir).resolve()
    config = str((ROOT / args.config).resolve())
    env = os.environ.copy()
    env["PYTHONHASHSEED"] = "2026"
    env["CLIQUEBIO_RESULT_ROOT"] = str(output_root)
    env["CLIQUEBIO_EXPERIMENT_ROOT"] = str(output_root / "experiments")

    if args.prepare_data:
        run(["scripts/prepare_tcga_luad_xena.py"], env)
        run(["scripts/prepare_string_physical_ppi.py"], env)

    run(["scripts/check_inputs.py", "--config", config], env)
    if args.reuse_cache:
        required_cache_files = {
            "cache_manifest.json",
            "edge_scores.csv",
            "node_scores.csv",
            "scored_ppi_edges.csv",
        }
        missing = sorted(
            name for name in required_cache_files if not (cache_dir / name).is_file()
        )
        if missing:
            raise FileNotFoundError(
                f"--reuse-cache was requested, but {cache_dir} is missing: "
                + ", ".join(missing)
            )
    else:
        run(["scripts/build_score_cache.py", "--config", config, "--cache-dir", str(cache_dir)], env)
    run(
        [
            "scripts/run_phase1.py",
            "--config",
            config,
            "--use-cache",
            "--cache-dir",
            str(cache_dir),
            "--output-dir",
            str(output_root),
        ],
        env,
    )
    run_dir = newest_run(output_root)
    env["CLIQUEBIO_DEFAULT_RUN_DIR"] = str(run_dir)

    for number in range(1, 10):
        name = next((ROOT / "scripts").glob(f"exp{number:02d}_*.py"))
        run([str(name.relative_to(ROOT)), "--config", config, "--cache-dir", str(cache_dir)], env)
    run(["scripts/exp10_biomedical_case_study.py", "--run-dir", str(run_dir)], env)

    run(
        [
            "scripts/run_baseline_comparison.py",
            "--config",
            config,
            "--cache-dir",
            str(cache_dir),
            "--output-dir",
            str(output_root / "baselines"),
        ],
        env,
    )
    run(
        [
            "scripts/run_objective_gap_small_instances.py",
            "--config",
            config,
            "--cache-dir",
            str(cache_dir),
            "--output-dir",
            str(output_root / "objective_gap"),
        ],
        env,
    )
    run(
        [
            "scripts/run_robustness_bootstrap.py",
            "--config",
            config,
            "--cache-dir",
            str(cache_dir),
            "--runs",
            "10",
            "--fraction",
            "0.8",
            "--output-dir",
            str(output_root / "robustness"),
        ],
        env,
    )
    run(
        [
            "scripts/run_leakage_reduced.py",
            "--config",
            config,
            "--cache-dir",
            str(cache_dir),
            "--output-dir",
            str(output_root / "leakage_reduced"),
        ],
        env,
    )

    if args.include_determinism:
        run(
            [
                "scripts/run_hash_seed_regression.py",
                "--config",
                config,
                "--cache-dir",
                str(cache_dir),
                "--output-dir",
                str(output_root / "determinism"),
            ],
            env,
        )

    if not args.skip_assets:
        run(["scripts/generate_manuscript_assets.py"], env)
        run(["scripts/make_experiment_tables.py"], env)
        run(["scripts/figure_replot/redesign_fgcs_figures.py"], env)

    print(f"Reproduction completed. Main run: {run_dir}")
    print(f"All results: {output_root}")


if __name__ == "__main__":
    main()
