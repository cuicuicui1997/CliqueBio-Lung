from __future__ import annotations

import argparse
import itertools
import time
from pathlib import Path

import networkx as nx
import pandas as pd

import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.clique_enum import enumerate_top_r_cliques
from src.graph_builder import build_candidate_graph
from src.pipeline import load_config
from src.scoring import clique_score


def split_genes(value: object) -> tuple[str, ...]:
    return tuple(sorted([x.strip().upper() for x in str(value).split(";") if x.strip()]))


def brute_force(graph: nx.Graph, r: int) -> set[tuple[str, ...]]:
    return {
        tuple(combo)
        for combo in itertools.combinations(sorted(graph.nodes()), r)
        if all(graph.has_edge(a, b) for a, b in itertools.combinations(combo, 2))
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare optimized clique enumeration with exact naive enumeration on small graphs.")
    parser.add_argument("--config", default="configs/phase1_luad.yaml")
    parser.add_argument("--run-dir", default=None)
    parser.add_argument("--cache-dir", default="data/processed/cache/phase1_luad_real")
    parser.add_argument("--output-dir", default="results/exact_check")
    args = parser.parse_args()
    config, _ = load_config(args.config)
    score_root = Path(args.run_dir) / "metrics" if args.run_dir else Path(args.cache_dir)
    node_scores = pd.read_csv(score_root / "node_scores.csv")
    edge_scores = pd.read_csv(score_root / "edge_scores.csv")
    node_scores = node_scores.drop(columns=[c for c in ["run_id", "experiment_mode"] if c in node_scores.columns])
    edge_scores = edge_scores.drop(columns=[c for c in ["run_id", "experiment_mode"] if c in edge_scores.columns])
    mechanism = pd.read_csv(config["paths"]["mechanism_gene_bank"], sep="\t")
    mechanism = mechanism.rename(columns={config["columns"]["mechanism_category"]: "mechanism_category"})

    rows = []
    for max_genes in [100, 150, 200]:
        cfg = {**config, "candidate_graph": {**config.get("candidate_graph", {}), "max_candidate_genes": max_genes}}
        graph, _ = build_candidate_graph(node_scores, edge_scores, mechanism, cfg)
        for r in [3, 4]:
            t0 = time.perf_counter()
            exact = brute_force(graph, r)
            exact_time = time.perf_counter() - t0
            t1 = time.perf_counter()
            opt, meta = enumerate_top_r_cliques(graph, r, max_clique_seeds=max(1, len(exact) + 10))
            opt_time = time.perf_counter() - t1
            opt_set = {split_genes(g) for g in opt.get("genes", [])}
            exact_top = max([clique_score(c, graph)["final_seed_score"] for c in exact], default=float("nan"))
            opt_top = pd.to_numeric(opt.get("final_seed_score", pd.Series(dtype=float)), errors="coerce").max()
            rows.append({
                "max_candidate_genes": max_genes,
                "r": r,
                "candidate_num_nodes": graph.number_of_nodes(),
                "candidate_num_edges": graph.number_of_edges(),
                "exact_cliques": len(exact),
                "optimized_cliques": len(opt_set),
                "sets_match": exact == opt_set,
                "top_seed_score_match": abs(exact_top - opt_top) < 1e-12 if pd.notna(exact_top) and pd.notna(opt_top) else len(exact) == 0,
                "exact_runtime": exact_time,
                "optimized_runtime": opt_time,
                "speedup": exact_time / opt_time if opt_time > 0 else float("inf"),
                "recursive_calls": meta.get("recursive_calls"),
                "intersection_calls": meta.get("intersection_calls"),
            })
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    df.to_csv(out_dir / "small_exact_comparison.csv", index=False)
    text = f"""# Small Exact Comparison

The optimized degeneracy-order enumeration was compared against naive combination-based exact enumeration using the same Phase 1.6 node and edge scores.

- settings: `max_candidate_genes in [100, 150, 200]`, `r in [3, 4]`
- all clique sets match: `{bool(df['sets_match'].all())}`
- all top seed scores match: `{bool(df['top_seed_score_match'].all())}`
- median speedup: `{df['speedup'].median()}`
- max exact cliques checked: `{int(df['exact_cliques'].max())}`

This supports enumeration correctness on small candidate graphs while keeping the production LUAD run focused on scalable problem-driven evaluation.
"""
    (out_dir / "SMALL_EXACT_COMPARISON.md").write_text(text, encoding="utf-8")
    print(out_dir / "small_exact_comparison.csv")


if __name__ == "__main__":
    main()
