from __future__ import annotations

import copy
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .baselines import build_baseline_modules
from .cache import load_score_cache
from .clique_enum import enumerate_top_r_cliques
from .data_io import load_discovery_inputs, load_optional_expression_metadata
from .evaluation import evaluate_modules
from .graph_builder import build_candidate_graph
from .module_builder import build_modules
from .scoring import compute_edge_scores, compute_node_scores
from .utils import (
    ensure_run_dirs,
    file_size_or_none,
    git_commit_hash,
    make_run_id,
    package_versions,
    project_root,
    read_yaml,
    resolve_path,
    set_random_seed,
    setup_logger,
    write_yaml,
)
from .visualization import (
    plot_graph_reduction,
    plot_module_auc,
    plot_node_distribution,
    plot_runtime,
    plot_seed_distribution,
    plot_top_module_network,
)


def _deep_merge(parent: dict[str, Any], child: dict[str, Any]) -> dict[str, Any]:
    merged = copy.deepcopy(parent)
    for key, value in child.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def load_config(config_path: str | Path) -> tuple[dict[str, Any], Path]:
    path = Path(config_path).resolve()
    config = read_yaml(path)
    inherited = config.pop("inherits", None)
    if inherited:
        parent_path = (path.parent / inherited).resolve()
        parent, _ = load_config(parent_path)
        config = _deep_merge(parent, config)
    config_directory = next((directory for directory in [path.parent, *path.parents] if directory.name == "configs"), None)
    base = config_directory.parent if config_directory is not None else project_root()
    return config, base


def apply_overrides(config: dict[str, Any], overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    cfg = copy.deepcopy(config)
    for dotted, value in (overrides or {}).items():
        target = cfg
        parts = dotted.split(".")
        for part in parts[:-1]:
            target = target.setdefault(part, {})
        target[parts[-1]] = value
    return cfg


def experiment_mode(config: dict[str, Any]) -> str:
    return str(config.get("experiment", {}).get("mode", "real")).lower()


def random_seed(config: dict[str, Any]) -> int:
    return int(config.get("experiment", {}).get("random_seed", config.get("random_seed", 42)))


def _input_paths(config: dict[str, Any], base: Path) -> dict[str, str | None]:
    paths = config.get("paths", {})
    keys = [
        "expression_matrix",
        "sample_metadata",
        "clinical_survival",
        "string_ppi",
        "mechanism_gene_bank",
        "external_validation_expression",
        "external_validation_metadata",
    ]
    return {key: str(resolve_path(paths.get(key), base)) if resolve_path(paths.get(key), base) is not None else None for key in keys}


def _validate_experiment_inputs(config: dict[str, Any], base: Path) -> None:
    mode = experiment_mode(config)
    if mode not in {"real", "toy", "smoke"}:
        raise ValueError("experiment.mode must be one of: real, toy, smoke")
    if mode != "real":
        return
    paths = _input_paths(config, base)
    required = config.get("data", {}).get("real_required_inputs", ["expression_matrix", "sample_metadata", "string_ppi"])
    missing = [key for key in required if not paths.get(key) or not Path(paths[key]).exists()]
    for key in ["clinical_survival", "mechanism_gene_bank"]:
        if paths.get(key) and not Path(paths[key]).exists():
            missing.append(key)
    ext_expr = paths.get("external_validation_expression")
    ext_meta = paths.get("external_validation_metadata")
    if bool(ext_expr) != bool(ext_meta):
        raise ValueError("External validation expression and metadata must be configured as a pair.")
    if ext_expr and (not Path(ext_expr).exists() or not Path(ext_meta).exists()):
        missing.extend(["external_validation_expression", "external_validation_metadata"])
    if missing:
        raise FileNotFoundError(f"real mode requires existing input files; missing: {sorted(set(missing))}")


def _tag(df: pd.DataFrame, config: dict[str, Any], run_id: str) -> pd.DataFrame:
    out = df.copy()
    mode = experiment_mode(config)
    if "experiment_mode" not in out.columns:
        out.insert(0, "experiment_mode", mode)
    if "run_id" not in out.columns:
        out.insert(0, "run_id", run_id)
    return out


def _manifest(config: dict[str, Any], config_path: Path, base: Path, r: int, run_id: str, dirs: dict[str, Path], start_time: datetime) -> dict[str, Any]:
    paths = _input_paths(config, base)
    return {
        "run_id": run_id,
        "experiment_mode": experiment_mode(config),
        "config_path": str(config_path),
        "config_content": config,
        "r": r,
        "random_seed": random_seed(config),
        "input_file_paths": paths,
        "input_file_sizes": {key: file_size_or_none(value) for key, value in paths.items()},
        "python_version": sys.version,
        "PYTHONHASHSEED": os.environ.get("PYTHONHASHSEED", "unset"),
        "package_versions": package_versions(),
        "survival_data_available": bool(paths.get("clinical_survival") and Path(paths["clinical_survival"]).exists()),
        "external_validation_available": bool(paths.get("external_validation_expression") and paths.get("external_validation_metadata")),
        "external_validation_participated_in_discovery": False,
        "mechanism_gene_bank_available": bool(paths.get("mechanism_gene_bank") and Path(paths["mechanism_gene_bank"]).exists()),
        "start_time": start_time.isoformat(),
        "end_time": None,
        "total_runtime": None,
        "output_directory": str(dirs["run"]),
        "git_commit_hash": git_commit_hash(base),
    }


def _avg_jaccard(modules: pd.DataFrame) -> float:
    from .utils import split_gene_list

    if len(modules) < 2:
        return 0.0
    vals = []
    sets = [set(split_gene_list(g)) for g in modules["genes"]]
    for i, a in enumerate(sets):
        for b in sets[i + 1 :]:
            vals.append(len(a & b) / len(a | b) if a | b else 0.0)
    return float(np.mean(vals)) if vals else 0.0


def _write_go_no_go_report(result: dict[str, Any], baseline_eval: pd.DataFrame, dirs: dict[str, Path], r: int) -> None:
    stats = result["graph_stats"].iloc[0] if not result["graph_stats"].empty else {}
    modules = result["modules"]
    eval_df = result["evaluation"]
    mode = experiment_mode(result["config"])
    best_auc = eval_df.loc[eval_df["cohort_role"] == "discovery", "AUC"].max() if not eval_df.empty else np.nan
    best_logp = eval_df["logrank_p"].min() if not eval_df.empty else np.nan
    best_c = eval_df["c_index"].max() if not eval_df.empty else np.nan
    baseline_best = baseline_eval["AUC"].max() if not baseline_eval.empty else np.nan
    avg_j = _avg_jaccard(modules)
    high_redundancy = avg_j >= result["config"].get("module", {}).get("redundancy_threshold", 0.5)
    has_mechanism = (modules.get("mechanism_genes", pd.Series(dtype=str)).fillna("").astype(str).str.len() > 0).any() if not modules.empty else False
    engineering_go = (
        bool(stats.get("candidate_num_nodes", 0) > 0)
        and bool(stats.get("candidate_num_edges", 0) > 0)
        and result["enum_meta"].get("num_retained_seeds", 0) > 0
        and len(modules) > 0
    )
    if mode in {"toy", "smoke"}:
        judgment = "Engineering Go only; toy/smoke results are not paper-usable"
    elif engineering_go and pd.notna(best_auc) and best_auc >= max(0.60, baseline_best if pd.notna(baseline_best) else 0.0):
        judgment = "Scientific Go candidate"
    elif engineering_go:
        judgment = "Needs More Data"
    else:
        judgment = "No-Go"
    size_range = "NA"
    if not modules.empty:
        size_range = f"{int(modules['size'].min())}-{int(modules['size'].max())}"
    text = f"""# GO / NO-GO Report

- run_id: `{result['run_id']}`
- experiment mode: `{mode}`
- r: `{r}`

## Engineering Checks

- candidate graph built: `{engineering_go}`
- candidate_num_nodes: `{stats.get('candidate_num_nodes', 'NA')}`
- candidate_num_edges: `{stats.get('candidate_num_edges', 'NA')}`
- density: `{stats.get('density', 'NA')}`
- degeneracy: `{stats.get('degeneracy', 'NA')}`
- enumerated r-cliques: `{result['enum_meta'].get('num_enumerated_cliques', 'NA')}`
- retained clique seeds: `{result['enum_meta'].get('num_retained_seeds', 'NA')}`
- top modules: `{len(modules)}`
- top module size range: `{size_range}`
- top modules average Jaccard overlap: `{avg_j:.4f}`
- highly redundant modules: `{high_redundancy}`
- mechanism gene bank overlap present: `{has_mechanism}`

## Medical Signals

- best discovery AUC: `{best_auc}`
- best survival log-rank p: `{best_logp}`
- best C-index: `{best_c}`
- best baseline discovery AUC: `{baseline_best}`

## Ablation Summary

Run `python scripts/run_ablation.py --config configs/phase1_luad.yaml` to generate `ablation_summary.csv` for this code/config family.

## Judgment

Current judgment: **{judgment}**

## Main Risks And Next Steps

- Confirm TCGA sample barcode truncation matches expression, metadata, and survival files.
- Inspect `input_check_report.*` before treating real-mode outputs as paper-usable.
- Compare full-model AUC and survival signal against `baseline_evaluation.csv`.
- If r=4 is slow, lower `candidate_graph.max_candidate_genes` for a pilot run, then scale carefully.
- Do not use toy or smoke outputs in manuscript figures or claims.
"""
    (dirs["run"] / "GO_NO_GO_report.md").write_text(text, encoding="utf-8")


def _peak_memory_mb() -> float | None:
    try:
        import psutil

        return float(psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024))
    except Exception:
        return None


def _write_algorithm_trace(result: dict[str, Any], dirs: dict[str, Path], r: int) -> None:
    stats = result["graph_stats"].iloc[0].to_dict() if not result["graph_stats"].empty else {}
    enum = result.get("enum_meta", {})
    module = result.get("module_meta", {})
    runtime = result.get("runtime", {})
    trace = {
        "original_num_nodes": stats.get("original_num_nodes"),
        "original_num_edges": stats.get("original_num_edges"),
        "candidate_num_nodes": stats.get("candidate_num_nodes"),
        "candidate_num_edges": stats.get("candidate_num_edges"),
        "reduction_node_ratio": stats.get("reduction_node_ratio"),
        "reduction_edge_ratio": stats.get("reduction_edge_ratio"),
        "degeneracy": stats.get("degeneracy"),
        "r": r,
        "recursive_calls": enum.get("recursive_calls"),
        "intersection_calls": enum.get("intersection_calls"),
        "candidate_extensions": enum.get("candidate_extensions"),
        "enumerated_cliques": enum.get("num_enumerated_cliques"),
        "retained_seeds": enum.get("num_retained_seeds"),
        "weighted_upper_bound_pruning": enum.get("weighted_upper_bound_pruning", False),
        "pruned_by_bound": enum.get("pruned_by_bound", 0),
        "pruned_by_candidate_size": enum.get("pruned_by_candidate_size"),
        "enumeration_time": runtime.get("runtime_enum"),
        "scoring_time": runtime.get("runtime_scoring"),
        "expansion_time": module.get("runtime_expansion"),
        "redundancy_selection_time": module.get("runtime_redundancy_selection"),
        "total_runtime": runtime.get("runtime_total"),
        "peak_memory_mb": _peak_memory_mb(),
        "notes": "upper-bound pruning not implemented in current Python prototype",
    }
    (dirs["metrics"] / "algorithm_trace.json").write_text(json.dumps(trace, indent=2, default=str), encoding="utf-8")
    pd.DataFrame([trace]).to_csv(dirs["metrics"] / "algorithm_trace.csv", index=False)


def run_phase1_pipeline(
    config_path: str | Path,
    r: int | None = None,
    overrides: dict[str, Any] | None = None,
    output_suffix: str = "",
    no_expansion: bool = False,
    redundancy: bool = True,
    ignore_knowledge: bool = False,
    use_cache: bool = False,
    cache_dir: str | Path | None = None,
) -> dict[str, Any]:
    config_path = Path(config_path).resolve()
    config, base = load_config(config_path)
    config = apply_overrides(config, overrides)
    if r is None:
        r = int(config.get("clique", {}).get("r", 3))
    config.setdefault("clique", {})["r"] = r
    _validate_experiment_inputs(config, base)
    set_random_seed(random_seed(config))
    out_dir = resolve_path(config.get("paths", {}).get("output_dir", "results"), base)
    start_wall = datetime.now()
    run_id = make_run_id(config, r, start_wall)
    dirs = ensure_run_dirs(out_dir, run_id)
    logger = setup_logger(log_file=dirs["logs"] / "run.log")
    suffix = f"_{output_suffix}" if output_suffix else ""
    write_yaml(config, dirs["run"] / "config_used.yaml")
    manifest = _manifest(config, config_path, base, r, run_id, dirs, start_wall)
    manifest["use_cache"] = bool(use_cache)
    manifest["cache_dir"] = str(resolve_path(str(cache_dir), base)) if use_cache and cache_dir else None
    (dirs["run"] / "run_manifest.json").write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")

    total_start = time.perf_counter()
    runtime: dict[str, float] = {}

    logger.info("Loading discovery inputs")
    inputs = load_discovery_inputs(config, base)
    if ignore_knowledge:
        inputs["mechanism"] = None

    node_notes: list[str] = []
    edge_notes: list[str] = []
    if use_cache:
        logger.info("Loading precomputed scoring cache")
        t = time.perf_counter()
        if cache_dir is None:
            raise ValueError("--use-cache requires --cache-dir")
        cache = load_score_cache(resolve_path(str(cache_dir), base))
        node_scores = cache["node_scores"]
        edge_scores = cache["edge_scores"]
        inputs["expression"] = cache["expression"]
        inputs["metadata"] = cache["metadata"]
        inputs["clinical"] = cache["clinical"]
        runtime["runtime_scoring"] = time.perf_counter() - t
        manifest["cache_manifest"] = cache.get("manifest", {})
    else:
        logger.info("Computing node and edge scores")
        t = time.perf_counter()
        node_scores, node_notes = compute_node_scores(inputs["expression"], inputs["metadata"], inputs["clinical"], inputs["mechanism"], config)
        edge_scores, edge_notes = compute_edge_scores(inputs["ppi"], inputs["expression"], inputs["mechanism"], config)
        runtime["runtime_scoring"] = time.perf_counter() - t
    _tag(node_scores, config, run_id).to_csv(dirs["metrics"] / f"node_scores{suffix}.csv", index=False)
    _tag(edge_scores, config, run_id).to_csv(dirs["metrics"] / f"edge_scores{suffix}.csv", index=False)

    logger.info("Building candidate graph")
    t = time.perf_counter()
    graph, graph_stats = build_candidate_graph(node_scores, edge_scores, inputs["mechanism"], config)
    runtime["runtime_graph"] = time.perf_counter() - t
    _tag(graph_stats, config, run_id).to_csv(dirs["metrics"] / f"graph_stats{suffix}.csv", index=False)
    if graph.number_of_nodes() == 0:
        raise RuntimeError("Candidate graph has zero nodes. Check STRING threshold, expression gene symbols, and min_edge_score.")

    if r == 4 and graph_stats.loc[0, "degeneracy"] >= 80:
        logger.warning("r=4 may be slow on this graph. Consider lowering max_candidate_genes or max_clique_seeds.")

    logger.info("Enumerating r=%s clique seeds", r)
    max_seeds = int(config.get("clique", {}).get("max_clique_seeds", 5000))
    seeds, enum_meta = enumerate_top_r_cliques(graph, r, max_seeds)
    runtime["runtime_enum"] = enum_meta["runtime_enum"]
    _tag(seeds, config, run_id).to_csv(dirs["modules"] / f"clique_seeds_r{r}{suffix}.csv", index=False)

    logger.info("Building clique-seeded modules")
    modules, module_meta = build_modules(graph, seeds, config, no_expansion=no_expansion, redundancy=redundancy)
    runtime["runtime_module"] = module_meta["runtime_module"]
    _tag(modules, config, run_id).to_csv(dirs["modules"] / f"top_modules{suffix}.csv", index=False)

    logger.info("Evaluating modules")
    t = time.perf_counter()
    evaluation = evaluate_modules(modules, inputs["expression"], inputs["metadata"], inputs["clinical"], config, "discovery", "discovery")
    try:
        ext_expr, ext_meta = load_optional_expression_metadata(config, base)
        if ext_expr is not None and ext_meta is not None:
            ext_eval = evaluate_modules(modules, ext_expr, ext_meta, None, config, "external", "external_validation")
            evaluation = pd.concat([evaluation, ext_eval], ignore_index=True)
    except FileNotFoundError as exc:
        logger.warning("External validation skipped: %s", exc)
    runtime["runtime_eval"] = time.perf_counter() - t
    _tag(evaluation, config, run_id).to_csv(dirs["metrics"] / f"module_evaluation{suffix}.csv", index=False)

    logger.info("Running baseline comparison inside frozen discovery run")
    reference_size = int(round(modules["size"].mean())) if not modules.empty else int(config.get("module", {}).get("min_module_size", 5))
    baseline_modules = build_baseline_modules(graph, reference_size, config)
    _tag(baseline_modules, config, run_id).to_csv(dirs["modules"] / f"baseline_modules{suffix}.csv", index=False)
    baseline_eval = evaluate_modules(baseline_modules, inputs["expression"], inputs["metadata"], inputs["clinical"], config, "discovery", "discovery")
    _tag(baseline_eval, config, run_id).to_csv(dirs["metrics"] / f"baseline_evaluation{suffix}.csv", index=False)

    logger.info("Generating figures")
    plot_node_distribution(node_scores, dirs["figures"] / f"node_score_distribution{suffix}.png")
    plot_graph_reduction(graph_stats, dirs["figures"] / f"candidate_graph_reduction{suffix}.png")
    plot_seed_distribution(seeds, r, dirs["figures"] / f"clique_seed_score_distribution_r{r}{suffix}.png")
    plot_runtime(runtime, dirs["figures"] / f"runtime_breakdown{suffix}.png")
    plot_top_module_network(graph, modules, dirs["figures"])
    plot_module_auc(evaluation[evaluation["cohort"] == "discovery"] if not evaluation.empty else evaluation, dirs["figures"] / f"module_auc_barplot{suffix}.png")

    runtime_total = time.perf_counter() - total_start
    summary = {
        "config": config,
        "graph": graph,
        "node_scores": node_scores,
        "edge_scores": edge_scores,
        "seeds": seeds,
        "modules": modules,
        "evaluation": evaluation,
        "graph_stats": graph_stats,
        "runtime": {**runtime, "runtime_total": runtime_total},
        "enum_meta": enum_meta,
        "module_meta": module_meta,
        "notes": node_notes + edge_notes,
        "dirs": dirs,
        "run_id": run_id,
        "baseline_modules": baseline_modules,
        "baseline_evaluation": baseline_eval,
    }
    _write_algorithm_trace(summary, dirs, r)
    _write_go_no_go_report(summary, baseline_eval, dirs, r)
    manifest["end_time"] = datetime.now().isoformat()
    manifest["total_runtime"] = runtime_total
    (dirs["run"] / "run_manifest.json").write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    logger.info("Phase 1 run complete in %.2fs", runtime_total)
    return summary
