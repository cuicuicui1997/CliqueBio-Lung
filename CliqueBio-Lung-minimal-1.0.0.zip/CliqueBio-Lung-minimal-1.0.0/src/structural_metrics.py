from __future__ import annotations

import itertools
from collections.abc import Iterable

import networkx as nx

from .canonical import vertex_key


def enumerate_r_cliques_exact(
    vertices: Iterable[str],
    graph: nx.Graph,
    r: int,
) -> list[tuple[str, ...]]:
    """Exactly enumerate all size-r cliques in the induced subgraph."""
    if r < 1:
        raise ValueError("r must be positive")
    nodes = vertex_key(set(vertices) & set(graph.nodes))
    if len(nodes) < r:
        return []
    cliques: list[tuple[str, ...]] = []
    for candidate in itertools.combinations(nodes, r):
        if all(graph.has_edge(left, right) for left, right in itertools.combinations(candidate, 2)):
            cliques.append(candidate)
    return cliques


def contains_r_clique_exact(vertices: Iterable[str], graph: nx.Graph, r: int) -> bool:
    """Exactly test clique presence without construction provenance."""
    if r < 1:
        raise ValueError("r must be positive")
    nodes = vertex_key(set(vertices) & set(graph.nodes))
    if len(nodes) < r:
        return False
    return any(
        all(graph.has_edge(left, right) for left, right in itertools.combinations(candidate, 2))
        for candidate in itertools.combinations(nodes, r)
    )


def structural_clique_metrics(vertices: Iterable[str], graph: nx.Graph, r: int) -> dict[str, object]:
    genes = set(vertices) & set(graph.nodes)
    cliques = enumerate_r_cliques_exact(genes, graph, r)
    covered = set().union(*map(set, cliques)) if cliques else set()
    coverage = len(covered) / len(genes) if genes else 0.0
    return {
        "structural_clique_count": len(cliques),
        "structural_clique_coverage": float(coverage),
        "structural_cliques": cliques,
    }


def feasible_module_exact(
    vertices: Iterable[str],
    graph: nx.Graph,
    r: int,
    min_size: int,
    max_size: int,
) -> bool:
    genes = set(vertices) & set(graph.nodes)
    return bool(
        min_size <= len(genes) <= max_size
        and genes
        and nx.is_connected(graph.subgraph(genes))
        and contains_r_clique_exact(genes, graph, r)
    )
