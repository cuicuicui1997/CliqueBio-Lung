"""CliqueBio-Lung Phase 1 feasibility prototype."""

