from __future__ import annotations

import networkx as nx
import numpy as np
import pandas as pd

from .canonical import canonical_component, gene_key


def _row(module_id: str, genes: list[str], graph: nx.Graph) -> dict:
    sub = graph.subgraph(genes)
    edges = list(sub.edges(data=True))
    return {
        "module_id": module_id,
        "genes": ";".join(sorted(genes)),
        "size": len(genes),
        "module_score": float(np.mean([graph.nodes[g].get("final_node_score", 0.0) for g in genes])) if genes else 0.0,
        "num_clique_seeds": 0,
        "best_seed_score": np.nan,
        "clique_coverage": np.nan,
        "avg_node_score": float(np.mean([graph.nodes[g].get("final_node_score", 0.0) for g in genes])) if genes else 0.0,
        "avg_edge_score": float(np.mean([d.get("final_edge_score", 0.0) for _, _, d in edges])) if edges else 0.0,
        "ppi_density": nx.density(sub) if len(sub) > 1 else 0.0,
        "avg_string_score": float(np.mean([d.get("STRING_score", 0.0) for _, _, d in edges])) if edges else 0.0,
        "mechanism_genes": ";".join(sorted([g for g in genes if graph.nodes[g].get("Knowledge_score", 0.0) > 0])),
        "mechanism_categories": "",
    }


def top_weight_genes(graph: nx.Graph, size: int) -> pd.DataFrame:
    genes = sorted(graph.nodes(), key=lambda gene: (-graph.nodes[gene].get("final_node_score", 0.0), gene_key(gene)))[:size]
    return pd.DataFrame([_row("baseline_top_weight_genes", genes, graph)])


def weighted_k_core(graph: nx.Graph, min_size: int = 5, max_size: int = 30) -> pd.DataFrame:
    if graph.number_of_nodes() == 0:
        return pd.DataFrame()
    core = nx.core_number(graph)
    rows = []
    for k in sorted(set(core.values()), reverse=True):
        sub = graph.subgraph([g for g, c in core.items() if c >= k])
        components = sorted(nx.connected_components(sub), key=lambda component: (-len(component), tuple(sorted(component, key=gene_key))))
        for comp in components:
            genes = sorted(comp, key=lambda gene: (-graph.nodes[gene].get("final_node_score", 0.0), gene_key(gene)))[:max_size]
            if len(genes) >= min_size:
                rows.append(_row(f"baseline_weighted_k_core_k{k}", genes, graph))
        if rows:
            break
    return pd.DataFrame(rows[:3])


def mcode_like(graph: nx.Graph, min_size: int = 5, max_size: int = 30) -> pd.DataFrame:
    scores = {}
    for g in graph.nodes():
        neigh = set(graph.neighbors(g)) | {g}
        sub = graph.subgraph(neigh)
        density = nx.density(sub) if len(sub) > 1 else 0
        scores[g] = density * graph.nodes[g].get("final_node_score", 0.0)
    rows = []
    used = set()
    for seed, _ in sorted(scores.items(), key=lambda item: (-item[1], gene_key(item[0]))):
        if seed in used:
            continue
        genes = {seed}
        boundary = set(graph.neighbors(seed))
        while len(genes) < max_size and boundary:
            best = sorted(boundary, key=lambda gene: (-scores.get(gene, 0.0), gene_key(gene)))[0]
            genes.add(best)
            boundary |= set(graph.neighbors(best))
            boundary -= genes
        if len(genes) >= min_size and nx.is_connected(graph.subgraph(genes)):
            rows.append(_row(f"baseline_mcode_like_{len(rows)+1}", sorted(genes), graph))
            used |= genes
        if len(rows) >= 3:
            break
    return pd.DataFrame(rows)


def build_baseline_modules(graph: nx.Graph, reference_avg_size: int, config: dict) -> pd.DataFrame:
    cfg = config.get("module", {})
    min_size = int(cfg.get("min_module_size", 5))
    max_size = int(cfg.get("max_module_size", 30))
    size = max(min_size, min(max_size, int(reference_avg_size or min_size)))
    frames = [
        top_weight_genes(graph, size),
        weighted_k_core(graph, min_size, max_size),
        mcode_like(graph, min_size, max_size),
    ]
    frames = [f for f in frames if not f.empty]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
