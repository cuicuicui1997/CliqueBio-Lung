from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from .scoring import label_vectors
from .utils import split_gene_list


def module_activity(expression: pd.DataFrame, genes: list[str]) -> pd.Series:
    available = [g for g in genes if g in expression.index]
    if not available:
        return pd.Series(index=expression.columns, dtype="float64")
    mat = expression.loc[available].astype(float)
    z = mat.sub(mat.mean(axis=1), axis=0).div(mat.std(axis=1).replace(0, np.nan), axis=0)
    return z.mean(axis=0)


def _auc_ci(y: np.ndarray, scores: np.ndarray, n_boot: int, seed: int) -> tuple[float, float, float, str]:
    valid = np.isfinite(scores)
    y = y[valid]
    scores = scores[valid]
    if len(np.unique(y)) < 2:
        return np.nan, np.nan, np.nan, "AUC skipped: cohort lacks both tumor and normal labels"
    auc = roc_auc_score(y, scores)
    auc = max(auc, 1 - auc)
    rng = np.random.default_rng(seed)
    boots = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(y), len(y))
        if len(np.unique(y[idx])) == 2:
            b = roc_auc_score(y[idx], scores[idx])
            boots.append(max(b, 1 - b))
    if boots:
        return float(auc), float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5)), "ok"
    return float(auc), np.nan, np.nan, "AUC CI skipped: bootstrap samples invalid"


def _survival(activity: pd.Series, clinical: pd.DataFrame | None, config: dict[str, Any]) -> tuple[float, float, float, str]:
    if clinical is None:
        return np.nan, np.nan, np.nan, "survival skipped: clinical_survival missing"
    try:
        from lifelines import CoxPHFitter
        from lifelines.statistics import logrank_test
        from lifelines.utils import concordance_index
    except ImportError:
        return np.nan, np.nan, np.nan, "survival skipped: lifelines not installed"
    cols = config.get("columns", {})
    sample_col = cols.get("sample_id", "sample_id")
    time_col = cols.get("os_time", "OS_time")
    status_col = cols.get("os_status", "OS_status")
    df = clinical.set_index(sample_col).join(activity.rename("activity"), how="inner")
    df = df[[time_col, status_col, "activity"]].apply(pd.to_numeric, errors="coerce").dropna()
    if len(df) < 10 or df[status_col].sum() < 3 or df["activity"].nunique() < 2:
        return np.nan, np.nan, np.nan, "survival skipped: insufficient events or activity variation"
    high = df["activity"] >= df["activity"].median()
    try:
        lr = logrank_test(df.loc[high, time_col], df.loc[~high, time_col], df.loc[high, status_col], df.loc[~high, status_col])
        cph = CoxPHFitter()
        cph.fit(df.rename(columns={time_col: "time", status_col: "status"}), duration_col="time", event_col="status", formula="activity")
        hr = float(np.exp(cph.params_["activity"]))
        cidx = float(concordance_index(df[time_col], df["activity"], df[status_col]))
        return float(lr.p_value), hr, cidx, "ok"
    except Exception as exc:
        return np.nan, np.nan, np.nan, f"survival skipped: {exc}"


def evaluate_modules(
    modules: pd.DataFrame,
    expression: pd.DataFrame,
    metadata: pd.DataFrame,
    clinical: pd.DataFrame | None,
    config: dict[str, Any],
    cohort: str = "discovery",
    cohort_role: str | None = None,
) -> pd.DataFrame:
    if modules.empty:
        return pd.DataFrame(columns=["module_id", "cohort", "cohort_role", "AUC", "AUC_CI_low", "AUC_CI_high", "logrank_p", "hazard_ratio", "c_index", "notes"])
    n_boot = int(config.get("evaluation", {}).get("auc_bootstrap", 200))
    seed = int(config.get("random_seed", 42))
    samples, y = label_vectors(metadata, config, list(expression.columns))
    expr = expression[samples]
    rows = []
    for row in modules.itertuples(index=False):
        genes = split_gene_list(row.genes)
        activity = module_activity(expr, genes)
        auc, lo, hi, auc_note = _auc_ci(y, activity.reindex(samples).values.astype(float), n_boot, seed)
        logp, hr, cidx, surv_note = _survival(activity, clinical, config)
        notes = "; ".join([x for x in [auc_note if auc_note != "ok" else "", surv_note if surv_note != "ok" else ""] if x]) or "ok"
        rows.append({
            "module_id": row.module_id,
            "cohort": cohort,
            "cohort_role": cohort_role or ("external_validation" if cohort != "discovery" else "discovery"),
            "AUC": auc,
            "AUC_CI_low": lo,
            "AUC_CI_high": hi,
            "logrank_p": logp,
            "hazard_ratio": hr,
            "c_index": cidx,
            "notes": notes,
        })
    return pd.DataFrame(rows)
