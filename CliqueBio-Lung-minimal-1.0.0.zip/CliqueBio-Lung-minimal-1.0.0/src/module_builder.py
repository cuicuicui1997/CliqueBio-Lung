from __future__ import annotations

import itertools
import time
from collections import defaultdict
from typing import Any

import networkx as nx
import numpy as np
import pandas as pd

from .utils import split_gene_list
from .canonical import canonical_component, canonical_induced_edges, gene_key, provenance_key, seed_key, seed_pair_key, vertex_key
from .structural_metrics import feasible_module_exact, structural_clique_metrics


def _jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / len(a | b) if a or b else 0.0


def _cross_edges(graph: nx.Graph, a: set[str], b: set[str]) -> int:
    count = 0
    for u in a - b:
        for v in b - a:
            if graph.has_edge(u, v):
                count += 1
    return count


def build_seed_adjacency(
    graph: nx.Graph,
    seed_sets: dict[str, set[str]],
    r: int,
    jac_thr: float,
    min_cross: int,
    max_pair_checks: int,
) -> tuple[dict[str, set[str]], list[tuple[str, str]]]:
    """Build the production seed graph with canonical pair generation."""
    seed_keys = {seed_id: seed_key(genes) for seed_id, genes in seed_sets.items()}
    adjacency: dict[str, set[str]] = defaultdict(set)
    by_gene: dict[str, list[str]] = defaultdict(list)
    for seed_id in sorted(seed_sets, key=lambda item: seed_keys[item]):
        for gene in sorted(seed_sets[seed_id], key=gene_key):
            by_gene[gene].append(seed_id)
    candidate_pairs: set[tuple[str, str]] = set()
    for gene in sorted(by_gene, key=gene_key):
        ids = sorted(by_gene[gene], key=lambda seed_id: seed_keys[seed_id])
        candidate_pairs.update(itertools.combinations(ids, 2))
    if len(seed_sets) <= 1000:
        ordered_ids = sorted(seed_sets, key=lambda seed_id: seed_keys[seed_id])
        candidate_pairs.update(itertools.combinations(ordered_ids, 2))
    ordered_pairs = sorted(candidate_pairs, key=lambda pair: seed_pair_key(pair, seed_keys))
    if len(seed_sets) > 1000:
        ordered_pairs = ordered_pairs[:max_pair_checks]
    for left, right in ordered_pairs:
        left_genes, right_genes = seed_sets[left], seed_sets[right]
        overlap = len(left_genes & right_genes)
        linked = (
            overlap >= r - 1
            or _jaccard(left_genes, right_genes) >= jac_thr
            or _cross_edges(graph, left_genes, right_genes) >= min_cross
        )
        if linked:
            adjacency[left].add(right)
            adjacency[right].add(left)
    return adjacency, ordered_pairs


def _module_metrics(graph: nx.Graph, genes: set[str], seed_ids: list[str], seed_sets: dict[str, set[str]], seed_scores: dict[str, float]) -> dict[str, Any]:
    sub = graph.subgraph(genes).copy()
    ordered_genes = vertex_key(genes)
    induced_edges = canonical_induced_edges(graph, ordered_genes)
    covered = set().union(*(seed_sets[s] for s in seed_ids)) if seed_ids else set()
    avg_node = float(np.mean([graph.nodes[g].get("final_node_score", 0.0) for g in ordered_genes])) if genes else 0.0
    avg_edge = float(np.mean([d.get("final_edge_score", 0.0) for _, _, d in induced_edges])) if induced_edges else 0.0
    avg_string = float(np.mean([d.get("STRING_score", 0.0) for _, _, d in induced_edges])) if induced_edges else 0.0
    provenance_coverage = len(covered & genes) / len(genes) if genes else 0.0
    knowledge_genes = [g for g in ordered_genes if graph.nodes[g].get("Knowledge_score", 0.0) > 0]
    seed_support = (len(seed_ids) / max(1, len(seed_sets))) * 0.5 + float(np.mean([seed_scores[s] for s in seed_ids])) * 0.5 if seed_ids else 0.0
    avg_seed = float(np.mean([seed_scores[s] for s in seed_ids])) if seed_ids else np.nan
    bio = len(knowledge_genes) / len(genes) if genes else 0.0
    module_score = 0.30 * seed_support + 0.25 * avg_node + 0.20 * avg_edge + 0.15 * provenance_coverage + 0.10 * bio
    cats = set()
    for g in knowledge_genes:
        raw = graph.nodes[g].get("mechanism_categories", "")
        cats.update([x for x in str(raw).split(";") if x])
    return {
        "size": len(genes),
        "module_score": float(module_score),
        "q_prod": float(module_score),
        "seed_support_score": float(seed_support),
        "seed_provenance_score": float(seed_support),
        "num_clique_seeds": len(seed_ids),
        "num_provenance_seeds": len(seed_ids),
        "best_seed_score": max([seed_scores[s] for s in seed_ids], default=np.nan),
        "avg_seed_score": avg_seed,
        "provenance_coverage": provenance_coverage,
        "avg_node_score": avg_node,
        "avg_edge_score": avg_edge,
        "ppi_density": nx.density(sub) if len(sub) > 1 else 0.0,
        "avg_string_score": avg_string,
        "redundancy_penalty": 0.0,
        "final_selection_score": float(module_score),
        "mechanism_gene_fraction": bio,
        "mechanism_genes": ";".join(sorted(knowledge_genes)),
        "mechanism_categories": ";".join(sorted(cats)),
    }


def _expand_or_trim(graph: nx.Graph, genes: set[str], min_size: int, max_size: int) -> set[str]:
    genes = set(genes)
    while len(genes) < min_size:
        boundary = set().union(*(set(graph.neighbors(g)) for g in genes)) - genes if genes else set()
        if not boundary:
            break
        def boundary_score(node: str) -> float:
            return float(graph.nodes[node].get("final_node_score", 0.0) + np.mean([
                graph.edges[node, old].get("final_edge_score", 0.0)
                for old in sorted(genes, key=gene_key) if graph.has_edge(node, old)
            ] or [0.0]))
        best = sorted(boundary, key=lambda node: (-boundary_score(node), gene_key(node)))[0]
        genes.add(best)
    while len(genes) > max_size:
        removable = [
            gene for gene in sorted(genes, key=gene_key)
            if graph.subgraph(genes - {gene}).number_of_nodes()
            and nx.is_connected(graph.subgraph(genes - {gene}))
        ]
        if not removable:
            break
        worst = min(
            removable,
            key=lambda node: (graph.nodes[node].get("final_node_score", 0.0) + graph.degree(node), gene_key(node)),
        )
        genes.remove(worst)
    if genes and not nx.is_connected(graph.subgraph(genes)):
        genes = canonical_component(nx.connected_components(graph.subgraph(genes)))
    return genes


def build_modules(graph: nx.Graph, seeds: pd.DataFrame, config: dict[str, Any], no_expansion: bool = False, redundancy: bool = True) -> tuple[pd.DataFrame, dict[str, Any]]:
    start = time.perf_counter()
    if seeds.empty:
        return pd.DataFrame(), {"runtime_module": time.perf_counter() - start, "num_modules": 0}
    expansion_start = time.perf_counter()
    cfg = config.get("module", {})
    r = int(seeds["r"].iloc[0])
    min_size = int(cfg.get("min_module_size", 5))
    max_size = int(cfg.get("max_module_size", 30))
    top_b = int(cfg.get("top_B_modules", cfg.get("top_b", 10)))
    jac_thr = float(cfg.get("clique_jaccard_threshold", 0.5))
    min_cross = int(cfg.get("min_cross_edges", 2))
    red_thr = float(cfg.get("redundancy_threshold", cfg.get("redundancy_jaccard_threshold", 0.5)))
    max_neighbors = int(cfg.get("max_seed_neighbors", 25))
    max_pair_checks = int(cfg.get("max_pair_checks", 2_000_000))

    seed_sets = dict(zip(seeds["seed_id"], seeds["genes"].map(lambda x: set(split_gene_list(x)))))
    seed_scores = dict(zip(seeds["seed_id"], seeds["final_seed_score"].astype(float)))
    seed_keys = {seed_id: seed_key(genes) for seed_id, genes in seed_sets.items()}
    adjacency, ordered_pairs = build_seed_adjacency(
        graph, seed_sets, r, jac_thr, min_cross, max_pair_checks
    )

    candidates = []
    sorted_seeds = sorted(seed_sets, key=lambda seed_id: (-seed_scores[seed_id], seed_keys[seed_id]))
    for sid in sorted_seeds:
        module_seed_ids = [sid]
        if not no_expansion:
            neigh = sorted(
                adjacency.get(sid, set()),
                key=lambda neighbor_id: (-seed_scores[neighbor_id], seed_keys[neighbor_id]),
            )[:max_neighbors]
            module_seed_ids.extend(neigh)
        genes = set().union(*(seed_sets[s] for s in module_seed_ids))
        if not no_expansion:
            genes = _expand_or_trim(graph, genes, min_size, max_size)
        if not feasible_module_exact(genes, graph, r, min_size, max_size):
            continue
        metrics = _module_metrics(graph, genes, module_seed_ids, seed_sets, seed_scores)
        candidates.append({
            "genes_set": genes,
            "seed_ids": tuple(module_seed_ids),
            "source_seed_id": sid,
            "source_seed_key": seed_keys[sid],
            "provenance_key": provenance_key(module_seed_ids, seed_keys),
            **metrics,
        })

    candidates = sorted(
        candidates,
        key=lambda item: (
            -item["module_score"],
            vertex_key(item["genes_set"]),
            item["source_seed_key"],
            item["provenance_key"],
        ),
    )
    expansion_time = time.perf_counter() - expansion_start
    selection_start = time.perf_counter()
    selected = []
    for item in candidates:
        max_redundancy = max([_jaccard(item["genes_set"], old["genes_set"]) for old in selected], default=0.0)
        item["redundancy_penalty"] = float(max_redundancy)
        item["final_selection_score"] = float(item["module_score"] * (1.0 - max_redundancy))
        if redundancy and max_redundancy >= red_thr:
            continue
        selected.append(item)
        if len(selected) >= top_b:
            break
    selection_time = time.perf_counter() - selection_start

    rows = []
    for i, item in enumerate(selected, start=1):
        genes_set = set(item["genes_set"])
        structural = structural_clique_metrics(genes_set, graph, r)
        row = {key: value for key, value in item.items() if key not in {"genes_set", "seed_ids"}}
        row["source_seed_key"] = ";".join(item["source_seed_key"])
        row["provenance_seed_ids"] = ";".join(item["seed_ids"])
        row["provenance_key"] = "|".join(";".join(key) for key in item["provenance_key"])
        row["structural_clique_count"] = structural["structural_clique_count"]
        row["structural_clique_coverage"] = structural["structural_clique_coverage"]
        row["clique_coverage"] = structural["structural_clique_coverage"]
        rows.append({"module_id": f"M{i:03d}", "genes": ";".join(vertex_key(genes_set)), "objective_rank": i, **row})
    return pd.DataFrame(rows), {
        "runtime_module": time.perf_counter() - start,
        "runtime_expansion": expansion_time,
        "runtime_redundancy_selection": selection_time,
        "num_module_candidates": len(candidates),
        "num_modules": len(rows),
        "num_rejected_infeasible": len(sorted_seeds) - len(candidates),
        "num_seed_pairs_tested": len(ordered_pairs),
    }
