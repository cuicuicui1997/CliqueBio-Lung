from __future__ import annotations

import heapq
import time
from dataclasses import dataclass, field
from typing import Any

import networkx as nx
import pandas as pd

from .scoring import clique_score


@dataclass(order=False)
class _HeapSeed:
    """Min-heap item whose root is the worst retained canonical seed."""

    score: float
    genes: tuple[str, ...]
    scores: dict[str, float] = field(compare=False)

    def __lt__(self, other: "_HeapSeed") -> bool:
        if self.score != other.score:
            return self.score < other.score
        return self.genes > other.genes

    def better_than(self, other: "_HeapSeed") -> bool:
        return self.score > other.score or (self.score == other.score and self.genes < other.genes)


def degeneracy_order(graph: nx.Graph) -> list[str]:
    core = nx.core_number(graph) if graph.number_of_nodes() else {}
    return sorted(graph.nodes(), key=lambda n: (core.get(n, 0), graph.degree(n), n))


def enumerate_top_r_cliques(graph: nx.Graph, r: int, max_clique_seeds: int = 5000) -> tuple[pd.DataFrame, dict[str, Any]]:
    start = time.perf_counter()
    if r < 2:
        raise ValueError("r must be >= 2")
    order = degeneracy_order(graph)
    pos = {v: i for i, v in enumerate(order)}
    total = 0
    recursive_calls = 0
    intersection_calls = 0
    candidate_extensions = 0
    pruned_by_candidate_size = 0
    heap: list[_HeapSeed] = []

    def keep(genes: tuple[str, ...]) -> None:
        nonlocal total
        total += 1
        scores = clique_score(genes, graph)
        item = _HeapSeed(float(scores["final_seed_score"]), genes, scores)
        if len(heap) < max_clique_seeds:
            heapq.heappush(heap, item)
        elif item.better_than(heap[0]):
            heapq.heapreplace(heap, item)

    def extend(prefix: tuple[str, ...], candidates: set[str]) -> None:
        nonlocal recursive_calls, intersection_calls, candidate_extensions, pruned_by_candidate_size
        recursive_calls += 1
        if len(prefix) == r:
            keep(tuple(sorted(prefix)))
            return
        need = r - len(prefix)
        if len(candidates) < need:
            pruned_by_candidate_size += 1
            return
        ordered_candidates = sorted(candidates, key=lambda x: pos[x])
        for i, v in enumerate(ordered_candidates):
            candidate_extensions += 1
            later = set(ordered_candidates[i + 1 :])
            intersection_calls += 1
            next_candidates = later.intersection(graph.neighbors(v))
            extend(prefix + (v,), next_candidates)

    for v in order:
        fwd = {n for n in graph.neighbors(v) if pos[n] > pos[v]}
        extend((v,), fwd)

    rows = []
    for idx, item in enumerate(sorted(heap, key=lambda x: (-x.score, x.genes)), start=1):
        rows.append({"seed_id": f"S{idx:05d}", "genes": ";".join(item.genes), "r": r, **item.scores})
    elapsed = time.perf_counter() - start
    meta = {
        "runtime_enum": elapsed,
        "num_enumerated_cliques": total,
        "num_retained_seeds": len(rows),
        "recursive_calls": recursive_calls,
        "intersection_calls": intersection_calls,
        "candidate_extensions": candidate_extensions,
        "pruned_by_candidate_size": pruned_by_candidate_size,
        "pruned_by_bound": 0,
        "weighted_upper_bound_pruning": False,
    }
    return pd.DataFrame(rows), meta
