from __future__ import annotations

import networkx as nx
import numpy as np
import pandas as pd

from .canonical import gene_key


def _threshold_to_unit(value: float) -> float:
    return value / 1000.0 if value > 1 else value


def build_candidate_graph(
    node_scores: pd.DataFrame,
    edge_scores: pd.DataFrame,
    mechanism: pd.DataFrame | None,
    config: dict,
) -> tuple[nx.Graph, pd.DataFrame]:
    cfg = config.get("candidate_graph", {})
    max_genes = int(cfg.get("max_candidate_genes", 1500))
    string_threshold = _threshold_to_unit(float(cfg.get("string_threshold", 700)))
    min_edge_score = float(cfg.get("min_edge_score", 0.5))

    node = node_scores.set_index("gene")
    category_map = {}
    if mechanism is not None and not mechanism.empty:
        category_map = {
            gene: ";".join(sorted(set(group["mechanism_category"].dropna().astype(str))))
            for gene, group in mechanism.groupby("gene")
        }
    expression_genes = set(node.index)
    ppi_genes = set(edge_scores["geneA"]) | set(edge_scores["geneB"])
    universe = expression_genes & ppi_genes

    ranked = (
        node.loc[sorted(universe, key=gene_key)]
        .assign(_gene_key=lambda frame: frame.index.map(gene_key))
        .sort_values(["final_node_score", "_gene_key"], ascending=[False, True], kind="mergesort")
        .drop(columns="_gene_key")
    )
    if cfg.get("keep_top_node_score_genes", True):
        candidates = set(ranked.head(max_genes).index)
    else:
        candidates = set(ranked.index)
    if cfg.get("always_keep_knowledge_genes", True) and mechanism is not None:
        candidates |= set(mechanism["gene"]) & universe

    original_edges = edge_scores[(edge_scores["geneA"].isin(universe)) & (edge_scores["geneB"].isin(universe))]
    filtered_edges = original_edges[
        (original_edges["geneA"].isin(candidates))
        & (original_edges["geneB"].isin(candidates))
        & (original_edges["STRING_score"] >= string_threshold)
        & (original_edges["final_edge_score"] >= min_edge_score)
    ]

    graph = nx.Graph()
    for gene, attrs in node.loc[sorted(candidates & set(node.index), key=gene_key)].iterrows():
        node_attrs = {k: float(attrs[k]) if pd.notna(attrs[k]) else 0.0 for k in attrs.index}
        node_attrs["mechanism_categories"] = category_map.get(gene, "")
        graph.add_node(gene, **node_attrs)
    filtered_edges = filtered_edges.assign(
        _left=filtered_edges[["geneA", "geneB"]].min(axis=1),
        _right=filtered_edges[["geneA", "geneB"]].max(axis=1),
    ).sort_values(["_left", "_right"], kind="mergesort")
    for row in filtered_edges.drop(columns=["_left", "_right"]).itertuples(index=False):
        graph.add_edge(row.geneA, row.geneB, **row._asdict())
    graph.remove_nodes_from(list(nx.isolates(graph)))

    original_nodes = len(universe)
    original_num_edges = len(original_edges)
    candidate_nodes = graph.number_of_nodes()
    candidate_edges = graph.number_of_edges()
    degeneracy = max(nx.core_number(graph).values()) if candidate_nodes else 0
    stats = pd.DataFrame([{
        "original_num_nodes": original_nodes,
        "original_num_edges": original_num_edges,
        "candidate_num_nodes": candidate_nodes,
        "candidate_num_edges": candidate_edges,
        "reduction_node_ratio": candidate_nodes / original_nodes if original_nodes else np.nan,
        "reduction_edge_ratio": candidate_edges / original_num_edges if original_num_edges else np.nan,
        "average_degree": 2 * candidate_edges / candidate_nodes if candidate_nodes else 0,
        "density": nx.density(graph) if candidate_nodes > 1 else 0,
        "degeneracy": degeneracy,
    }])
    return graph, stats
