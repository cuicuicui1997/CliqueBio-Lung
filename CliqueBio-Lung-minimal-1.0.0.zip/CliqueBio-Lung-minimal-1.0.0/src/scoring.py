from __future__ import annotations

import itertools
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score

from .utils import gene_key, normalize_01, weighted_sum_available


def label_vectors(metadata: pd.DataFrame, config: dict[str, Any], expression_columns: list[str]) -> tuple[list[str], np.ndarray]:
    cols = config.get("columns", {})
    sample_col = cols.get("sample_id", "sample_id")
    label_col = cols.get("label", "label")
    meta = metadata.set_index(sample_col).reindex([str(c) for c in expression_columns])
    y = []
    samples = []
    if "label_binary" in meta.columns:
        label_series = meta["label_binary"]
    else:
        labels_cfg = config.get("labels", {})
        tumor_values = {str(x).lower() for x in labels_cfg.get("tumor_values", ["tumor", "1"])}
        normal_values = {str(x).lower() for x in labels_cfg.get("normal_values", ["normal", "0"])}
        label_series = meta[label_col].map(lambda value: 1 if str(value).lower() in tumor_values else (0 if str(value).lower() in normal_values else None))
    for sample, label in label_series.items():
        if label == 1:
            y.append(1)
            samples.append(sample)
        elif label == 0:
            y.append(0)
            samples.append(sample)
    return samples, np.asarray(y, dtype=int)


def _cox_scores(expression: pd.DataFrame, clinical: pd.DataFrame | None, config: dict[str, Any]) -> tuple[pd.Series | None, str]:
    if clinical is None:
        return None, "survival data missing"
    try:
        from lifelines import CoxPHFitter
    except ImportError:
        return None, "lifelines not installed; Cox_score skipped"
    cols = config.get("columns", {})
    sample_col = cols.get("sample_id", "sample_id")
    time_col = cols.get("os_time", "OS_time")
    status_col = cols.get("os_status", "OS_status")
    common = [s for s in expression.columns.astype(str) if s in set(clinical[sample_col].astype(str))]
    if len(common) < 10:
        return None, "too few survival samples"
    clin = clinical.set_index(sample_col).reindex(common)
    scores = {}
    for gene, values in expression[common].iterrows():
        df = pd.DataFrame({
            "time": clin[time_col].values,
            "status": clin[status_col].values,
            "expr": pd.to_numeric(values, errors="coerce").values,
        }).dropna()
        if df["expr"].nunique() < 2 or df["status"].sum() < 3:
            scores[gene] = np.nan
            continue
        try:
            cph = CoxPHFitter()
            cph.fit(df, duration_col="time", event_col="status", formula="expr", show_progress=False)
            p = float(cph.summary.loc["expr", "p"])
            scores[gene] = -np.log10(max(p, 1e-300))
        except Exception:
            scores[gene] = np.nan
    return normalize_01(pd.Series(scores)), "ok"


def mechanism_maps(mechanism: pd.DataFrame | None) -> tuple[set[str], dict[str, set[str]]]:
    if mechanism is None or mechanism.empty:
        return set(), {}
    genes = set(mechanism["gene"].map(gene_key))
    categories: dict[str, set[str]] = {}
    for gene, group in mechanism.groupby("gene"):
        categories[gene_key(gene)] = set(group["mechanism_category"].dropna().astype(str))
    return genes, categories


def compute_node_scores(
    expression: pd.DataFrame,
    metadata: pd.DataFrame,
    clinical: pd.DataFrame | None,
    mechanism: pd.DataFrame | None,
    config: dict[str, Any],
) -> tuple[pd.DataFrame, list[str]]:
    notes: list[str] = []
    samples, y = label_vectors(metadata, config, list(expression.columns))
    expr = expression[samples]
    node_cfg = config.get("node_scoring", {})
    min_tumor = int(node_cfg.get("min_tumor_samples", 3))
    min_normal = int(node_cfg.get("min_normal_samples", 3))
    tumor_cols = [s for s, label in zip(samples, y) if label == 1]
    normal_cols = [s for s, label in zip(samples, y) if label == 0]

    out = pd.DataFrame(index=expression.index)
    available = []
    weights = node_cfg.get("weights", {})
    if weights.get("DE_score", 0.0) > 0 and len(tumor_cols) >= min_tumor and len(normal_cols) >= min_normal:
        tumor = expr[tumor_cols]
        normal = expr[normal_cols]
        logfc = tumor.mean(axis=1) - normal.mean(axis=1)
        pvals = []
        for gene in expression.index:
            _, p = stats.ttest_ind(tumor.loc[gene].dropna(), normal.loc[gene].dropna(), equal_var=False, nan_policy="omit")
            pvals.append(p if np.isfinite(p) else 1.0)
        raw = logfc.abs() * (-np.log10(np.maximum(pvals, 1e-300)))
        out["DE_score"] = normalize_01(pd.Series(raw, index=expression.index))
        available.append("DE_score")
    elif weights.get("DE_score", 0.0) > 0:
        out["DE_score"] = np.nan
        notes.append("DE_score skipped: insufficient tumor/normal samples")
    else:
        out["DE_score"] = np.nan
        notes.append("DE_score disabled by zero weight")

    auc_scores = {}
    if weights.get("AUC_score", 0.0) > 0 and len(np.unique(y)) == 2:
        for gene, row in expr.iterrows():
            values = pd.to_numeric(row, errors="coerce")
            valid = values.notna()
            if valid.sum() < 4 or len(np.unique(y[valid.values])) < 2:
                auc_scores[gene] = np.nan
                continue
            auc = roc_auc_score(y[valid.values], values[valid].values)
            auc_scores[gene] = max(auc, 1.0 - auc)
        out["AUC_score"] = normalize_01(pd.Series(auc_scores))
        available.append("AUC_score")
    elif weights.get("AUC_score", 0.0) > 0:
        out["AUC_score"] = np.nan
        notes.append("AUC_score skipped: labels do not contain both tumor and normal")
    else:
        out["AUC_score"] = np.nan
        notes.append("AUC_score disabled by zero weight")

    if weights.get("Cox_score", 0.0) <= 0:
        out["Cox_score"] = np.nan
        notes.append("Cox_score disabled by zero weight")
    else:
        cox, cox_note = _cox_scores(expression, clinical, config)
        if cox is not None:
            out["Cox_score"] = cox.reindex(expression.index)
            available.append("Cox_score")
        else:
            out["Cox_score"] = np.nan
            notes.append(f"Cox_score skipped: {cox_note}")

    out["Stability_score"] = np.nan
    notes.append("Stability_score omitted; remaining available node components are renormalized")

    mechanism_genes, _ = mechanism_maps(mechanism)
    if weights.get("Knowledge_score", 0.0) > 0 and mechanism_genes:
        out["Knowledge_score"] = [1.0 if g in mechanism_genes else 0.0 for g in expression.index]
        available.append("Knowledge_score")
    elif weights.get("Knowledge_score", 0.0) > 0:
        out["Knowledge_score"] = np.nan
        notes.append("Knowledge_score skipped: mechanism_gene_bank missing")
    else:
        out["Knowledge_score"] = np.nan
        notes.append("Knowledge_score disabled by zero weight")

    out["final_node_score"] = weighted_sum_available(out, weights, available)
    out = out.reset_index().rename(columns={out.index.name or "index": "gene"})
    return out, notes


def compute_edge_scores(
    ppi: pd.DataFrame,
    expression: pd.DataFrame,
    mechanism: pd.DataFrame | None,
    config: dict[str, Any],
) -> tuple[pd.DataFrame, list[str]]:
    notes: list[str] = []
    pathway_enabled = float(config.get("edge_scoring", {}).get("weights", {}).get("Pathway_score", 0.0)) > 0
    _, cat_map = mechanism_maps(mechanism) if pathway_enabled else (set(), {})
    expr_index = set(expression.index)
    rows = []
    for row in ppi.itertuples(index=False):
        u = gene_key(row.geneA)
        v = gene_key(row.geneB)
        raw_string = float(row.combined_score)
        string_score = raw_string / 1000.0 if raw_string > 1 else raw_string
        if u in expr_index and v in expr_index:
            a = expression.loc[u].astype(float)
            b = expression.loc[v].astype(float)
            valid = a.notna() & b.notna()
            coexpr = abs(float(np.corrcoef(a[valid], b[valid])[0, 1])) if valid.sum() >= 3 else 0.0
            if not np.isfinite(coexpr):
                coexpr = 0.0
        else:
            coexpr = 0.0
        pathway = np.nan
        if pathway_enabled and cat_map:
            pathway = 1.0 if cat_map.get(u, set()) & cat_map.get(v, set()) else 0.0
        rows.append((u, v, raw_string, string_score, coexpr, pathway))
    out = pd.DataFrame(rows, columns=["geneA", "geneB", "raw_STRING_score", "STRING_score", "CoExpr_score", "Pathway_score"])
    available = ["STRING_score", "CoExpr_score"]
    if pathway_enabled and cat_map:
        available.append("Pathway_score")
    elif pathway_enabled:
        notes.append("Pathway_score skipped: mechanism_gene_bank missing")
    else:
        notes.append("Pathway_score disabled by zero weight")
    out["final_edge_score"] = weighted_sum_available(out, config.get("edge_scoring", {}).get("weights", {}), available)
    return out, notes


def clique_score(genes: tuple[str, ...], graph, expression: pd.DataFrame | None = None) -> dict[str, float]:
    node_scores = [float(graph.nodes[g].get("final_node_score", 0.0)) for g in genes]
    knowledge_scores = [float(graph.nodes[g].get("Knowledge_score", 0.0)) for g in genes]
    node = np.mean(node_scores)
    knowledge = np.mean(knowledge_scores)
    edge_scores = []
    coexpr_scores = []
    for u, v in itertools.combinations(genes, 2):
        attrs = graph.edges[u, v]
        edge_scores.append(float(attrs.get("final_edge_score", 0.0)))
        coexpr_scores.append(float(attrs.get("CoExpr_score", 0.0)))
    edge = float(np.mean(edge_scores)) if edge_scores else 0.0
    coherence = float(np.mean(coexpr_scores)) if coexpr_scores else 0.0
    active_total = 0.35 + 0.30 + 0.15 + 0.10
    final = (
        0.35 * node
        + 0.30 * edge
        + 0.15 * knowledge
        + 0.10 * coherence
    ) / active_total
    return {
        "node_score": float(node),
        "edge_score": float(edge),
        "knowledge_score": float(knowledge),
        "stability_score": np.nan,
        "coherence_score": float(coherence),
        "final_seed_score": float(final),
        "all_edge_scores": ";".join(f"{x:.6g}" for x in edge_scores),
        "all_node_scores": ";".join(f"{x:.6g}" for x in node_scores),
    }
