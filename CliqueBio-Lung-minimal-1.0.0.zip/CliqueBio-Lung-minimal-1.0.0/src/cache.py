from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

from .data_io import load_discovery_inputs
from .scoring import compute_edge_scores, compute_node_scores
from .utils import file_size_or_none, git_commit_hash, resolve_path


def cache_paths(cache_dir: str | Path) -> dict[str, Path]:
    base = Path(cache_dir)
    return {
        "base": base,
        "node_scores": base / "node_scores.csv",
        "edge_scores": base / "edge_scores.csv",
        "scored_ppi_edges": base / "scored_ppi_edges.csv",
        "expression": base / "expression_aligned.tsv",
        "metadata": base / "sample_metadata_aligned.tsv",
        "survival": base / "survival_aligned.tsv",
        "manifest": base / "cache_manifest.json",
    }


def build_score_cache(config: dict[str, Any], config_path: Path, base: Path, cache_dir: str | Path) -> dict[str, Any]:
    paths = cache_paths(cache_dir)
    paths["base"].mkdir(parents=True, exist_ok=True)
    inputs = load_discovery_inputs(config, base)
    node_scores, node_notes = compute_node_scores(inputs["expression"], inputs["metadata"], inputs["clinical"], inputs["mechanism"], config)
    edge_scores, edge_notes = compute_edge_scores(inputs["ppi"], inputs["expression"], inputs["mechanism"], config)

    node_scores.to_csv(paths["node_scores"], index=False)
    edge_scores.to_csv(paths["edge_scores"], index=False)
    edge_scores.to_csv(paths["scored_ppi_edges"], index=False)
    inputs["expression"].to_csv(paths["expression"], sep="\t")
    inputs["metadata"].to_csv(paths["metadata"], sep="\t", index=False)
    if inputs["clinical"] is not None:
        inputs["clinical"].to_csv(paths["survival"], sep="\t", index=False)
    elif paths["survival"].exists():
        paths["survival"].unlink()

    input_cfg = config.get("paths", {})
    input_file_paths = {
        key: str(resolve_path(input_cfg.get(key), base)) if resolve_path(input_cfg.get(key), base) else None
        for key in ["expression_matrix", "sample_metadata", "clinical_survival", "string_ppi", "mechanism_gene_bank"]
    }
    manifest = {
        "config_path": str(config_path),
        "input_file_paths": input_file_paths,
        "input_file_sizes": {key: file_size_or_none(value) for key, value in input_file_paths.items()},
        "number_of_expression_genes": int(inputs["expression"].shape[0]),
        "number_of_samples": int(inputs["expression"].shape[1]),
        "number_of_node_scores": int(len(node_scores)),
        "number_of_scored_ppi_edges": int(len(edge_scores)),
        "creation_time": datetime.now().isoformat(),
        "git_commit_hash": git_commit_hash(base),
        "random_seed": int(config.get("experiment", {}).get("random_seed", config.get("random_seed", 42))),
        "python_version": sys.version,
        "notes": node_notes + edge_notes + ["discovery scoring cache only; external validation must not recompute module discovery."],
    }
    paths["manifest"].write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    return manifest


def load_score_cache(cache_dir: str | Path) -> dict[str, Any]:
    paths = cache_paths(cache_dir)
    missing = [name for name in ["node_scores", "edge_scores", "expression", "metadata", "manifest"] if not paths[name].exists()]
    if missing:
        raise FileNotFoundError(f"Scoring cache is incomplete at {paths['base']}; missing: {missing}")
    manifest = json.loads(paths["manifest"].read_text(encoding="utf-8"))
    expression = pd.read_csv(paths["expression"], sep="\t", index_col=0)
    metadata = pd.read_csv(paths["metadata"], sep="\t")
    clinical = pd.read_csv(paths["survival"], sep="\t") if paths["survival"].exists() else None
    return {
        "node_scores": pd.read_csv(paths["node_scores"]),
        "edge_scores": pd.read_csv(paths["edge_scores"]),
        "expression": expression,
        "metadata": metadata,
        "clinical": clinical,
        "manifest": manifest,
    }
