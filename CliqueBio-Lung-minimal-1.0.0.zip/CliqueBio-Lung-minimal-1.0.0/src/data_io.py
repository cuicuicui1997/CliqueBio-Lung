from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .utils import gene_key, normalize_sample_id, read_table_auto, resolve_path


def _data_cfg(config: dict[str, Any] | None) -> dict[str, Any]:
    return (config or {}).get("data", {})


def _tcga_truncate(config: dict[str, Any] | None) -> int | None:
    value = _data_cfg(config).get("tcga_barcode_truncate")
    return int(value) if value not in (None, "", False) else None


def _find_gene_column(df: pd.DataFrame, config: dict[str, Any] | None) -> str:
    configured = (config or {}).get("columns", {}).get("gene")
    candidates = [configured, "GeneSymbol", "gene_symbol", "gene", "Gene", "symbol", "Symbol"]
    for col in candidates:
        if col and col in df.columns:
            return col
    return str(df.columns[0])


def _collapse_expression(df: pd.DataFrame, method: str) -> pd.DataFrame:
    if not df.index.has_duplicates:
        return df
    if method != "mean":
        raise ValueError(f"Unsupported duplicated_gene_collapse method: {method}")
    return df.groupby(level=0).mean(numeric_only=True)


def _maybe_log2_transform(df: pd.DataFrame, config: dict[str, Any] | None) -> pd.DataFrame:
    cfg = _data_cfg(config)
    if bool(cfg.get("expression_already_log2", False)):
        return df
    force = bool(cfg.get("expression_log2_transform", False))
    auto = bool(cfg.get("auto_detect_log2", True))
    values = df.to_numpy(dtype=float)
    finite = values[np.isfinite(values)]
    looks_raw = finite.size > 0 and (np.nanmax(finite) > 50 or np.nanpercentile(finite, 95) > 20)
    if force or (auto and looks_raw):
        if np.nanmin(finite) < 0:
            raise ValueError("Cannot log2(x+1) transform expression containing negative values.")
        return np.log2(df + 1.0)
    return df


def load_expression(path: str | Path, config: dict[str, Any] | None = None) -> pd.DataFrame:
    df = read_table_auto(path)
    if df.empty:
        raise ValueError(f"Expression matrix is empty: {path}")
    gene_col = _find_gene_column(df, config)
    df[gene_col] = df[gene_col].map(gene_key)
    df = df[df[gene_col].astype(str).str.len() > 0]
    df = df.set_index(gene_col)
    truncate = _tcga_truncate(config)
    df.columns = [normalize_sample_id(c, truncate) for c in df.columns]
    df = df.apply(pd.to_numeric, errors="coerce")
    if pd.Index(df.columns).has_duplicates:
        df = df.T.groupby(level=0).mean(numeric_only=True).T
    df = _collapse_expression(df, _data_cfg(config).get("duplicated_gene_collapse", "mean"))
    df = _maybe_log2_transform(df, config)
    if df.shape[1] == 0:
        raise ValueError("Expression matrix must have sample columns after the first gene column.")
    return df


def map_label(value: Any, config: dict[str, Any]) -> int | None:
    labels_cfg = config.get("labels", {})
    tumor_values = {str(x).lower() for x in labels_cfg.get("tumor_values", ["tumor", "1"])}
    normal_values = {str(x).lower() for x in labels_cfg.get("normal_values", ["normal", "0"])}
    key = str(value).strip().lower()
    if key in tumor_values:
        return 1
    if key in normal_values:
        return 0
    return None


def load_sample_metadata(path: str | Path, sample_col: str, label_col: str, config: dict[str, Any] | None = None) -> pd.DataFrame:
    df = read_table_auto(path)
    missing = {sample_col, label_col} - set(df.columns)
    if missing:
        raise ValueError(f"sample_metadata missing required columns: {sorted(missing)}")
    truncate = _tcga_truncate(config)
    df[sample_col] = df[sample_col].map(lambda x: normalize_sample_id(x, truncate))
    if config is not None:
        df["label_binary"] = df[label_col].map(lambda x: map_label(x, config))
    return df.drop_duplicates(subset=[sample_col], keep="first")


def map_survival_status(value: Any) -> int | None:
    if pd.isna(value):
        return None
    key = str(value).strip().lower()
    event_values = {"1", "event", "dead", "deceased", "death", "true", "yes"}
    censored_values = {"0", "censored", "alive", "living", "false", "no"}
    if key in event_values:
        return 1
    if key in censored_values:
        return 0
    try:
        num = float(key)
        if num in (0.0, 1.0):
            return int(num)
    except ValueError:
        pass
    return None


def load_clinical_survival(path: str | Path | None, sample_col: str, time_col: str, status_col: str, config: dict[str, Any] | None = None) -> pd.DataFrame | None:
    if path is None:
        return None
    df = read_table_auto(path)
    missing = {sample_col, time_col, status_col} - set(df.columns)
    if missing:
        raise ValueError(f"clinical_survival missing required columns: {sorted(missing)}")
    truncate = _tcga_truncate(config)
    df[sample_col] = df[sample_col].map(lambda x: normalize_sample_id(x, truncate))
    df[time_col] = pd.to_numeric(df[time_col], errors="coerce")
    df[status_col] = df[status_col].map(map_survival_status)
    return df.drop_duplicates(subset=[sample_col], keep="first")


def load_string_ppi(path: str | Path, gene_a_col: str, gene_b_col: str, score_col: str) -> pd.DataFrame:
    df = read_table_auto(path)
    missing = {gene_a_col, gene_b_col, score_col} - set(df.columns)
    if missing:
        raise ValueError(f"string_ppi missing required columns: {sorted(missing)}")
    out = df[[gene_a_col, gene_b_col, score_col]].copy()
    out.columns = ["geneA", "geneB", "combined_score"]
    out["geneA"] = out["geneA"].map(gene_key)
    out["geneB"] = out["geneB"].map(gene_key)
    out["combined_score"] = pd.to_numeric(out["combined_score"], errors="coerce")
    out = out.dropna(subset=["geneA", "geneB", "combined_score"])
    out = out[out["geneA"] != out["geneB"]]
    a = out[["geneA", "geneB"]].min(axis=1)
    b = out[["geneA", "geneB"]].max(axis=1)
    out["geneA"], out["geneB"] = a, b
    return out.sort_values("combined_score", ascending=False).drop_duplicates(subset=["geneA", "geneB"], keep="first")


def load_mechanism_bank(path: str | Path | None, gene_col: str, category_col: str) -> pd.DataFrame | None:
    if path is None:
        return None
    df = read_table_auto(path)
    missing = {gene_col, category_col} - set(df.columns)
    if missing:
        raise ValueError(f"mechanism_gene_bank missing required columns: {sorted(missing)}")
    out = df[[gene_col, category_col]].copy()
    out.columns = ["gene", "mechanism_category"]
    out["gene"] = out["gene"].map(gene_key)
    out["mechanism_category"] = out["mechanism_category"].astype(str).str.strip()
    return out.dropna(subset=["gene"]).drop_duplicates()


def load_optional_expression_metadata(config: dict[str, Any], base: Path) -> tuple[pd.DataFrame | None, pd.DataFrame | None]:
    paths = config.get("paths", {})
    cols = config.get("columns", {})
    expr_path = resolve_path(paths.get("external_validation_expression"), base)
    meta_path = resolve_path(paths.get("external_validation_metadata"), base)
    if expr_path is None and meta_path is None:
        return None, None
    if expr_path is None or meta_path is None:
        raise ValueError("Both external_validation_expression and external_validation_metadata must be provided together.")
    return (
        load_expression(expr_path, config),
        load_sample_metadata(meta_path, cols.get("sample_id", "sample_id"), cols.get("label", "label"), config),
    )


def load_discovery_inputs(config: dict[str, Any], base: Path) -> dict[str, Any]:
    paths = config.get("paths", {})
    cols = config.get("columns", {})
    expression = load_expression(resolve_path(paths.get("expression_matrix"), base), config)
    metadata = load_sample_metadata(
        resolve_path(paths.get("sample_metadata"), base),
        cols.get("sample_id", "sample_id"),
        cols.get("label", "label"),
        config,
    )
    clinical_path = resolve_path(paths.get("clinical_survival"), base)
    clinical = load_clinical_survival(
        clinical_path,
        cols.get("sample_id", "sample_id"),
        cols.get("os_time", "OS_time"),
        cols.get("os_status", "OS_status"),
        config,
    ) if clinical_path is not None and clinical_path.exists() else None
    ppi = load_string_ppi(
        resolve_path(paths.get("string_ppi"), base),
        cols.get("gene_a", "geneA"),
        cols.get("gene_b", "geneB"),
        cols.get("string_score", "combined_score"),
    )
    mechanism_path = resolve_path(paths.get("mechanism_gene_bank"), base)
    mechanism = load_mechanism_bank(
        mechanism_path,
        cols.get("mechanism_gene", "gene"),
        cols.get("mechanism_category", "mechanism_category"),
    ) if mechanism_path is not None and mechanism_path.exists() else None
    return {"expression": expression, "metadata": metadata, "clinical": clinical, "ppi": ppi, "mechanism": mechanism}
