from __future__ import annotations

from collections.abc import Iterable

import networkx as nx


def gene_key(gene: object) -> str:
    """Return the repository-wide canonical key for a graph vertex."""
    return str(gene)


def vertex_key(vertices: Iterable[object]) -> tuple[str, ...]:
    return tuple(sorted((gene_key(vertex) for vertex in vertices)))


def seed_key(vertices: Iterable[object]) -> tuple[str, ...]:
    return vertex_key(vertices)


def seed_pair_key(
    pair: tuple[str, str],
    seed_keys: dict[str, tuple[str, ...]],
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    left, right = seed_keys[pair[0]], seed_keys[pair[1]]
    return (left, right) if left <= right else (right, left)


def provenance_key(
    seed_ids: Iterable[str],
    seed_keys: dict[str, tuple[str, ...]],
) -> tuple[tuple[str, ...], ...]:
    return tuple(sorted(seed_keys[seed_id] for seed_id in seed_ids))


def canonical_component(components: Iterable[Iterable[object]]) -> set[object]:
    """Choose maximum size, then the lexicographically smallest vertex tuple."""
    materialized = [(set(component), vertex_key(component)) for component in components]
    if not materialized:
        return set()
    return min(materialized, key=lambda item: (-len(item[0]), item[1]))[0]


def canonical_induced_edges(graph: nx.Graph, vertices: Iterable[object]) -> list[tuple[object, object, dict]]:
    nodes = list(vertex_key(vertices))
    return [
        (left, right, graph.edges[left, right])
        for index, left in enumerate(nodes)
        for right in nodes[index + 1 :]
        if graph.has_edge(left, right)
    ]
