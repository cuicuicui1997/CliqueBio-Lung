from __future__ import annotations

import time
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import pandas as pd

from .utils import split_gene_list


def plot_node_distribution(node_scores: pd.DataFrame, out: Path) -> None:
    plt.figure(figsize=(5, 3.2))
    node_scores["final_node_score"].hist(bins=40, color="#4C78A8")
    plt.xlabel("Final node score")
    plt.ylabel("Genes")
    plt.tight_layout()
    plt.savefig(out, dpi=200)
    plt.close()


def plot_graph_reduction(stats: pd.DataFrame, out: Path) -> None:
    row = stats.iloc[0]
    plt.figure(figsize=(5, 3.2))
    plt.bar(["nodes", "edges"], [row["reduction_node_ratio"], row["reduction_edge_ratio"]], color=["#4C78A8", "#F58518"])
    plt.ylabel("Candidate / original")
    plt.ylim(0, 1.05)
    plt.tight_layout()
    plt.savefig(out, dpi=200)
    plt.close()


def plot_seed_distribution(seeds: pd.DataFrame, r: int, out: Path) -> None:
    plt.figure(figsize=(5, 3.2))
    if not seeds.empty:
        seeds["final_seed_score"].hist(bins=40, color="#54A24B")
    plt.xlabel(f"r={r} clique seed score")
    plt.ylabel("Seeds")
    plt.tight_layout()
    plt.savefig(out, dpi=200)
    plt.close()


def plot_runtime(runtime: dict[str, Any], out: Path) -> None:
    keys = [k for k in ["runtime_scoring", "runtime_graph", "runtime_enum", "runtime_module", "runtime_eval"] if k in runtime]
    vals = [runtime[k] for k in keys]
    plt.figure(figsize=(6, 3.2))
    plt.bar([k.replace("runtime_", "") for k in keys], vals, color="#72B7B2")
    plt.ylabel("Seconds")
    plt.tight_layout()
    plt.savefig(out, dpi=200)
    plt.close()


def plot_module_auc(evaluation: pd.DataFrame, out: Path) -> None:
    plt.figure(figsize=(6, 3.4))
    if not evaluation.empty and "AUC" in evaluation:
        df = evaluation.sort_values("AUC", ascending=False)
        plt.bar(df["module_id"], df["AUC"], color="#E45756")
        plt.xticks(rotation=45, ha="right")
        plt.ylim(0.45, 1.0)
    plt.ylabel("Diagnostic AUC")
    plt.tight_layout()
    plt.savefig(out, dpi=200)
    plt.close()


def plot_top_module_network(graph: nx.Graph, modules: pd.DataFrame, out_dir: Path) -> None:
    if modules.empty:
        return
    row = modules.iloc[0]
    genes = split_gene_list(row["genes"])
    sub = graph.subgraph(genes)
    plt.figure(figsize=(6, 5))
    pos = nx.spring_layout(sub, seed=42)
    node_colors = [sub.nodes[g].get("final_node_score", 0.0) for g in sub.nodes()]
    nx.draw_networkx_edges(sub, pos, alpha=0.35, width=0.8)
    nx.draw_networkx_nodes(sub, pos, node_color=node_colors, cmap="viridis", node_size=320)
    nx.draw_networkx_labels(sub, pos, font_size=7)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(out_dir / f"top_module_network_{row['module_id']}.png", dpi=220)
    plt.close()


def plot_ablation(summary: pd.DataFrame, out: Path) -> None:
    plt.figure(figsize=(7, 3.4))
    if not summary.empty:
        plt.bar(summary["setting"].astype(str), summary["best_auc"], color="#B279A2")
        plt.xticks(rotation=45, ha="right")
        plt.ylim(0.45, 1.0)
    plt.ylabel("Best AUC")
    plt.tight_layout()
    plt.savefig(out, dpi=200)
    plt.close()

