from __future__ import annotations

import logging
import math
import platform
import random
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def resolve_path(path: str | None, base: Path | None = None) -> Path | None:
    if path in (None, ""):
        return None
    p = Path(path)
    if not p.is_absolute():
        p = (base or project_root()) / p
    return p


def read_yaml(path: str | Path) -> dict[str, Any]:
    try:
        import yaml
    except ImportError as exc:
        raise RuntimeError("PyYAML is required to read config files. Install with: pip install pyyaml") from exc
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def write_yaml(data: dict[str, Any], path: str | Path) -> None:
    try:
        import yaml
    except ImportError as exc:
        raise RuntimeError("PyYAML is required to write config files. Install with: pip install pyyaml") from exc
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)


def setup_logger(name: str = "cliquebio", level: int = logging.INFO, log_file: str | Path | None = None) -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers and log_file is None:
        return logger
    logger.setLevel(level)
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s", "%H:%M:%S")
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    if log_file is not None:
        path = Path(log_file)
        path.parent.mkdir(parents=True, exist_ok=True)
        if not any(isinstance(h, logging.FileHandler) and Path(h.baseFilename) == path for h in logger.handlers):
            file_handler = logging.FileHandler(path, encoding="utf-8")
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
    return logger


def set_random_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)


def ensure_output_dirs(output_dir: str | Path) -> dict[str, Path]:
    out = Path(output_dir)
    dirs = {
        "output": out,
        "modules": out / "modules",
        "metrics": out / "metrics",
        "figures": out / "figures",
    }
    for p in dirs.values():
        p.mkdir(parents=True, exist_ok=True)
    return dirs


def make_run_id(config: dict[str, Any], r: int, timestamp: datetime | None = None) -> str:
    exp = config.get("experiment", {})
    run_name = str(exp.get("run_name") or config.get("project_name", "cliquebio")).strip().replace(" ", "_")
    cohort = str(exp.get("cohort", "cohort")).strip().replace(" ", "_")
    ts = (timestamp or datetime.now()).strftime("%Y%m%d_%H%M%S")
    return f"{run_name}_{cohort}_r{r}_{ts}"


def ensure_run_dirs(output_dir: str | Path, run_id: str) -> dict[str, Path]:
    run_dir = Path(output_dir) / "runs" / run_id
    dirs = {
        "output": run_dir,
        "run": run_dir,
        "modules": run_dir / "modules",
        "metrics": run_dir / "metrics",
        "figures": run_dir / "figures",
        "logs": run_dir / "logs",
    }
    for p in dirs.values():
        p.mkdir(parents=True, exist_ok=True)
    return dirs


def package_versions() -> dict[str, str]:
    versions = {"python": sys.version, "platform": platform.platform()}
    for name in ["numpy", "pandas", "scipy", "sklearn", "networkx", "matplotlib", "yaml", "lifelines"]:
        try:
            mod = __import__(name)
            versions[name] = str(getattr(mod, "__version__", "available"))
        except Exception:
            versions[name] = "not_installed"
    return versions


def git_commit_hash(base: Path | None = None) -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(base or project_root()),
            text=True,
            capture_output=True,
            check=True,
            timeout=10,
        )
        return result.stdout.strip()
    except Exception:
        return None


def file_size_or_none(path: str | Path | None) -> int | None:
    if path is None:
        return None
    p = Path(path)
    return p.stat().st_size if p.exists() else None


def read_table_auto(path: str | Path, **kwargs: Any) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Required input file does not exist: {path}")
    suffix = path.suffix.lower()
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t", **kwargs)
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path, **kwargs)
    return pd.read_csv(path, **kwargs)


def normalize_01(values: pd.Series | np.ndarray) -> pd.Series:
    s = pd.Series(values, dtype="float64").replace([np.inf, -np.inf], np.nan)
    if s.notna().sum() == 0:
        return pd.Series(np.zeros(len(s)), index=s.index)
    mn = s.min(skipna=True)
    mx = s.max(skipna=True)
    if not math.isfinite(mn) or not math.isfinite(mx) or mx <= mn:
        return pd.Series(np.full(len(s), 0.5), index=s.index)
    return ((s - mn) / (mx - mn)).fillna(0.0)


def weighted_sum_available(df: pd.DataFrame, weights: dict[str, float], available: Iterable[str]) -> pd.Series:
    cols = [c for c in available if c in df.columns and weights.get(c, 0) > 0]
    total = sum(weights[c] for c in cols)
    if total <= 0:
        return pd.Series(np.zeros(len(df)), index=df.index)
    score = pd.Series(np.zeros(len(df)), index=df.index, dtype="float64")
    for col in cols:
        score += df[col].fillna(0.0) * (weights[col] / total)
    return score


def gene_key(gene: Any) -> str:
    if pd.isna(gene):
        return ""
    return str(gene).strip().upper()


def normalize_sample_id(sample: Any, truncate: int | None = None) -> str:
    value = str(sample).strip()
    if truncate:
        return value[: int(truncate)]
    return value


def split_gene_list(value: Any) -> list[str]:
    if pd.isna(value):
        return []
    if isinstance(value, (list, tuple, set)):
        return [gene_key(x) for x in value]
    return [gene_key(x) for x in str(value).replace("|", ";").split(";") if str(x).strip()]
